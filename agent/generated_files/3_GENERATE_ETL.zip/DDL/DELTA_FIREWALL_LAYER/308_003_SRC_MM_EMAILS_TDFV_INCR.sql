/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


DROP VIEW IF EXISTS "MOTO_MKTG_DFV"."VW_E_MAILS";
CREATE   VIEW "MOTO_MKTG_DFV"."VW_E_MAILS"  AS 
	WITH "DELTA_WINDOW" AS 
	( 
		SELECT 
			  "LWT_SRC"."FMC_BEGIN_LW_TIMESTAMP" AS "FMC_BEGIN_LW_TIMESTAMP"
			, "LWT_SRC"."FMC_END_LW_TIMESTAMP" AS "FMC_END_LW_TIMESTAMP"
		FROM "MOTO_MKTG_MTD"."FMC_LOADING_WINDOW_TABLE" "LWT_SRC"
	)
	, "DELTA_VIEW" AS 
	( 
		SELECT 
			  "CDC_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, "CDC_SRC"."JRN_FLAG" AS "JRN_FLAG"
			, 'S' ::text AS "RECORD_TYPE"
			, "CDC_SRC"."CONTACT_ID" AS "CONTACT_ID"
			, "CDC_SRC"."NAME" AS "NAME"
			, "CDC_SRC"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
		FROM "MOTO_MKTG_CDC"."CDC_E_MAILS" "CDC_SRC"
		INNER JOIN "DELTA_WINDOW" "DELTA_WINDOW" ON  1 = 1
		WHERE  "CDC_SRC"."CDC_TIMESTAMP" >= "DELTA_WINDOW"."FMC_BEGIN_LW_TIMESTAMP" AND "CDC_SRC"."CDC_TIMESTAMP" < "DELTA_WINDOW"."FMC_END_LW_TIMESTAMP"
	)
	, "PREPJOINBK" AS 
	( 
		SELECT 
			  "DELTA_VIEW"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, "DELTA_VIEW"."JRN_FLAG" AS "JRN_FLAG"
			, "DELTA_VIEW"."RECORD_TYPE" AS "RECORD_TYPE"
			, COALESCE("DELTA_VIEW"."CONTACT_ID", TO_NUMBER("MEX_BK_SRC"."KEY_ATTRIBUTE_NUMERIC", 
				'9999999999999D9999999999'::varchar)) AS "CONTACT_ID"
			, "DELTA_VIEW"."NAME" AS "NAME"
			, "DELTA_VIEW"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
		FROM "DELTA_VIEW" "DELTA_VIEW"
		INNER JOIN "MOTO_MKTG_MTD"."MTD_EXCEPTION_RECORDS" "MEX_BK_SRC" ON  1 = 1
		WHERE  "MEX_BK_SRC"."RECORD_TYPE" = 'N'
	)
	SELECT 
		  "PREPJOINBK"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "PREPJOINBK"."JRN_FLAG" AS "JRN_FLAG"
		, "PREPJOINBK"."RECORD_TYPE" AS "RECORD_TYPE"
		, "PREPJOINBK"."CONTACT_ID" AS "CONTACT_ID"
		, "PREPJOINBK"."NAME" AS "NAME"
		, "PREPJOINBK"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
	FROM "PREPJOINBK" "PREPJOINBK"
	LEFT OUTER JOIN "MOTO_DV_FL"."SAT_MM_E_MAILS" "SAT_SRC1" ON  "PREPJOINBK"."CONTACT_ID" = "SAT_SRC1"."CONTACT_ID" AND "SAT_SRC1"."CDC_TIMESTAMP" = "PREPJOINBK"."CDC_TIMESTAMP"
	WHERE  "SAT_SRC1"."CONTACTS_HKEY" IS NULL
	;

 
 
