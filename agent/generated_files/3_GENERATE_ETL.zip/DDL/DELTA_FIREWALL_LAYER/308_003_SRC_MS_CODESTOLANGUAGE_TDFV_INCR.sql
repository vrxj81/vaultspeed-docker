/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


DROP VIEW IF EXISTS "MOTO_SALES_DFV"."VW_CODES_TO_LANGUAGE";
CREATE   VIEW "MOTO_SALES_DFV"."VW_CODES_TO_LANGUAGE"  AS 
	WITH "DELTA_WINDOW" AS 
	( 
		SELECT 
			  "LWT_SRC"."FMC_BEGIN_LW_TIMESTAMP" AS "FMC_BEGIN_LW_TIMESTAMP"
			, "LWT_SRC"."FMC_END_LW_TIMESTAMP" AS "FMC_END_LW_TIMESTAMP"
		FROM "MOTO_SALES_MTD"."FMC_LOADING_WINDOW_TABLE" "LWT_SRC"
	)
	, "DELTA_VIEW" AS 
	( 
		SELECT 
			  "CDC_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, "CDC_SRC"."JRN_FLAG" AS "JRN_FLAG"
			, 'S' ::text AS "RECORD_TYPE"
			, "CDC_SRC"."CODE" AS "CODE"
			, "CDC_SRC"."LANGUAGE_CODE" AS "LANGUAGE_CODE"
			, "CDC_SRC"."DESCRIPTION" AS "DESCRIPTION"
		FROM "MOTO_SALES_CDC"."CDC_CODES_TO_LANGUAGE" "CDC_SRC"
		INNER JOIN "DELTA_WINDOW" "DELTA_WINDOW" ON  1 = 1
		WHERE  "CDC_SRC"."CDC_TIMESTAMP" >= "DELTA_WINDOW"."FMC_BEGIN_LW_TIMESTAMP" AND "CDC_SRC"."CDC_TIMESTAMP" < "DELTA_WINDOW"."FMC_END_LW_TIMESTAMP"
	)
	, "PREPJOINBK" AS 
	( 
		SELECT 
			  "DELTA_VIEW"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, "DELTA_VIEW"."JRN_FLAG" AS "JRN_FLAG"
			, "DELTA_VIEW"."RECORD_TYPE" AS "RECORD_TYPE"
			, COALESCE("DELTA_VIEW"."CODE","MEX_BK_SRC"."KEY_ATTRIBUTE_VARCHAR") AS "CODE"
			, COALESCE("DELTA_VIEW"."LANGUAGE_CODE","MEX_BK_SRC"."KEY_ATTRIBUTE_VARCHAR") AS "LANGUAGE_CODE"
			, "DELTA_VIEW"."DESCRIPTION" AS "DESCRIPTION"
		FROM "DELTA_VIEW" "DELTA_VIEW"
		INNER JOIN "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_BK_SRC" ON  1 = 1
		WHERE  "MEX_BK_SRC"."RECORD_TYPE" = 'N'
	)
	SELECT 
		  "PREPJOINBK"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "PREPJOINBK"."JRN_FLAG" AS "JRN_FLAG"
		, "PREPJOINBK"."RECORD_TYPE" AS "RECORD_TYPE"
		, "PREPJOINBK"."CODE" AS "CODE"
		, "PREPJOINBK"."LANGUAGE_CODE" AS "LANGUAGE_CODE"
		, "PREPJOINBK"."DESCRIPTION" AS "DESCRIPTION"
	FROM "PREPJOINBK" "PREPJOINBK"
	;

 
 
