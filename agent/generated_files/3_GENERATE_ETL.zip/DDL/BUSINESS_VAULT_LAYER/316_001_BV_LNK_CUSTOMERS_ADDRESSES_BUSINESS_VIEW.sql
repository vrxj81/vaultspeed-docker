/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:02:39
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


DROP VIEW IF EXISTS "MOTO_DV_BV"."LNK_CUSTOMERS_ADDRESSES";
CREATE   VIEW "MOTO_DV_BV"."LNK_CUSTOMERS_ADDRESSES"  AS 
	SELECT 
		  "DVT_SRC"."CUSTOMERS_HKEY" AS "CUSTOMERS_HKEY"
		, "DVT_SRC"."LNK_CUSTOMERS_ADDRESSES_HKEY" AS "LNK_CUSTOMERS_ADDRESSES_HKEY"
		, "DVT_SRC"."ADDRESSES_HKEY" AS "ADDRESSES_HKEY"
		, "DVT_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "DVT_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "DVT_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
	FROM "MOTO_DV_FL"."LNK_CUSTOMERS_ADDRESSES" "DVT_SRC"
	;

 
 
