CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."LKS_MS_CUSTOMERS_ADDRESSES_CIAI_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- LKS_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."LKS_MS_CUSTOMERS_ADDRESSES_CIAI"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."LKS_MS_CUSTOMERS_ADDRESSES_CIAI"(
		 "LNK_CUSTOMERS_ADDRESSES_CIAI_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"DELETE_FLAG"
		,"CDC_TIMESTAMP"
	)
	WITH "STG_SRC" AS 
	( 
		SELECT 
			  "STG_INR_SRC"."LNK_CUSTOMERS_ADDRESSES_CIAI_HKEY" AS "LNK_CUSTOMERS_ADDRESSES_CIAI_HKEY"
			, "STG_INR_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "STG_INR_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, 'N'::text AS "DELETE_FLAG"
			, "STG_INR_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, ROW_NUMBER()OVER(PARTITION BY "STG_INR_SRC"."CUSTOMERS_HKEY" ORDER BY "STG_INR_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_SALES_STG"."CUSTOMERS" "STG_INR_SRC"
	)
	SELECT 
		  "STG_SRC"."LNK_CUSTOMERS_ADDRESSES_CIAI_HKEY" AS "LNK_CUSTOMERS_ADDRESSES_CIAI_HKEY"
		, "STG_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_SRC"."DELETE_FLAG" AS "DELETE_FLAG"
		, "STG_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
	FROM "STG_SRC" "STG_SRC"
	WHERE  "STG_SRC"."DUMMY" = 1
	;
END;


END;
$function$;
 
 
