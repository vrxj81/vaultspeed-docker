CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."REF_MS_CODESTOLANGUAGE_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- REF_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."REF_MS_CODES_TO_LANGUAGE"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."REF_MS_CODES_TO_LANGUAGE"(
		 "CODE"
		,"LANGUAGE_CODE"
		,"LOAD_CYCLE_ID"
		,"LOAD_DATE"
		,"DESCRIPTION"
		,"RECORD_SOURCE"
	)
	WITH "PREP_EXCEP" AS 
	( 
		SELECT 
			  "INI_SRC"."CODE" AS "CODE"
			, "INI_SRC"."LANGUAGE_CODE" AS "LANGUAGE_CODE"
			, NULL ::int AS "LOAD_CYCLE_ID"
			, "INI_SRC"."DESCRIPTION" AS "DESCRIPTION"
		FROM "MOTO_SALES_INI"."CODES_TO_LANGUAGE" "INI_SRC"
		UNION 
		SELECT 
			  "MEX_EX_SRC"."KEY_ATTRIBUTE_VARCHAR"::text AS "CODE"
			, "MEX_EX_SRC"."KEY_ATTRIBUTE_VARCHAR"::text AS "LANGUAGE_CODE"
			, "MEX_EX_SRC"."LOAD_CYCLE_ID" ::int AS "LOAD_CYCLE_ID"
			, "MEX_EX_SRC"."ATTRIBUTE_VARCHAR"::text AS "DESCRIPTION"
		FROM "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_EX_SRC"
	)
	SELECT 
		  "PREP_EXCEP"."CODE" AS "CODE"
		, "PREP_EXCEP"."LANGUAGE_CODE" AS "LANGUAGE_CODE"
		, COALESCE("PREP_EXCEP"."LOAD_CYCLE_ID","LCI_SRC"."LOAD_CYCLE_ID") AS "LOAD_CYCLE_ID"
		, "LCI_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "PREP_EXCEP"."DESCRIPTION" AS "DESCRIPTION"
		, 'MS.CODES_TO_LANGUAGE' AS "RECORD_SOURCE"
	FROM "PREP_EXCEP" "PREP_EXCEP"
	INNER JOIN "MOTO_SALES_MTD"."LOAD_CYCLE_INFO" "LCI_SRC" ON  1 = 1
	;
END;


END;
$function$;
 
 
