CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."LDS_MS_PRODUCTFEATCLASSREL_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- LDS_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."LDS_MS_PRODUCT_FEAT_CLASS_REL"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."LDS_MS_PRODUCT_FEAT_CLASS_REL"(
		 "LND_PRODUCT_FEAT_CLASS_REL_HKEY"
		,"PRODUCT_FEATURE_ID"
		,"PRODUCT_ID"
		,"PRODUCT_FEATURE_CLASS_ID"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"DELETE_FLAG"
		,"CDC_TIMESTAMP"
	)
	WITH "STG_DL_SRC" AS 
	( 
		SELECT 
			  "STG_DL_INR_SRC"."LND_PRODUCT_FEAT_CLASS_REL_HKEY" AS "LND_PRODUCT_FEAT_CLASS_REL_HKEY"
			, "STG_DL_INR_SRC"."PRODUCT_FEATURE_ID" AS "PRODUCT_FEATURE_ID"
			, "STG_DL_INR_SRC"."PRODUCT_ID" AS "PRODUCT_ID"
			, "STG_DL_INR_SRC"."PRODUCT_FEATURE_CLASS_ID" AS "PRODUCT_FEATURE_CLASS_ID"
			, "STG_DL_INR_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "STG_DL_INR_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, 'N'::text AS "DELETE_FLAG"
			, "STG_DL_INR_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, ROW_NUMBER()OVER(PARTITION BY "STG_DL_INR_SRC"."PRODUCTS_HKEY" ,  "STG_DL_INR_SRC"."PRODUCT_FEATURES_HKEY" ORDER BY "STG_DL_INR_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_SALES_STG"."PRODUCT_FEAT_CLASS_REL" "STG_DL_INR_SRC"
	)
	SELECT 
		  "STG_DL_SRC"."LND_PRODUCT_FEAT_CLASS_REL_HKEY" AS "LND_PRODUCT_FEAT_CLASS_REL_HKEY"
		, "STG_DL_SRC"."PRODUCT_FEATURE_ID" AS "PRODUCT_FEATURE_ID"
		, "STG_DL_SRC"."PRODUCT_ID" AS "PRODUCT_ID"
		, "STG_DL_SRC"."PRODUCT_FEATURE_CLASS_ID" AS "PRODUCT_FEATURE_CLASS_ID"
		, "STG_DL_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_DL_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_DL_SRC"."DELETE_FLAG" AS "DELETE_FLAG"
		, "STG_DL_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
	FROM "STG_DL_SRC" "STG_DL_SRC"
	WHERE  "STG_DL_SRC"."DUMMY" = 1
	;
END;


END;
$function$;
 
 
