CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."HUB_MM_CONTACTS_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


BEGIN 

BEGIN -- HUB_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."HUB_CONTACTS"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."HUB_CONTACTS"(
		 "CONTACTS_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"CONTACT_ID_BK"
		,"RECORD_SOURCE"
	)
	SELECT DISTINCT 
		  "STG_SRC"."CONTACTS_HKEY" AS "CONTACTS_HKEY"
		, "STG_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_SRC"."CONTACT_ID_BK" AS "CONTACT_ID_BK"
		, "STG_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
	FROM "MOTO_MKTG_STG"."CONTACTS" "STG_SRC"
	;
END;


END;
$function$;
 
 
