CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."LKS_MM_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


BEGIN 

BEGIN -- LKS_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."LKS_MM_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."LKS_MM_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER"(
		 "LNK_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"DELETE_FLAG"
		,"CDC_TIMESTAMP"
		,"PARTY_NUMBER"
		,"PARENT_PARTY_NUMBER"
	)
	WITH "STG_SRC" AS 
	( 
		SELECT 
			  "STG_INR_SRC"."LNK_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER_HKEY" AS "LNK_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER_HKEY"
			, "STG_INR_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "STG_INR_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, 'N'::text AS "DELETE_FLAG"
			, "STG_INR_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, "STG_INR_SRC"."PARTY_NUMBER" AS "PARTY_NUMBER"
			, "STG_INR_SRC"."PARENT_PARTY_NUMBER" AS "PARENT_PARTY_NUMBER"
			, ROW_NUMBER()OVER(PARTITION BY "STG_INR_SRC"."CUSTOMERS_HKEY" ORDER BY "STG_INR_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_MKTG_STG"."PARTY" "STG_INR_SRC"
	)
	SELECT 
		  "STG_SRC"."LNK_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER_HKEY" AS "LNK_CUSTOMERS_CUSTOMERS_PARENTPARTYNUMBER_HKEY"
		, "STG_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_SRC"."DELETE_FLAG" AS "DELETE_FLAG"
		, "STG_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "STG_SRC"."PARTY_NUMBER" AS "PARTY_NUMBER"
		, "STG_SRC"."PARENT_PARTY_NUMBER" AS "PARENT_PARTY_NUMBER"
	FROM "STG_SRC" "STG_SRC"
	WHERE  "STG_SRC"."DUMMY" = 1
	;
END;


END;
$function$;
 
 
