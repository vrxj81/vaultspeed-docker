CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."LND_MM_CAMPAIGNMOTORCYCLES_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


BEGIN 

BEGIN -- LND_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."LND_CAMPAIGN_MOTORCYCLES"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."LND_CAMPAIGN_MOTORCYCLES"(
		 "LND_CAMPAIGN_MOTORCYCLES_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"PRODUCTS_HKEY"
		,"CAMPAIGNS_HKEY"
		,"RECORD_SOURCE"
	)
	WITH "STG_DL_SRC" AS 
	( 
		SELECT 
			  "IN_STG_DL_SRC"."LND_CAMPAIGN_MOTORCYCLES_HKEY" AS "LND_CAMPAIGN_MOTORCYCLES_HKEY"
			, "IN_STG_DL_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "IN_STG_DL_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, "IN_STG_DL_SRC"."PRODUCTS_HKEY" AS "PRODUCTS_HKEY"
			, "IN_STG_DL_SRC"."CAMPAIGNS_HKEY" AS "CAMPAIGNS_HKEY"
			, "IN_STG_DL_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
			, ROW_NUMBER()OVER(PARTITION BY "IN_STG_DL_SRC"."LND_CAMPAIGN_MOTORCYCLES_HKEY" ORDER BY "IN_STG_DL_SRC"."LOAD_CYCLE_ID",
				"IN_STG_DL_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_MKTG_STG"."CAMPAIGN_MOTORCYCLES" "IN_STG_DL_SRC"
	)
	SELECT 
		  "STG_DL_SRC"."LND_CAMPAIGN_MOTORCYCLES_HKEY" AS "LND_CAMPAIGN_MOTORCYCLES_HKEY"
		, "STG_DL_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_DL_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_DL_SRC"."PRODUCTS_HKEY" AS "PRODUCTS_HKEY"
		, "STG_DL_SRC"."CAMPAIGNS_HKEY" AS "CAMPAIGNS_HKEY"
		, "STG_DL_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
	FROM "STG_DL_SRC" "STG_DL_SRC"
	WHERE  "STG_DL_SRC"."DUMMY" = 1
	;
END;


END;
$function$;
 
 
