CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."SAT_MM_CONTACTS_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


BEGIN 

BEGIN -- SAT_TGT

	TRUNCATE TABLE "MOTO_DV_FL"."SAT_MM_CONTACTS"  CASCADE;

	INSERT INTO "MOTO_DV_FL"."SAT_MM_CONTACTS"(
		 "CONTACTS_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"HASH_DIFF"
		,"DELETE_FLAG"
		,"CDC_TIMESTAMP"
		,"CONTACT_ID"
		,"CONTACT_TYPE"
		,"CONTACT_TYPE_DESC"
		,"UPDATE_TIMESTAMP"
	)
	WITH "STG_SRC" AS 
	( 
		SELECT 
			  "STG_INR_SRC"."CONTACTS_HKEY" AS "CONTACTS_HKEY"
			, "STG_INR_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "STG_INR_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, UPPER(ENCODE(DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "STG_INR_SRC"."CONTACT_TYPE"),'~'),'#','\' || '#')
				|| '#' ||  REPLACE(COALESCE(TRIM( "STG_INR_SRC"."CONTACT_TYPE_DESC"),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("STG_INR_SRC"."UPDATE_TIMESTAMP", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'MD5'),'HEX')) AS "HASH_DIFF"
			, 'N'::text AS "DELETE_FLAG"
			, "STG_INR_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, "STG_INR_SRC"."CONTACT_ID" AS "CONTACT_ID"
			, "STG_INR_SRC"."CONTACT_TYPE" AS "CONTACT_TYPE"
			, "STG_INR_SRC"."CONTACT_TYPE_DESC" AS "CONTACT_TYPE_DESC"
			, "STG_INR_SRC"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
			, ROW_NUMBER()OVER(PARTITION BY "STG_INR_SRC"."CONTACTS_HKEY" ORDER BY "STG_INR_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_MKTG_STG"."CONTACTS" "STG_INR_SRC"
	)
	SELECT 
		  "STG_SRC"."CONTACTS_HKEY" AS "CONTACTS_HKEY"
		, "STG_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_SRC"."HASH_DIFF" AS "HASH_DIFF"
		, "STG_SRC"."DELETE_FLAG" AS "DELETE_FLAG"
		, "STG_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "STG_SRC"."CONTACT_ID" AS "CONTACT_ID"
		, "STG_SRC"."CONTACT_TYPE" AS "CONTACT_TYPE"
		, "STG_SRC"."CONTACT_TYPE_DESC" AS "CONTACT_TYPE_DESC"
		, "STG_SRC"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
	FROM "STG_SRC" "STG_SRC"
	WHERE  "STG_SRC"."DUMMY" = 1
	;
END;


END;
$function$;
 
 
