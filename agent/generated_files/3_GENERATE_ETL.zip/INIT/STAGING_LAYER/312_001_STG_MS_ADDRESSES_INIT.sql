CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."STG_MS_ADDRESSES_INIT"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- STG_TGT

	TRUNCATE TABLE "MOTO_SALES_STG"."ADDRESSES"  CASCADE;

	INSERT INTO "MOTO_SALES_STG"."ADDRESSES"(
		 "ADDRESSES_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"SRC_BK"
		,"RECORD_SOURCE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"ADDRESS_NUMBER"
		,"STREET_NAME"
		,"STREET_NUMBER"
		,"POSTAL_CODE"
		,"CITY"
		,"STREET_NAME_BK"
		,"STREET_NUMBER_BK"
		,"POSTAL_CODE_BK"
		,"CITY_BK"
	)
	SELECT 
		  UPPER(ENCODE(DIGEST( 'MS' || '#' || "EXT_SRC"."STREET_NAME_BK" || '#' ||  "EXT_SRC"."STREET_NUMBER_BK" || '#' ||  
			"EXT_SRC"."POSTAL_CODE_BK" || '#' ||  "EXT_SRC"."CITY_BK" || '#' ,'MD5'),'HEX')) AS "ADDRESSES_HKEY"
		, "EXT_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "EXT_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, 'MS' AS "SRC_BK"
		, 'MS.ADDRESSES' AS "RECORD_SOURCE"
		, "EXT_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "EXT_SRC"."JRN_FLAG" AS "JRN_FLAG"
		, "EXT_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
		, "EXT_SRC"."ADDRESS_NUMBER" AS "ADDRESS_NUMBER"
		, "EXT_SRC"."STREET_NAME" AS "STREET_NAME"
		, "EXT_SRC"."STREET_NUMBER" AS "STREET_NUMBER"
		, "EXT_SRC"."POSTAL_CODE" AS "POSTAL_CODE"
		, "EXT_SRC"."CITY" AS "CITY"
		, "EXT_SRC"."STREET_NAME_BK" AS "STREET_NAME_BK"
		, "EXT_SRC"."STREET_NUMBER_BK" AS "STREET_NUMBER_BK"
		, "EXT_SRC"."POSTAL_CODE_BK" AS "POSTAL_CODE_BK"
		, "EXT_SRC"."CITY_BK" AS "CITY_BK"
	FROM "MOTO_SALES_EXT"."ADDRESSES" "EXT_SRC"
	INNER JOIN "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  "MEX_SRC"."RECORD_TYPE" = 'U'
	;
END;


END;
$function$;
 
 
