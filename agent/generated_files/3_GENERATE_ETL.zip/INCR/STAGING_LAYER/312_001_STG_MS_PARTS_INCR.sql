CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."STG_MS_PARTS_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- STG_TGT

	TRUNCATE TABLE "MOTO_SALES_STG"."PARTS"  CASCADE;

	INSERT INTO "MOTO_SALES_STG"."PARTS"(
		 "PARTS_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"RECORD_SOURCE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"PART_ID"
		,"PART_NUMBER_BK"
		,"PART_LANGUAGE_CODE_BK"
	)
	SELECT 
		  UPPER(ENCODE(DIGEST( "EXT_SRC"."PART_NUMBER_BK" || '#' ||  "EXT_SRC"."PART_LANGUAGE_CODE_BK" || '#' ,'MD5'),
			'HEX')) AS "PARTS_HKEY"
		, "EXT_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "EXT_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, 'MS.PARTS' AS "RECORD_SOURCE"
		, "EXT_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "EXT_SRC"."JRN_FLAG" AS "JRN_FLAG"
		, "EXT_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
		, "EXT_SRC"."PART_ID" AS "PART_ID"
		, "EXT_SRC"."PART_NUMBER_BK" AS "PART_NUMBER_BK"
		, "EXT_SRC"."PART_LANGUAGE_CODE_BK" AS "PART_LANGUAGE_CODE_BK"
	FROM "MOTO_SALES_EXT"."PARTS" "EXT_SRC"
	INNER JOIN "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  "MEX_SRC"."RECORD_TYPE" = 'U'
	;
END;


END;
$function$;
 
 
