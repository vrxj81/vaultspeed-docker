CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."STG_MM_PHONES_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


BEGIN 

BEGIN -- STG_TGT

	TRUNCATE TABLE "MOTO_MKTG_STG"."PHONES"  CASCADE;

	INSERT INTO "MOTO_MKTG_STG"."PHONES"(
		 "CONTACTS_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"RECORD_SOURCE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"CONTACT_ID"
		,"CONTACT_ID_FK_CONTACTID_BK"
		,"PHONE_NUMBER"
		,"UPDATE_TIMESTAMP"
	)
	SELECT 
		  UPPER(ENCODE(DIGEST( "EXT_SRC"."CONTACT_ID_FK_CONTACTID_BK" || '#' ,'MD5'),'HEX')) AS "CONTACTS_HKEY"
		, "EXT_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "EXT_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, 'MM.PHONES' AS "RECORD_SOURCE"
		, "EXT_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "EXT_SRC"."JRN_FLAG" AS "JRN_FLAG"
		, "EXT_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
		, "EXT_SRC"."CONTACT_ID" AS "CONTACT_ID"
		, "EXT_SRC"."CONTACT_ID_FK_CONTACTID_BK" AS "CONTACT_ID_FK_CONTACTID_BK"
		, "EXT_SRC"."PHONE_NUMBER" AS "PHONE_NUMBER"
		, "EXT_SRC"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
	FROM "MOTO_MKTG_EXT"."PHONES" "EXT_SRC"
	INNER JOIN "MOTO_MKTG_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  "MEX_SRC"."RECORD_TYPE" = 'U'
	;
END;


END;
$function$;
 
 
