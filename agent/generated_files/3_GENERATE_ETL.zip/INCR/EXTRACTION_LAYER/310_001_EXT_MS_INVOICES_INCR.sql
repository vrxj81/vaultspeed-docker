CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."EXT_MS_INVOICES_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- EXT_TGT

	TRUNCATE TABLE "MOTO_SALES_EXT"."INVOICES"  CASCADE;

	INSERT INTO "MOTO_SALES_EXT"."INVOICES"(
		 "LOAD_CYCLE_ID"
		,"LOAD_DATE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"INVOICE_NUMBER"
		,"INVOICE_CUSTOMER_ID"
		,"INVOICE_NUMBER_BK"
		,"INVOICE_DATE"
		,"AMOUNT"
		,"DISCOUNT"
	)
	WITH "CALCULATE_BK" AS 
	( 
		SELECT 
			  "LCI_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, CURRENT_TIMESTAMP + row_number() over (order by "TDFV_SRC"."CDC_TIMESTAMP") * interval'2 microsecond'   AS "LOAD_DATE"
			, "TDFV_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, COALESCE("TDFV_SRC"."JRN_FLAG","MEX_SRC"."ATTRIBUTE_VARCHAR") AS "JRN_FLAG"
			, "TDFV_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
			, "TDFV_SRC"."INVOICE_NUMBER" AS "INVOICE_NUMBER"
			, "TDFV_SRC"."INVOICE_CUSTOMER_ID" AS "INVOICE_CUSTOMER_ID"
			, COALESCE(UPPER( "TDFV_SRC"."INVOICE_NUMBER"::text),"MEX_SRC"."KEY_ATTRIBUTE_NUMERIC") AS "INVOICE_NUMBER_BK"
			, "TDFV_SRC"."INVOICE_DATE" AS "INVOICE_DATE"
			, "TDFV_SRC"."AMOUNT" AS "AMOUNT"
			, "TDFV_SRC"."DISCOUNT" AS "DISCOUNT"
		FROM "MOTO_SALES_DFV"."VW_INVOICES" "TDFV_SRC"
		INNER JOIN "MOTO_SALES_MTD"."LOAD_CYCLE_INFO" "LCI_SRC" ON  1 = 1
		INNER JOIN "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  1 = 1
		WHERE  "MEX_SRC"."RECORD_TYPE" = 'N'
	)
	SELECT 
		  "CALCULATE_BK"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "CALCULATE_BK"."LOAD_DATE" AS "LOAD_DATE"
		, "CALCULATE_BK"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "CALCULATE_BK"."JRN_FLAG" AS "JRN_FLAG"
		, "CALCULATE_BK"."RECORD_TYPE" AS "RECORD_TYPE"
		, "CALCULATE_BK"."INVOICE_NUMBER" AS "INVOICE_NUMBER"
		, "CALCULATE_BK"."INVOICE_CUSTOMER_ID" AS "INVOICE_CUSTOMER_ID"
		, "CALCULATE_BK"."INVOICE_NUMBER_BK" AS "INVOICE_NUMBER_BK"
		, "CALCULATE_BK"."INVOICE_DATE" AS "INVOICE_DATE"
		, "CALCULATE_BK"."AMOUNT" AS "AMOUNT"
		, "CALCULATE_BK"."DISCOUNT" AS "DISCOUNT"
	FROM "CALCULATE_BK" "CALCULATE_BK"
	;
END;


END;
$function$;
 
 
