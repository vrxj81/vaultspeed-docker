CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."EXT_MS_PRODUCTFEATCLASSREL_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- EXT_TGT

	TRUNCATE TABLE "MOTO_SALES_EXT"."PRODUCT_FEAT_CLASS_REL"  CASCADE;

	INSERT INTO "MOTO_SALES_EXT"."PRODUCT_FEAT_CLASS_REL"(
		 "LOAD_CYCLE_ID"
		,"LOAD_DATE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"PRODUCT_FEATURE_ID"
		,"PRODUCT_ID"
		,"PRODUCT_FEATURE_CLASS_ID"
	)
	WITH "CALCULATE_BK" AS 
	( 
		SELECT 
			  "LCI_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, CURRENT_TIMESTAMP + row_number() over (order by "TDFV_SRC"."CDC_TIMESTAMP") * interval'2 microsecond'   AS "LOAD_DATE"
			, "TDFV_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, COALESCE("TDFV_SRC"."JRN_FLAG","MEX_SRC"."ATTRIBUTE_VARCHAR") AS "JRN_FLAG"
			, "TDFV_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
			, "TDFV_SRC"."PRODUCT_FEATURE_ID" AS "PRODUCT_FEATURE_ID"
			, "TDFV_SRC"."PRODUCT_ID" AS "PRODUCT_ID"
			, "TDFV_SRC"."PRODUCT_FEATURE_CLASS_ID" AS "PRODUCT_FEATURE_CLASS_ID"
		FROM "MOTO_SALES_DFV"."VW_PRODUCT_FEAT_CLASS_REL" "TDFV_SRC"
		INNER JOIN "MOTO_SALES_MTD"."LOAD_CYCLE_INFO" "LCI_SRC" ON  1 = 1
		INNER JOIN "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  1 = 1
		WHERE  "MEX_SRC"."RECORD_TYPE" = 'N'
	)
	SELECT 
		  "CALCULATE_BK"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "CALCULATE_BK"."LOAD_DATE" AS "LOAD_DATE"
		, "CALCULATE_BK"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "CALCULATE_BK"."JRN_FLAG" AS "JRN_FLAG"
		, "CALCULATE_BK"."RECORD_TYPE" AS "RECORD_TYPE"
		, "CALCULATE_BK"."PRODUCT_FEATURE_ID" AS "PRODUCT_FEATURE_ID"
		, "CALCULATE_BK"."PRODUCT_ID" AS "PRODUCT_ID"
		, "CALCULATE_BK"."PRODUCT_FEATURE_CLASS_ID" AS "PRODUCT_FEATURE_CLASS_ID"
	FROM "CALCULATE_BK" "CALCULATE_BK"
	;
END;


END;
$function$;
 
 
