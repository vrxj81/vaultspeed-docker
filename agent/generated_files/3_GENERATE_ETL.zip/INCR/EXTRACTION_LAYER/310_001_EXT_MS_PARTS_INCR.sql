CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."EXT_MS_PARTS_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- EXT_TGT

	TRUNCATE TABLE "MOTO_SALES_EXT"."PARTS"  CASCADE;

	INSERT INTO "MOTO_SALES_EXT"."PARTS"(
		 "LOAD_CYCLE_ID"
		,"LOAD_DATE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"PART_ID"
		,"PART_NUMBER_BK"
		,"PART_LANGUAGE_CODE_BK"
	)
	WITH "CALCULATE_BK" AS 
	( 
		SELECT 
			  "LCI_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, CURRENT_TIMESTAMP + row_number() over (order by "TDFV_SRC"."CDC_TIMESTAMP") * interval'2 microsecond'   AS "LOAD_DATE"
			, "TDFV_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, COALESCE("TDFV_SRC"."JRN_FLAG","MEX_SRC"."ATTRIBUTE_VARCHAR") AS "JRN_FLAG"
			, "TDFV_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
			, "TDFV_SRC"."PART_ID" AS "PART_ID"
			, COALESCE(UPPER(REPLACE(TRIM( "TDFV_SRC"."PART_NUMBER"),'#','\' || '#')),"MEX_SRC"."KEY_ATTRIBUTE_VARCHAR") AS "PART_NUMBER_BK"
			, COALESCE(UPPER(REPLACE(TRIM( "TDFV_SRC"."PART_LANGUAGE_CODE"),'#','\' || '#')),"MEX_SRC"."KEY_ATTRIBUTE_VARCHAR") AS "PART_LANGUAGE_CODE_BK"
		FROM "MOTO_SALES_DFV"."VW_PARTS" "TDFV_SRC"
		INNER JOIN "MOTO_SALES_MTD"."LOAD_CYCLE_INFO" "LCI_SRC" ON  1 = 1
		INNER JOIN "MOTO_SALES_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  1 = 1
		WHERE  "MEX_SRC"."RECORD_TYPE" = 'N'
	)
	SELECT 
		  "CALCULATE_BK"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "CALCULATE_BK"."LOAD_DATE" AS "LOAD_DATE"
		, "CALCULATE_BK"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "CALCULATE_BK"."JRN_FLAG" AS "JRN_FLAG"
		, "CALCULATE_BK"."RECORD_TYPE" AS "RECORD_TYPE"
		, "CALCULATE_BK"."PART_ID" AS "PART_ID"
		, "CALCULATE_BK"."PART_NUMBER_BK" AS "PART_NUMBER_BK"
		, "CALCULATE_BK"."PART_LANGUAGE_CODE_BK" AS "PART_LANGUAGE_CODE_BK"
	FROM "CALCULATE_BK" "CALCULATE_BK"
	;
END;


END;
$function$;
 
 
