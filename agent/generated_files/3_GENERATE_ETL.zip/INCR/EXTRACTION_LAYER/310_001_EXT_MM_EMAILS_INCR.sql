CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."EXT_MM_EMAILS_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:11
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_MKTG - Release: MOTO_MKTG(1) - Comment: Initial Marketing Release - Release date: 2022/03/21 17:49:04
 */


BEGIN 

BEGIN -- EXT_TGT

	TRUNCATE TABLE "MOTO_MKTG_EXT"."E_MAILS"  CASCADE;

	INSERT INTO "MOTO_MKTG_EXT"."E_MAILS"(
		 "LOAD_CYCLE_ID"
		,"LOAD_DATE"
		,"CDC_TIMESTAMP"
		,"JRN_FLAG"
		,"RECORD_TYPE"
		,"CONTACT_ID"
		,"CONTACT_ID_FK_CONTACTID_BK"
		,"NAME"
		,"UPDATE_TIMESTAMP"
	)
	WITH "CALCULATE_BK" AS 
	( 
		SELECT 
			  "LCI_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, CURRENT_TIMESTAMP + row_number() over (order by "TDFV_SRC"."CDC_TIMESTAMP") * interval'2 microsecond'   AS "LOAD_DATE"
			, "TDFV_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, COALESCE("TDFV_SRC"."JRN_FLAG","MEX_SRC"."ATTRIBUTE_VARCHAR") AS "JRN_FLAG"
			, "TDFV_SRC"."RECORD_TYPE" AS "RECORD_TYPE"
			, "TDFV_SRC"."CONTACT_ID" AS "CONTACT_ID"
			, UPPER( "TDFV_SRC"."CONTACT_ID"::text) AS "CONTACT_ID_FK_CONTACTID_BK"
			, "TDFV_SRC"."NAME" AS "NAME"
			, "TDFV_SRC"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
		FROM "MOTO_MKTG_DFV"."VW_E_MAILS" "TDFV_SRC"
		INNER JOIN "MOTO_MKTG_MTD"."LOAD_CYCLE_INFO" "LCI_SRC" ON  1 = 1
		INNER JOIN "MOTO_MKTG_MTD"."MTD_EXCEPTION_RECORDS" "MEX_SRC" ON  1 = 1
		WHERE  "MEX_SRC"."RECORD_TYPE" = 'N'
	)
	SELECT 
		  "CALCULATE_BK"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "CALCULATE_BK"."LOAD_DATE" AS "LOAD_DATE"
		, "CALCULATE_BK"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
		, "CALCULATE_BK"."JRN_FLAG" AS "JRN_FLAG"
		, "CALCULATE_BK"."RECORD_TYPE" AS "RECORD_TYPE"
		, "CALCULATE_BK"."CONTACT_ID" AS "CONTACT_ID"
		, "CALCULATE_BK"."CONTACT_ID_FK_CONTACTID_BK" AS "CONTACT_ID_FK_CONTACTID_BK"
		, "CALCULATE_BK"."NAME" AS "NAME"
		, "CALCULATE_BK"."UPDATE_TIMESTAMP" AS "UPDATE_TIMESTAMP"
	FROM "CALCULATE_BK" "CALCULATE_BK"
	;
END;


END;
$function$;
 
 
