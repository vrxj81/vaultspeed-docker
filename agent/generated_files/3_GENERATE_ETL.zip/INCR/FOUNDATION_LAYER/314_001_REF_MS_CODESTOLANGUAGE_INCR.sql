CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."REF_MS_CODESTOLANGUAGE_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- REF_TGT_DEL

	ALTER TABLE "MOTO_DV_FL"."REF_MS_CODES_TO_LANGUAGE" DISABLE TRIGGER ALL;

	DELETE  FROM "MOTO_DV_FL"."REF_MS_CODES_TO_LANGUAGE" "REF_DEL_TGT"
	WHERE EXISTS ( 
		SELECT 1 
		FROM "MOTO_SALES_DFV"."VW_CODES_TO_LANGUAGE" "TDFV_DEL_SRC"
		WHERE  "REF_DEL_TGT"."CODE" = "TDFV_DEL_SRC"."CODE" AND  "REF_DEL_TGT"."LANGUAGE_CODE" = "TDFV_DEL_SRC"."LANGUAGE_CODE")

	;
END;


BEGIN -- REF_TGT

	INSERT INTO "MOTO_DV_FL"."REF_MS_CODES_TO_LANGUAGE"(
		 "CODE"
		,"LANGUAGE_CODE"
		,"LOAD_CYCLE_ID"
		,"LOAD_DATE"
		,"DESCRIPTION"
		,"RECORD_SOURCE"
	)
	WITH "NEW_SET" AS 
	( 
		SELECT 
			  "TDFV_SRC"."DESCRIPTION" AS "DESCRIPTION"
			, "TDFV_SRC"."CODE" AS "CODE"
			, "TDFV_SRC"."LANGUAGE_CODE" AS "LANGUAGE_CODE"
			, "TDFV_SRC"."CDC_TIMESTAMP" AS "CDC_TIMESTAMP"
			, ROW_NUMBER()OVER(PARTITION BY "TDFV_SRC"."CODE" ,  "TDFV_SRC"."LANGUAGE_CODE" ORDER BY "TDFV_SRC"."CDC_TIMESTAMP" DESC) AS "DUMMY"
		FROM "MOTO_SALES_DFV"."VW_CODES_TO_LANGUAGE" "TDFV_SRC"
	)
	SELECT 
		  "NEW_SET"."CODE" AS "CODE"
		, "NEW_SET"."LANGUAGE_CODE" AS "LANGUAGE_CODE"
		, "LCI_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "NEW_SET"."CDC_TIMESTAMP" AS "LOAD_DATE"
		, "NEW_SET"."DESCRIPTION" AS "DESCRIPTION"
		, 'MS.CODES_TO_LANGUAGE' AS "RECORD_SOURCE"
	FROM "NEW_SET" "NEW_SET"
	INNER JOIN "MOTO_SALES_MTD"."LOAD_CYCLE_INFO" "LCI_SRC" ON  1 = 1
	LEFT OUTER JOIN "MOTO_DV_FL"."REF_MS_CODES_TO_LANGUAGE" "REF_SRC" ON  "NEW_SET"."CODE" = "REF_SRC"."CODE" AND  "NEW_SET"."LANGUAGE_CODE" = "REF_SRC"."LANGUAGE_CODE"
	WHERE  "NEW_SET"."DUMMY" = 1 AND "REF_SRC"."CODE" IS NULL AND "REF_SRC"."LANGUAGE_CODE" IS NULL
	;
END;


END;
$function$;
 
 
