CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."LNK_MS_INVOICELINES_PRODUCTS_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- LNK_TGT

	INSERT INTO "MOTO_DV_FL"."LNK_INVOICELINES_PRODUCTS"(
		 "LNK_INVOICELINES_PRODUCTS_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"PRODUCTS_HKEY"
		,"INVOICE_LINES_HKEY"
		,"RECORD_SOURCE"
	)
	WITH "STG_SRC" AS 
	( 
		SELECT 
			  "STG_INR_SRC"."LNK_INVOICELINES_PRODUCTS_HKEY" AS "LNK_INVOICELINES_PRODUCTS_HKEY"
			, "STG_INR_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "STG_INR_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, "STG_INR_SRC"."PRODUCTS_HKEY" AS "PRODUCTS_HKEY"
			, "STG_INR_SRC"."INVOICE_LINES_HKEY" AS "INVOICE_LINES_HKEY"
			, "STG_INR_SRC"."JRN_FLAG" AS "JRN_FLAG"
			, "STG_INR_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
			, ROW_NUMBER()OVER(PARTITION BY "STG_INR_SRC"."LNK_INVOICELINES_PRODUCTS_HKEY" ORDER BY "STG_INR_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_SALES_STG"."INVOICE_LINES" "STG_INR_SRC"
		WHERE  "STG_INR_SRC"."RECORD_TYPE" = 'S'
	)
	SELECT 
		  "STG_SRC"."LNK_INVOICELINES_PRODUCTS_HKEY" AS "LNK_INVOICELINES_PRODUCTS_HKEY"
		, "STG_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_SRC"."PRODUCTS_HKEY" AS "PRODUCTS_HKEY"
		, "STG_SRC"."INVOICE_LINES_HKEY" AS "INVOICE_LINES_HKEY"
		, "STG_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
	FROM "STG_SRC" "STG_SRC"
	LEFT OUTER JOIN "MOTO_DV_FL"."LNK_INVOICELINES_PRODUCTS" "LNK_SRC" ON  "STG_SRC"."LNK_INVOICELINES_PRODUCTS_HKEY" = "LNK_SRC"."LNK_INVOICELINES_PRODUCTS_HKEY"
	WHERE  "LNK_SRC"."LNK_INVOICELINES_PRODUCTS_HKEY" IS NULL AND "STG_SRC"."DUMMY" = 1
	;
END;


END;
$function$;
 
 
