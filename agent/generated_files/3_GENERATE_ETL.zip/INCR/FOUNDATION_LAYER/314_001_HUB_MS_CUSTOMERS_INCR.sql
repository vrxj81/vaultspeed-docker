CREATE OR REPLACE FUNCTION "VAULTSPEED_HANDSON_PROC"."HUB_MS_CUSTOMERS_INCR"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 18:01:55
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 17:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09, 
SRC_NAME: MOTO_SALES - Release: MOTO_SALES(1) - Comment: First Release - Release date: 2019/08/26 23:44:29
 */


BEGIN 

BEGIN -- HUB_TGT

	INSERT INTO "MOTO_DV_FL"."HUB_CUSTOMERS"(
		 "CUSTOMERS_HKEY"
		,"LOAD_DATE"
		,"LOAD_CYCLE_ID"
		,"CUSTOMERS_BK"
		,"SRC_BK"
		,"RECORD_SOURCE"
	)
	WITH "STG_SRC" AS 
	( 
		SELECT 
			  "STG_INR_SRC"."CUSTOMERS_HKEY" AS "CUSTOMERS_HKEY"
			, "STG_INR_SRC"."LOAD_DATE" AS "LOAD_DATE"
			, "STG_INR_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
			, "STG_INR_SRC"."CUSTOMERS_BK" AS "CUSTOMERS_BK"
			, "STG_INR_SRC"."SRC_BK" AS "SRC_BK"
			, "STG_INR_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
			, ROW_NUMBER()OVER(PARTITION BY "STG_INR_SRC"."CUSTOMERS_HKEY" ORDER BY "STG_INR_SRC"."LOAD_DATE") AS "DUMMY"
		FROM "MOTO_SALES_STG"."CUSTOMERS" "STG_INR_SRC"
		WHERE  "STG_INR_SRC"."RECORD_TYPE" = 'S'
	)
	SELECT 
		  "STG_SRC"."CUSTOMERS_HKEY" AS "CUSTOMERS_HKEY"
		, "STG_SRC"."LOAD_DATE" AS "LOAD_DATE"
		, "STG_SRC"."LOAD_CYCLE_ID" AS "LOAD_CYCLE_ID"
		, "STG_SRC"."CUSTOMERS_BK" AS "CUSTOMERS_BK"
		, "STG_SRC"."SRC_BK" AS "SRC_BK"
		, "STG_SRC"."RECORD_SOURCE" AS "RECORD_SOURCE"
	FROM "STG_SRC" "STG_SRC"
	LEFT OUTER JOIN "MOTO_DV_FL"."HUB_CUSTOMERS" "HUB_SRC" ON  "STG_SRC"."CUSTOMERS_HKEY" = "HUB_SRC"."CUSTOMERS_HKEY"
	WHERE  "STG_SRC"."DUMMY" = 1 AND "HUB_SRC"."CUSTOMERS_HKEY" is NULL
	;
END;


END;
$function$;
 
 
