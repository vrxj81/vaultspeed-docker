DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_parts_curr";
CREATE   VIEW "moto_dv_bv"."sat_sales_parts_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."parts_hkey" AS "parts_hkey"
		FROM "moto_dv_fl"."sat_sales_parts" "sat_curr"
		GROUP BY  "sat_curr"."parts_hkey"
	)
	SELECT 
		  "sat_src"."parts_hkey" AS "parts_hkey"
		, "sat_src"."part_language_code_seq" AS "part_language_code_seq"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."part_id" AS "part_id"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_parts" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."parts_hkey" = "curr_ld"."parts_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
