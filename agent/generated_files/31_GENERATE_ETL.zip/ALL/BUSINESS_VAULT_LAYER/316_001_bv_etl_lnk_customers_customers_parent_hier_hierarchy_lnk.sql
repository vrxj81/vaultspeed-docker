DROP VIEW IF EXISTS "moto_dv_bv"."lnk_customers_customers_parent_hier";
CREATE   VIEW "moto_dv_bv"."lnk_customers_customers_parent_hier"  AS 
	WITH RECURSIVE "all_view"("customers_parent_hkey") AS 
	( 
		SELECT 
			  "lnk_src"."customers_hkey" AS "customers_hkey"
			, "lnk_src"."customers_parent_hkey" AS "customers_parent_hkey"
			, "lnk_src"."load_date" AS "load_date"
			, "lnk_src"."load_cycle_id" AS "load_cycle_id"
		FROM "moto_dv_fl"."lnk_customers_customers_parent" "lnk_src"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_fk_src" ON  "hub_fk_src"."customers_hkey" = "lnk_src"."customers_parent_hkey"
		WHERE  "hub_fk_src"."load_cycle_id" = - 1 AND "lnk_src"."load_cycle_id" > 0
		UNION ALL 
		SELECT 
			  "lnk_src"."customers_hkey" AS "customers_hkey"
			, "lnk_src"."customers_parent_hkey" AS "customers_parent_hkey"
			, "lnk_src"."load_date" AS "load_date"
			, "lnk_src"."load_cycle_id" AS "load_cycle_id"
		FROM "moto_dv_fl"."lnk_customers_customers_parent" "lnk_src"
		INNER JOIN "all_view" "all_view" ON  "all_view"."customers_hkey" = "lnk_src"."customers_parent_hkey"
	)
	SELECT 
		  "all_view"."customers_hkey" AS "customers_hkey"
		, "all_view"."customers_parent_hkey" AS "customers_parent_hkey"
		, "all_view"."load_date" AS "load_date"
		, "all_view"."load_cycle_id" AS "load_cycle_id"
	FROM "all_view" "all_view"
	;

 
 
