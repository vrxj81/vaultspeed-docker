DROP VIEW IF EXISTS "moto_dv_bv"."lnk_products_products_rpid_hier";
CREATE   VIEW "moto_dv_bv"."lnk_products_products_rpid_hier"  AS 
	WITH RECURSIVE "all_view"("products_rpid_hkey") AS 
	( 
		SELECT 
			  "lnk_src"."products_hkey" AS "products_hkey"
			, "lnk_src"."products_rpid_hkey" AS "products_rpid_hkey"
			, "lnk_src"."load_date" AS "load_date"
			, "lnk_src"."load_cycle_id" AS "load_cycle_id"
		FROM "moto_dv_fl"."lnk_products_products_rpid" "lnk_src"
		INNER JOIN "moto_dv_fl"."hub_products" "hub_fk_src" ON  "hub_fk_src"."products_hkey" = "lnk_src"."products_rpid_hkey"
		WHERE  "hub_fk_src"."load_cycle_id" = - 1 AND "lnk_src"."load_cycle_id" > 0
		UNION ALL 
		SELECT 
			  "lnk_src"."products_hkey" AS "products_hkey"
			, "lnk_src"."products_rpid_hkey" AS "products_rpid_hkey"
			, "lnk_src"."load_date" AS "load_date"
			, "lnk_src"."load_cycle_id" AS "load_cycle_id"
		FROM "moto_dv_fl"."lnk_products_products_rpid" "lnk_src"
		INNER JOIN "all_view" "all_view" ON  "all_view"."products_hkey" = "lnk_src"."products_rpid_hkey"
	)
	SELECT 
		  "all_view"."products_hkey" AS "products_hkey"
		, "all_view"."products_rpid_hkey" AS "products_rpid_hkey"
		, "all_view"."load_date" AS "load_date"
		, "all_view"."load_cycle_id" AS "load_cycle_id"
	FROM "all_view" "all_view"
	;

 
 
