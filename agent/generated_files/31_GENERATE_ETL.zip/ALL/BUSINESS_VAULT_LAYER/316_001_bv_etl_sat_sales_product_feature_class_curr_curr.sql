DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_product_feature_class_curr";
CREATE   VIEW "moto_dv_bv"."sat_sales_product_feature_class_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."product_feature_class_hkey" AS "product_feature_class_hkey"
		FROM "moto_dv_fl"."sat_sales_product_feature_class" "sat_curr"
		GROUP BY  "sat_curr"."product_feature_class_hkey"
	)
	SELECT 
		  "sat_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."product_feature_class_id" AS "product_feature_class_id"
		, "sat_src"."product_feature_class_desc" AS "product_feature_class_desc"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_product_feature_class" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."product_feature_class_hkey" = "curr_ld"."product_feature_class_hkey" AND "sat_src"."load_date" = 
		"curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
