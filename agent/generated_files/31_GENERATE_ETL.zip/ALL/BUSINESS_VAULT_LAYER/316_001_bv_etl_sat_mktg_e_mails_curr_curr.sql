DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_e_mails_curr";
CREATE   VIEW "moto_dv_bv"."sat_mktg_e_mails_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."contacts_hkey" AS "contacts_hkey"
		FROM "moto_dv_fl"."sat_mktg_e_mails" "sat_curr"
		GROUP BY  "sat_curr"."contacts_hkey"
	)
	SELECT 
		  "sat_src"."contacts_hkey" AS "contacts_hkey"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."contact_id" AS "contact_id"
		, "sat_src"."name" AS "name"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_mktg_e_mails" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."contacts_hkey" = "curr_ld"."contacts_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
