DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_product_features_enddt";
CREATE   VIEW "moto_dv_bv"."sat_sales_product_features_enddt"  AS 
	SELECT 
		  "sat_src"."product_features_hkey" AS "product_features_hkey"
		, "sat_src"."product_feature_language_code_seq" AS "product_feature_language_code_seq"
		, "sat_src"."load_date" AS "load_date"
		, COALESCE(LEAD("sat_src"."load_date",1)OVER(PARTITION BY "sat_src"."product_features_hkey","sat_src"."product_feature_language_code_seq" ORDER BY "sat_src"."load_date")
			, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "end_load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."product_feature_id" AS "product_feature_id"
		, "sat_src"."product_feature_cat_id" AS "product_feature_cat_id"
		, "sat_src"."product_feature_description" AS "product_feature_description"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_product_features" "sat_src"
	;

 
 
