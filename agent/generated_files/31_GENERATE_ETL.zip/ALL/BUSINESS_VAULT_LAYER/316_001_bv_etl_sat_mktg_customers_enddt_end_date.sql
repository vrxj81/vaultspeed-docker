DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_customers_enddt";
CREATE   VIEW "moto_dv_bv"."sat_mktg_customers_enddt"  AS 
	SELECT 
		  "sat_src"."customers_hkey" AS "customers_hkey"
		, "sat_src"."load_date" AS "load_date"
		, COALESCE(LEAD("sat_src"."load_date",1)OVER(PARTITION BY "sat_src"."customers_hkey" ORDER BY "sat_src"."load_date")
			, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "end_load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."party_number" AS "party_number"
		, "sat_src"."address_number" AS "address_number"
		, "sat_src"."parent_party_number" AS "parent_party_number"
		, "sat_src"."comments" AS "comments"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_mktg_customers" "sat_src"
	;

 
 
