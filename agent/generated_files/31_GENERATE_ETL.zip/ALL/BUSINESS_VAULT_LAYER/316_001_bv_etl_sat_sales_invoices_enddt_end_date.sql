DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_invoices_enddt";
CREATE   VIEW "moto_dv_bv"."sat_sales_invoices_enddt"  AS 
	SELECT 
		  "sat_src"."invoices_hkey" AS "invoices_hkey"
		, "sat_src"."load_date" AS "load_date"
		, COALESCE(LEAD("sat_src"."load_date",1)OVER(PARTITION BY "sat_src"."invoices_hkey" ORDER BY "sat_src"."load_date")
			, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "end_load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."invoice_number" AS "invoice_number"
		, "sat_src"."invoice_customer_id" AS "invoice_customer_id"
		, "sat_src"."invoice_date" AS "invoice_date"
		, "sat_src"."amount" AS "amount"
		, "sat_src"."discount" AS "discount"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_invoices" "sat_src"
	;

 
 
