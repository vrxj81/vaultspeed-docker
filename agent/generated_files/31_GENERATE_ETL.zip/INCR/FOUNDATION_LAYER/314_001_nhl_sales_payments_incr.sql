CREATE OR REPLACE FUNCTION "moto_proc"."nhl_sales_payments_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- nhl_tgt

	INSERT INTO "moto_dv_fl"."nhl_sales_payments"(
		 "nhl_payments_hkey"
		,"invoices_hkey"
		,"customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"customer_number"
		,"invoice_number"
		,"transaction_id"
		,"date_time"
		,"amount"
		,"update_timestamp"
		,"record_source"
	)
	SELECT 
		  "stg_dl_src"."nhl_payments_hkey" AS "nhl_payments_hkey"
		, "stg_dl_src"."invoices_hkey" AS "invoices_hkey"
		, "stg_dl_src"."customers_hkey" AS "customers_hkey"
		, "stg_dl_src"."load_date" AS "load_date"
		, "stg_dl_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_dl_src"."customer_number" AS "customer_number"
		, "stg_dl_src"."invoice_number" AS "invoice_number"
		, "stg_dl_src"."transaction_id" AS "transaction_id"
		, "stg_dl_src"."date_time" AS "date_time"
		, "stg_dl_src"."amount" AS "amount"
		, "stg_dl_src"."update_timestamp" AS "update_timestamp"
		, "stg_dl_src"."record_source" AS "record_source"
	FROM "moto_sales_stg"."payments" "stg_dl_src"
	;
END;


END;
$function$;
 
 
