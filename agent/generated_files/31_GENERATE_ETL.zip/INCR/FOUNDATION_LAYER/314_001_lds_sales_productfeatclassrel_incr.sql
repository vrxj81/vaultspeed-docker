CREATE OR REPLACE FUNCTION "moto_proc"."lds_sales_productfeatclassrel_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lds_temp_tgt

	TRUNCATE TABLE "moto_sales_stg"."lds_sales_product_feat_class_rel_tmp"  CASCADE;

	INSERT INTO "moto_sales_stg"."lds_sales_product_feat_class_rel_tmp"(
		 "lnd_product_feat_class_rel_hkey"
		,"product_feature_class_hkey"
		,"product_features_hkey"
		,"products_hkey"
		,"product_id"
		,"product_feature_class_id"
		,"product_feature_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"record_type"
		,"source"
		,"equal"
		,"delete_flag"
		,"update_timestamp"
	)
	WITH "dist_stg" AS 
	( 
		SELECT 
			  "stg_dis_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
			, "stg_dis_src"."load_cycle_id" AS "load_cycle_id"
			, MIN("stg_dis_src"."load_date") AS "min_load_timestamp"
		FROM "moto_sales_stg"."product_feat_class_rel" "stg_dis_src"
		GROUP BY  "stg_dis_src"."lnd_product_feat_class_rel_hkey",  "stg_dis_src"."load_cycle_id"
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "stg_temp_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
			, "stg_temp_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, "stg_temp_src"."product_features_hkey" AS "product_features_hkey"
			, "stg_temp_src"."products_hkey" AS "products_hkey"
			, "stg_temp_src"."product_id" AS "product_id"
			, "stg_temp_src"."product_feature_class_id" AS "product_feature_class_id"
			, "stg_temp_src"."product_feature_id" AS "product_feature_id"
			, "stg_temp_src"."load_date" AS "load_date"
			, "stg_temp_src"."load_cycle_id" AS "load_cycle_id"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( TO_CHAR("stg_temp_src"."update_timestamp", 
				'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, "stg_temp_src"."record_type" AS "record_type"
			, 'STG' AS "source"
			, 1 AS "origin_id"
			, CASE WHEN "stg_temp_src"."jrn_flag" = 'D' THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
			, "stg_temp_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_stg"."product_feat_class_rel" "stg_temp_src"
		UNION ALL 
		SELECT 
			  "lds_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
			, "lnd_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, "lnd_src"."product_features_hkey" AS "product_features_hkey"
			, "lnd_src"."products_hkey" AS "products_hkey"
			, "lds_src"."product_id" AS "product_id"
			, "lds_src"."product_feature_class_id" AS "product_feature_class_id"
			, "lds_src"."product_feature_id" AS "product_feature_id"
			, "lds_src"."load_date" AS "load_date"
			, "lds_src"."load_cycle_id" AS "load_cycle_id"
			, MAX("lds_src"."load_date")OVER(PARTITION BY "lds_src"."lnd_product_feat_class_rel_hkey") AS "load_end_date"
			, "lds_src"."hash_diff" AS "hash_diff"
			, 'SAT' AS "record_type"
			, 'LDS' AS "source"
			, 0 AS "origin_id"
			, "lds_src"."delete_flag" AS "delete_flag"
			, "lds_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."lds_sales_product_feat_class_rel" "lds_src"
		INNER JOIN "moto_dv_fl"."lnd_product_feat_class_rel" "lnd_src" ON  "lds_src"."lnd_product_feat_class_rel_hkey" = "lnd_src"."lnd_product_feat_class_rel_hkey"
		INNER JOIN "dist_stg" "dist_stg" ON  "lds_src"."lnd_product_feat_class_rel_hkey" = "dist_stg"."lnd_product_feat_class_rel_hkey"
	)
	SELECT 
		  "temp_table_set"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "temp_table_set"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "temp_table_set"."product_features_hkey" AS "product_features_hkey"
		, "temp_table_set"."products_hkey" AS "products_hkey"
		, "temp_table_set"."product_id" AS "product_id"
		, "temp_table_set"."product_feature_class_id" AS "product_feature_class_id"
		, "temp_table_set"."product_feature_id" AS "product_feature_id"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."hash_diff" AS "hash_diff"
		, "temp_table_set"."record_type" AS "record_type"
		, "temp_table_set"."source" AS "source"
		, CASE WHEN "temp_table_set"."source" = 'STG' AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",'hex'),1)OVER(PARTITION BY "temp_table_set"."lnd_product_feat_class_rel_hkey" ORDER BY "temp_table_set"."load_date","temp_table_set"."origin_id")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."update_timestamp" AS "update_timestamp"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 'STG' OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 'LDS')
	;
END;


BEGIN -- lds_inur_tgt

	INSERT INTO "moto_dv_fl"."lds_sales_product_feat_class_rel"(
		 "lnd_product_feat_class_rel_hkey"
		,"product_id"
		,"product_feature_class_id"
		,"product_feature_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"update_timestamp"
	)
	SELECT 
		  "lds_temp_src_inur"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "lds_temp_src_inur"."product_id" AS "product_id"
		, "lds_temp_src_inur"."product_feature_class_id" AS "product_feature_class_id"
		, "lds_temp_src_inur"."product_feature_id" AS "product_feature_id"
		, "lds_temp_src_inur"."load_date" AS "load_date"
		, "lds_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "lds_temp_src_inur"."hash_diff" AS "hash_diff"
		, "lds_temp_src_inur"."delete_flag" AS "delete_flag"
		, "lds_temp_src_inur"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_stg"."lds_sales_product_feat_class_rel_tmp" "lds_temp_src_inur"
	WHERE  "lds_temp_src_inur"."source" = 'STG' AND "lds_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
