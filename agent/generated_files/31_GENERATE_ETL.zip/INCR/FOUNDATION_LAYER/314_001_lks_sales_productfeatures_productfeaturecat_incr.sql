CREATE OR REPLACE FUNCTION "moto_proc"."lks_sales_productfeatures_productfeaturecat_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lks_temp_tgt

	TRUNCATE TABLE "moto_sales_stg"."lks_sales_productfeatures_productfeaturecat_tmp"  CASCADE;

	INSERT INTO "moto_sales_stg"."lks_sales_productfeatures_productfeaturecat_tmp"(
		 "lnk_productfeatures_productfeaturecat_hkey"
		,"product_feature_cat_hkey"
		,"product_features_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_type"
		,"source"
		,"equal"
		,"delete_flag"
		,"product_feature_id"
		,"product_feature_cat_id"
	)
	WITH "dist_stg" AS 
	( 
		SELECT 
			  "stg_dis_src"."product_features_hkey" AS "product_features_hkey"
			, "stg_dis_src"."load_cycle_id" AS "load_cycle_id"
			, MIN("stg_dis_src"."load_date") AS "min_load_timestamp"
		FROM "moto_sales_stg"."product_features" "stg_dis_src"
		GROUP BY  "stg_dis_src"."product_features_hkey",  "stg_dis_src"."load_cycle_id"
	)
	, "dist_del" AS 
	( 
		SELECT DISTINCT 
 			  "stg_del_src"."product_features_hkey" AS "product_features_hkey"
		FROM "moto_sales_stg"."product_features" "stg_del_src"
		WHERE  "stg_del_src"."jrn_flag" = 'D'
	)
	, "del_sat" AS 
	( 
		SELECT 
			  "sat_src"."product_features_hkey" AS "product_features_hkey"
			, "sat_src"."product_feature_language_code_seq" AS "product_feature_language_code_seq"
			, "sat_src"."load_date" AS "load_date"
			, "sat_src"."delete_flag" AS "delete_flag"
			, ROW_NUMBER()OVER(PARTITION BY "sat_src"."product_features_hkey" ORDER BY "sat_src"."load_date" DESC) AS "dummy"
		FROM "moto_dv_fl"."sat_sales_product_features" "sat_src"
		INNER JOIN "dist_del" "dist_del" ON  "sat_src"."product_features_hkey" = "dist_del"."product_features_hkey"
	)
	, "all_rel_del" AS 
	( 
		SELECT 
			  "stg_rd_src"."product_features_hkey" AS "product_features_hkey"
			, "stg_rd_src"."product_feature_language_code_seq" AS "product_feature_language_code_seq"
			, "stg_rd_src"."load_date" AS "load_date"
			, CASE WHEN "stg_rd_src"."jrn_flag" = 'D' THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
		FROM "moto_sales_stg"."product_features" "stg_rd_src"
		INNER JOIN "dist_del" "dist_del" ON  "stg_rd_src"."product_features_hkey" = "dist_del"."product_features_hkey"
		UNION 
		SELECT 
			  "del_sat"."product_features_hkey" AS "product_features_hkey"
			, "del_sat"."product_feature_language_code_seq" AS "product_feature_language_code_seq"
			, "del_sat"."load_date" AS "load_date"
			, "del_sat"."delete_flag" AS "delete_flag"
		FROM "del_sat" "del_sat"
		WHERE  "del_sat"."dummy" = 1 AND "del_sat"."delete_flag" = 'N'::text
	)
	, "calc_interval" AS 
	( 
		SELECT 
			  "all_rel_del"."product_features_hkey" AS "product_features_hkey"
			, "all_rel_del"."load_date" AS "load_date"
			, "all_rel_del"."delete_flag" AS "delete_flag"
			, COALESCE(LEAD("all_rel_del"."load_date")OVER(PARTITION BY "all_rel_del"."product_features_hkey", 
				"all_rel_del"."product_feature_language_code_seq" ORDER BY "all_rel_del"."load_date"), TO_TIMESTAMP('31/12/2999 23:59:59' , 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "end_interval"
		FROM "all_rel_del" "all_rel_del"
	)
	, "del_keys" AS 
	( 
		SELECT 
			  "all_rel_del"."product_features_hkey" AS "product_features_hkey"
			, "all_rel_del"."load_date" AS "load_date"
		FROM "calc_interval" "calc_interval"
		RIGHT OUTER JOIN "all_rel_del" "all_rel_del" ON  "calc_interval"."product_features_hkey" = "all_rel_del"."product_features_hkey" AND "all_rel_del"."load_date" >=
			 "calc_interval"."load_date" AND "all_rel_del"."load_date" < "calc_interval"."end_interval" AND "calc_interval"."delete_flag" = 'N'::text
		WHERE  "calc_interval"."product_features_hkey" IS NULL AND "all_rel_del"."delete_flag" = 'Y'::text
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "stg_temp_src"."lnk_productfeatures_productfeaturecat_hkey" AS "lnk_productfeatures_productfeaturecat_hkey"
			, "stg_temp_src"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
			, "stg_temp_src"."product_features_hkey" AS "product_features_hkey"
			, "stg_temp_src"."load_date" AS "load_date"
			, "stg_temp_src"."load_cycle_id" AS "load_cycle_id"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, "stg_temp_src"."record_type" AS "record_type"
			, 'STG' AS "source"
			, 1 AS "origin_id"
			, CASE WHEN "stg_temp_src"."jrn_flag" = 'D' AND "del_keys"."product_features_hkey" IS NOT NULL THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
			, "stg_temp_src"."product_feature_id" AS "product_feature_id"
			, "stg_temp_src"."product_feature_cat_id" AS "product_feature_cat_id"
		FROM "moto_sales_stg"."product_features" "stg_temp_src"
		LEFT OUTER JOIN "del_keys" "del_keys" ON  "stg_temp_src"."product_features_hkey" = "del_keys"."product_features_hkey" AND "stg_temp_src"."load_date" = 
			"del_keys"."load_date"
		UNION 
		SELECT 
			  "lks_src"."lnk_productfeatures_productfeaturecat_hkey" AS "lnk_productfeatures_productfeaturecat_hkey"
			, "lnk_src"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
			, "lnk_src"."product_features_hkey" AS "product_features_hkey"
			, "lks_src"."load_date" AS "load_date"
			, "lks_src"."load_cycle_id" AS "load_cycle_id"
			, MAX("lks_src"."load_date")OVER(PARTITION BY "lnk_src"."product_features_hkey") AS "load_end_date"
			, 'SAT' AS "record_type"
			, 'LKS' AS "source"
			, 0 AS "origin_id"
			, "lks_src"."delete_flag" AS "delete_flag"
			, "lks_src"."product_feature_id" AS "product_feature_id"
			, "lks_src"."product_feature_cat_id" AS "product_feature_cat_id"
		FROM "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat" "lks_src"
		INNER JOIN "moto_dv_fl"."lnk_productfeatures_productfeaturecat" "lnk_src" ON  "lks_src"."lnk_productfeatures_productfeaturecat_hkey" = "lnk_src"."lnk_productfeatures_productfeaturecat_hkey"
		INNER JOIN "dist_stg" "dist_stg" ON  "lnk_src"."product_features_hkey" = "dist_stg"."product_features_hkey"
	)
	SELECT 
		  "temp_table_set"."lnk_productfeatures_productfeaturecat_hkey" AS "lnk_productfeatures_productfeaturecat_hkey"
		, "temp_table_set"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
		, "temp_table_set"."product_features_hkey" AS "product_features_hkey"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."record_type" AS "record_type"
		, "temp_table_set"."source" AS "source"
		, CASE WHEN "temp_table_set"."source" = 'STG' AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."product_feature_cat_hkey",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."product_feature_cat_hkey",'hex'),1)OVER(PARTITION BY "temp_table_set"."product_features_hkey" ORDER BY "temp_table_set"."load_date","temp_table_set"."origin_id")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."product_feature_id" AS "product_feature_id"
		, "temp_table_set"."product_feature_cat_id" AS "product_feature_cat_id"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 'STG' OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 'LKS')
	;
END;


BEGIN -- lks_inur_tgt

	INSERT INTO "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat"(
		 "lnk_productfeatures_productfeaturecat_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"product_feature_id"
		,"product_feature_cat_id"
	)
	SELECT 
		  "lks_temp_src_inur"."lnk_productfeatures_productfeaturecat_hkey" AS "lnk_productfeatures_productfeaturecat_hkey"
		, "lks_temp_src_inur"."load_date" AS "load_date"
		, "lks_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "lks_temp_src_inur"."delete_flag" AS "delete_flag"
		, "lks_temp_src_inur"."product_feature_id" AS "product_feature_id"
		, "lks_temp_src_inur"."product_feature_cat_id" AS "product_feature_cat_id"
	FROM "moto_sales_stg"."lks_sales_productfeatures_productfeaturecat_tmp" "lks_temp_src_inur"
	WHERE  "lks_temp_src_inur"."source" = 'STG' AND "lks_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
