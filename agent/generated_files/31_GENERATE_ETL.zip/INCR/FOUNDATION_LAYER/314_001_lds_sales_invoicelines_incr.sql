CREATE OR REPLACE FUNCTION "moto_proc"."lds_sales_invoicelines_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lds_temp_tgt

	TRUNCATE TABLE "moto_sales_stg"."lds_sales_invoice_lines_tmp"  CASCADE;

	INSERT INTO "moto_sales_stg"."lds_sales_invoice_lines_tmp"(
		 "lnd_invoice_lines_hkey"
		,"invoices_hkey"
		,"parts_hkey"
		,"products_hkey"
		,"invoice_number"
		,"part_id"
		,"product_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"record_type"
		,"source"
		,"equal"
		,"delete_flag"
		,"invoice_line_number_seq"
		,"amount"
		,"quantity"
		,"unit_price"
		,"update_timestamp"
	)
	WITH "dist_stg" AS 
	( 
		SELECT 
			  "stg_dis_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
			, "stg_dis_src"."load_cycle_id" AS "load_cycle_id"
			, "stg_dis_src"."invoice_line_number_seq" AS "invoice_line_number_seq"
			, MIN("stg_dis_src"."load_date") AS "min_load_timestamp"
		FROM "moto_sales_stg"."invoice_lines" "stg_dis_src"
		GROUP BY  "stg_dis_src"."lnd_invoice_lines_hkey",  "stg_dis_src"."load_cycle_id",  "stg_dis_src"."invoice_line_number_seq"
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "stg_temp_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
			, "stg_temp_src"."invoices_hkey" AS "invoices_hkey"
			, "stg_temp_src"."parts_hkey" AS "parts_hkey"
			, "stg_temp_src"."products_hkey" AS "products_hkey"
			, "stg_temp_src"."invoice_number" AS "invoice_number"
			, "stg_temp_src"."part_id" AS "part_id"
			, "stg_temp_src"."product_id" AS "product_id"
			, "stg_temp_src"."load_date" AS "load_date"
			, "stg_temp_src"."load_cycle_id" AS "load_cycle_id"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_temp_src"."amount"::text),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( "stg_temp_src"."quantity"::text)
				,'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( "stg_temp_src"."unit_price"::text),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_temp_src"."update_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, "stg_temp_src"."record_type" AS "record_type"
			, 'STG' AS "source"
			, 1 AS "origin_id"
			, CASE WHEN "stg_temp_src"."jrn_flag" = 'D' THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
			, "stg_temp_src"."invoice_line_number_seq" AS "invoice_line_number_seq"
			, "stg_temp_src"."amount" AS "amount"
			, "stg_temp_src"."quantity" AS "quantity"
			, "stg_temp_src"."unit_price" AS "unit_price"
			, "stg_temp_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_stg"."invoice_lines" "stg_temp_src"
		UNION ALL 
		SELECT 
			  "lds_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
			, "lnd_src"."invoices_hkey" AS "invoices_hkey"
			, "lnd_src"."parts_hkey" AS "parts_hkey"
			, "lnd_src"."products_hkey" AS "products_hkey"
			, "lds_src"."invoice_number" AS "invoice_number"
			, "lds_src"."part_id" AS "part_id"
			, "lds_src"."product_id" AS "product_id"
			, "lds_src"."load_date" AS "load_date"
			, "lds_src"."load_cycle_id" AS "load_cycle_id"
			, MAX("lds_src"."load_date")OVER(PARTITION BY "lds_src"."lnd_invoice_lines_hkey","lds_src"."invoice_line_number_seq") AS "load_end_date"
			, "lds_src"."hash_diff" AS "hash_diff"
			, 'SAT' AS "record_type"
			, 'LDS' AS "source"
			, 0 AS "origin_id"
			, "lds_src"."delete_flag" AS "delete_flag"
			, "lds_src"."invoice_line_number_seq" AS "invoice_line_number_seq"
			, "lds_src"."amount" AS "amount"
			, "lds_src"."quantity" AS "quantity"
			, "lds_src"."unit_price" AS "unit_price"
			, "lds_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."lds_sales_invoice_lines" "lds_src"
		INNER JOIN "moto_dv_fl"."lnd_invoice_lines" "lnd_src" ON  "lds_src"."lnd_invoice_lines_hkey" = "lnd_src"."lnd_invoice_lines_hkey"
		INNER JOIN "dist_stg" "dist_stg" ON  "lds_src"."lnd_invoice_lines_hkey" = "dist_stg"."lnd_invoice_lines_hkey" AND "lds_src"."invoice_line_number_seq" =
			 "dist_stg"."invoice_line_number_seq"
	)
	SELECT 
		  "temp_table_set"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
		, "temp_table_set"."invoices_hkey" AS "invoices_hkey"
		, "temp_table_set"."parts_hkey" AS "parts_hkey"
		, "temp_table_set"."products_hkey" AS "products_hkey"
		, "temp_table_set"."invoice_number" AS "invoice_number"
		, "temp_table_set"."part_id" AS "part_id"
		, "temp_table_set"."product_id" AS "product_id"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."hash_diff" AS "hash_diff"
		, "temp_table_set"."record_type" AS "record_type"
		, "temp_table_set"."source" AS "source"
		, CASE WHEN "temp_table_set"."source" = 'STG' AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",'hex'),1)OVER(PARTITION BY "temp_table_set"."lnd_invoice_lines_hkey","temp_table_set"."invoice_line_number_seq" ORDER BY "temp_table_set"."load_date","temp_table_set"."origin_id")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."invoice_line_number_seq" AS "invoice_line_number_seq"
		, "temp_table_set"."amount" AS "amount"
		, "temp_table_set"."quantity" AS "quantity"
		, "temp_table_set"."unit_price" AS "unit_price"
		, "temp_table_set"."update_timestamp" AS "update_timestamp"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 'STG' OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 'LDS')
	;
END;


BEGIN -- lds_inur_tgt

	INSERT INTO "moto_dv_fl"."lds_sales_invoice_lines"(
		 "lnd_invoice_lines_hkey"
		,"invoice_number"
		,"part_id"
		,"product_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"invoice_line_number_seq"
		,"amount"
		,"quantity"
		,"unit_price"
		,"update_timestamp"
	)
	SELECT 
		  "lds_temp_src_inur"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
		, "lds_temp_src_inur"."invoice_number" AS "invoice_number"
		, "lds_temp_src_inur"."part_id" AS "part_id"
		, "lds_temp_src_inur"."product_id" AS "product_id"
		, "lds_temp_src_inur"."load_date" AS "load_date"
		, "lds_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "lds_temp_src_inur"."hash_diff" AS "hash_diff"
		, "lds_temp_src_inur"."delete_flag" AS "delete_flag"
		, "lds_temp_src_inur"."invoice_line_number_seq" AS "invoice_line_number_seq"
		, "lds_temp_src_inur"."amount" AS "amount"
		, "lds_temp_src_inur"."quantity" AS "quantity"
		, "lds_temp_src_inur"."unit_price" AS "unit_price"
		, "lds_temp_src_inur"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_stg"."lds_sales_invoice_lines_tmp" "lds_temp_src_inur"
	WHERE  "lds_temp_src_inur"."source" = 'STG' AND "lds_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
