CREATE OR REPLACE FUNCTION "moto_proc"."lnd_sales_invoicelines_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lnd_tgt

	INSERT INTO "moto_dv_fl"."lnd_invoice_lines"(
		 "lnd_invoice_lines_hkey"
		,"load_date"
		,"load_cycle_id"
		,"invoices_hkey"
		,"parts_hkey"
		,"products_hkey"
		,"record_source"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, "stg_inr_src"."invoices_hkey" AS "invoices_hkey"
			, "stg_inr_src"."parts_hkey" AS "parts_hkey"
			, "stg_inr_src"."products_hkey" AS "products_hkey"
			, "stg_inr_src"."record_source" AS "record_source"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."lnd_invoice_lines_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_sales_stg"."invoice_lines" "stg_inr_src"
		WHERE  "stg_inr_src"."record_type" = 'S'
	)
	SELECT 
		  "stg_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."invoices_hkey" AS "invoices_hkey"
		, "stg_src"."parts_hkey" AS "parts_hkey"
		, "stg_src"."products_hkey" AS "products_hkey"
		, "stg_src"."record_source" AS "record_source"
	FROM "stg_src" "stg_src"
	LEFT OUTER JOIN "moto_dv_fl"."lnd_invoice_lines" "lnd_src" ON  "stg_src"."lnd_invoice_lines_hkey" = "lnd_src"."lnd_invoice_lines_hkey"
	WHERE  "lnd_src"."lnd_invoice_lines_hkey" IS NULL AND "stg_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
