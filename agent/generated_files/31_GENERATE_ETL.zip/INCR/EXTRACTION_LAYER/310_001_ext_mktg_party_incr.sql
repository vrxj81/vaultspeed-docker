CREATE OR REPLACE FUNCTION "moto_proc"."ext_mktg_party_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_mktg_ext"."party"  CASCADE;

	INSERT INTO "moto_mktg_ext"."party"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"party_number"
		,"parent_party_number"
		,"address_number"
		,"name_bk"
		,"birthdate_bk"
		,"gender_bk"
		,"party_type_code_bk"
		,"name"
		,"birthdate"
		,"gender"
		,"party_type_code"
		,"comments"
		,"update_timestamp"
	)
	WITH "calculate_bk" AS 
	( 
		SELECT 
			  "lci_src"."load_cycle_id" AS "load_cycle_id"
			, CURRENT_TIMESTAMP + row_number() over (order by "lci_src"."load_date") * interval'2 microsecond'   AS "load_date"
			, "mex_src"."attribute_varchar" AS "jrn_flag"
			, "tdfv_src"."record_type" AS "record_type"
			, "tdfv_src"."party_number" AS "party_number"
			, "tdfv_src"."parent_party_number" AS "parent_party_number"
			, "tdfv_src"."address_number" AS "address_number"
			, COALESCE(UPPER(REPLACE(TRIM( "tdfv_src"."name"),'#','\' || '#')),"mex_src"."key_attribute_varchar") AS "name_bk"
			, COALESCE(UPPER( TO_CHAR("tdfv_src"."birthdate", 'DD/MM/YYYY'::varchar)),"mex_src"."key_attribute_date") AS "birthdate_bk"
			, COALESCE(UPPER(REPLACE(TRIM( "tdfv_src"."gender"),'#','\' || '#')),"mex_src"."key_attribute_character") AS "gender_bk"
			, COALESCE(UPPER(REPLACE(TRIM( "tdfv_src"."party_type_code"),'#','\' || '#')),"mex_src"."key_attribute_character") AS "party_type_code_bk"
			, "tdfv_src"."name" AS "name"
			, "tdfv_src"."birthdate" AS "birthdate"
			, "tdfv_src"."gender" AS "gender"
			, "tdfv_src"."party_type_code" AS "party_type_code"
			, "tdfv_src"."comments" AS "comments"
			, "tdfv_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_dfv"."vw_party" "tdfv_src"
		INNER JOIN "moto_mktg_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."party_number" AS "party_number"
		, "calculate_bk"."parent_party_number" AS "parent_party_number"
		, "calculate_bk"."address_number" AS "address_number"
		, "calculate_bk"."name_bk" AS "name_bk"
		, "calculate_bk"."birthdate_bk" AS "birthdate_bk"
		, "calculate_bk"."gender_bk" AS "gender_bk"
		, "calculate_bk"."party_type_code_bk" AS "party_type_code_bk"
		, "calculate_bk"."name" AS "name"
		, "calculate_bk"."birthdate" AS "birthdate"
		, "calculate_bk"."gender" AS "gender"
		, "calculate_bk"."party_type_code" AS "party_type_code"
		, "calculate_bk"."comments" AS "comments"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
