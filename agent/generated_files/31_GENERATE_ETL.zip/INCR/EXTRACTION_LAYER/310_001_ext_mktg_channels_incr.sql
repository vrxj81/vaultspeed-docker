CREATE OR REPLACE FUNCTION "moto_proc"."ext_mktg_channels_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_mktg_ext"."channels"  CASCADE;

	INSERT INTO "moto_mktg_ext"."channels"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"channel_id"
		,"channel_code_bk"
		,"channel_description"
		,"update_timestamp"
	)
	WITH "calculate_bk" AS 
	( 
		SELECT 
			  "lci_src"."load_cycle_id" AS "load_cycle_id"
			, CURRENT_TIMESTAMP + row_number() over (order by "lci_src"."load_date") * interval'2 microsecond'   AS "load_date"
			, "mex_src"."attribute_varchar" AS "jrn_flag"
			, "tdfv_src"."record_type" AS "record_type"
			, "tdfv_src"."channel_id" AS "channel_id"
			, COALESCE(UPPER(REPLACE(TRIM( "tdfv_src"."channel_code"),'#','\' || '#')),"mex_src"."key_attribute_varchar") AS "channel_code_bk"
			, "tdfv_src"."channel_description" AS "channel_description"
			, "tdfv_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_dfv"."vw_channels" "tdfv_src"
		INNER JOIN "moto_mktg_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."channel_id" AS "channel_id"
		, "calculate_bk"."channel_code_bk" AS "channel_code_bk"
		, "calculate_bk"."channel_description" AS "channel_description"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
