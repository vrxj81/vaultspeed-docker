CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_addresses_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_tgt

	TRUNCATE TABLE "moto_sales_stg"."addresses"  CASCADE;

	INSERT INTO "moto_sales_stg"."addresses"(
		 "addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"address_number"
		,"street_name_bk"
		,"street_number_bk"
		,"postal_code_bk"
		,"city_bk"
		,"coordinates"
		,"update_timestamp"
	)
	SELECT 
		  DIGEST( "ext_src"."street_name_bk" || '#' ||  "ext_src"."street_number_bk" || '#' ||  "ext_src"."postal_code_bk" || 
			'#' ||  "ext_src"."city_bk" || '#' ,'SHA1') AS "addresses_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.addresses' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."address_number" AS "address_number"
		, "ext_src"."street_name_bk" AS "street_name_bk"
		, "ext_src"."street_number_bk" AS "street_number_bk"
		, "ext_src"."postal_code_bk" AS "postal_code_bk"
		, "ext_src"."city_bk" AS "city_bk"
		, "ext_src"."coordinates" AS "coordinates"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."addresses" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	;
END;


END;
$function$;
 
 
