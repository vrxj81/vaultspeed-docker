CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_mktg_campaignmotorcycles_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- stg_dl_tgt

	TRUNCATE TABLE "moto_mktg_stg"."campaign_motorcycles"  CASCADE;

	INSERT INTO "moto_mktg_stg"."campaign_motorcycles"(
		 "lnd_campaign_motorcycles_hkey"
		,"products_hkey"
		,"campaigns_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"campaign_code"
		,"campaign_start_date"
		,"motorcycle_id"
		,"campaign_code_fk_campaignstartdate_bk"
		,"motorcycle_class_desc"
		,"motorcycle_subclass_desc"
		,"motorcycle_emotion_desc"
		,"motorcycle_comment"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."motorcycle_id" AS "motorcycle_id"
		FROM "moto_mktg_ext"."campaign_motorcycles" "ext_dis_io_src1"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."products_hkey" AS "products_hkey"
			, "sat_io_src1"."motorcycle_id" AS "motorcycle_id"
			, MAX("sat_io_src1"."load_date") AS "load_date"
		FROM "moto_dv_fl"."sat_mktg_products" "sat_io_src1"
		INNER JOIN "dist_io_fk1" "dist_io_fk1" ON  "dist_io_fk1"."motorcycle_id" = "sat_io_src1"."motorcycle_id"
		GROUP BY  "sat_io_src1"."products_hkey",  "sat_io_src1"."motorcycle_id"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."motorcycle_id" AS "motorcycle_id"
		FROM "moto_mktg_ext"."campaign_motorcycles" "ext_dis_src1"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  "hub_src1"."product_cc_bk" AS "motorcycle_cc_bk"
			, "hub_src1"."product_et_code_bk" AS "motorcycle_et_code_bk"
			, "hub_src1"."product_part_code_bk" AS "motorcycle_part_code_bk"
			, "dist_fk1"."motorcycle_id" AS "motorcycle_id"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."motorcycle_id" = "sat_src1"."motorcycle_id"
		INNER JOIN "moto_dv_fl"."hub_products" "hub_src1" ON  "hub_src1"."products_hkey" = "sat_src1"."products_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
			, "ext_fkbk_src1"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
			, "ext_fkbk_src1"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
			, "dist_fk1"."motorcycle_id" AS "motorcycle_id"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_mktg_ext"."motorcycles" "ext_fkbk_src1" ON  "dist_fk1"."motorcycle_id" = "ext_fkbk_src1"."motorcycle_id"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
			, "prep_find_bk_fk1"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
			, "prep_find_bk_fk1"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
			, "prep_find_bk_fk1"."motorcycle_id" AS "motorcycle_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."motorcycle_id" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
			, "order_bk_fk1"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
			, "order_bk_fk1"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
			, "order_bk_fk1"."motorcycle_id" AS "motorcycle_id"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	SELECT 
		  DIGEST(  COALESCE("find_bk_fk1"."motorcycle_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk1"."motorcycle_et_code_bk",
			"mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk1"."motorcycle_part_code_bk","mex_src"."key_attribute_varchar")|| '#' || "ext_src"."campaign_code_fk_campaignstartdate_bk" || '#'  ,'SHA1') AS "lnd_campaign_motorcycles_hkey"
		, DIGEST( COALESCE("find_bk_fk1"."motorcycle_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk1"."motorcycle_et_code_bk",
			"mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk1"."motorcycle_part_code_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "products_hkey"
		, DIGEST( "ext_src"."campaign_code_fk_campaignstartdate_bk" || '#' ,'SHA1') AS "campaigns_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'mm.campaign_motorcycles' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."campaign_code" AS "campaign_code"
		, "ext_src"."campaign_start_date" AS "campaign_start_date"
		, "ext_src"."motorcycle_id" AS "motorcycle_id"
		, "ext_src"."campaign_code_fk_campaignstartdate_bk" AS "campaign_code_fk_campaignstartdate_bk"
		, "ext_src"."motorcycle_class_desc" AS "motorcycle_class_desc"
		, "ext_src"."motorcycle_subclass_desc" AS "motorcycle_subclass_desc"
		, "ext_src"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
		, "ext_src"."motorcycle_comment" AS "motorcycle_comment"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_mktg_ext"."campaign_motorcycles" "ext_src"
	INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."motorcycle_id" = "find_bk_fk1"."motorcycle_id"
	;
END;


END;
$function$;
 
 
