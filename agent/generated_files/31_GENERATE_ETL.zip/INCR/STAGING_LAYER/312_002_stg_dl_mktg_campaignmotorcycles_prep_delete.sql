CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_mktg_campaignmotorcycles_prep_delete"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- stg_dl_prep_del_tgt

	INSERT INTO "moto_mktg_stg"."campaign_motorcycles"(
		 "lnd_campaign_motorcycles_hkey"
		,"campaigns_hkey"
		,"products_hkey"
		,"jrn_flag"
		,"record_type"
		,"load_cycle_id"
		,"load_date"
		,"campaign_code"
		,"campaign_start_date"
		,"motorcycle_id"
		,"campaign_code_fk_campaignstartdate_bk"
		,"motorcycle_class_desc"
		,"motorcycle_subclass_desc"
		,"update_timestamp"
		,"motorcycle_emotion_desc"
		,"motorcycle_comment"
	)
	WITH "lds_src1" AS 
	( 
		SELECT 
			  "lds_ed_src1"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
			, "lds_ed_src1"."campaign_code" AS "campaign_code"
			, "lds_ed_src1"."campaign_start_date" AS "campaign_start_date"
			, "lds_ed_src1"."motorcycle_id" AS "motorcycle_id"
			, COALESCE(LEAD("lds_ed_src1"."load_date")OVER(PARTITION BY "lds_ed_src1"."lnd_campaign_motorcycles_hkey" ORDER BY "lds_ed_src1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "lds_ed_src1"."delete_flag" AS "delete_flag"
			, "lds_ed_src1"."load_cycle_id" AS "load_cycle_id"
			, "lds_ed_src1"."motorcycle_class_desc" AS "motorcycle_class_desc"
			, "lds_ed_src1"."motorcycle_subclass_desc" AS "motorcycle_subclass_desc"
			, "lds_ed_src1"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."lds_mktg_campaign_motorcycles_class" "lds_ed_src1"
	)
	, "lds_src2" AS 
	( 
		SELECT 
			  "lds_ed_src2"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
			, "lds_ed_src2"."campaign_code" AS "campaign_code"
			, "lds_ed_src2"."campaign_start_date" AS "campaign_start_date"
			, "lds_ed_src2"."motorcycle_id" AS "motorcycle_id"
			, COALESCE(LEAD("lds_ed_src2"."load_date")OVER(PARTITION BY "lds_ed_src2"."lnd_campaign_motorcycles_hkey" ORDER BY "lds_ed_src2"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "lds_ed_src2"."delete_flag" AS "delete_flag"
			, "lds_ed_src2"."load_cycle_id" AS "load_cycle_id"
			, "lds_ed_src2"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
			, "lds_ed_src2"."motorcycle_comment" AS "motorcycle_comment"
			, "lds_ed_src2"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" "lds_ed_src2"
	)
	SELECT 
		  "lnd_src"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
		, "lnd_src"."campaigns_hkey" AS "campaigns_hkey"
		, "lnd_src"."products_hkey" AS "products_hkey"
		, 'D' AS "jrn_flag"
		, 'S' AS "record_type"
		, "lci_src"."load_cycle_id" AS "load_cycle_id"
		, "lci_src"."load_date" AS "load_date"
		, "lds_src1"."campaign_code" AS "campaign_code"
		, "lds_src1"."campaign_start_date" AS "campaign_start_date"
		, "lds_src1"."motorcycle_id" AS "motorcycle_id"
		, UPPER(REPLACE(TRIM("lds_src1"."campaign_code"),'#','\' || '#')) AS "campaign_code_fk_campaignstartdate_bk"
		, "lds_src1"."motorcycle_class_desc" AS "motorcycle_class_desc"
		, "lds_src1"."motorcycle_subclass_desc" AS "motorcycle_subclass_desc"
		, "lds_src1"."update_timestamp" AS "update_timestamp"
		, "lds_src2"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
		, "lds_src2"."motorcycle_comment" AS "motorcycle_comment"
	FROM "moto_dv_fl"."lnd_campaign_motorcycles" "lnd_src"
	INNER JOIN "lds_src1" "lds_src1" ON  "lds_src1"."lnd_campaign_motorcycles_hkey" = "lnd_src"."lnd_campaign_motorcycles_hkey" AND "lds_src1"."load_end_date" =
		TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar) AND "lds_src1"."delete_flag" = 'N'::text
	INNER JOIN "lds_src2" "lds_src2" ON  "lds_src2"."lnd_campaign_motorcycles_hkey" = "lnd_src"."lnd_campaign_motorcycles_hkey" AND "lds_src2"."load_end_date" =
		TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar) AND "lds_src2"."delete_flag" = 'N'::text
	LEFT OUTER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  "lnd_src"."load_cycle_id"::text = "mex_src"."load_cycle_id"
	INNER JOIN "moto_mktg_mtd"."load_cycle_info" "lci_src" ON  1 = 1
	LEFT OUTER JOIN "moto_mktg_stg"."campaign_motorcycles" "stg_dl_src" ON  "lnd_src"."lnd_campaign_motorcycles_hkey" = "stg_dl_src"."lnd_campaign_motorcycles_hkey"
	INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src_bk" ON  1 = 1
	WHERE  "stg_dl_src"."load_cycle_id" IS NULL AND "mex_src"."load_cycle_id" IS NULL AND "mex_src_bk"."record_type" = 'N'
	;
END;


END;
$function$;
 
 
