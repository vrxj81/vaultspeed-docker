CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_sales_productfeatclassrel_prep_delete"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_dl_prep_del_tgt

	INSERT INTO "moto_sales_stg"."product_feat_class_rel"(
		 "lnd_product_feat_class_rel_hkey"
		,"product_feature_class_hkey"
		,"product_features_hkey"
		,"products_hkey"
		,"jrn_flag"
		,"record_type"
		,"load_cycle_id"
		,"load_date"
		,"product_feature_id"
		,"product_id"
		,"product_feature_class_id"
		,"update_timestamp"
	)
	WITH "lds_src1" AS 
	( 
		SELECT 
			  "lds_ed_src1"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
			, "lds_ed_src1"."product_id" AS "product_id"
			, "lds_ed_src1"."product_feature_class_id" AS "product_feature_class_id"
			, "lds_ed_src1"."product_feature_id" AS "product_feature_id"
			, COALESCE(LEAD("lds_ed_src1"."load_date")OVER(PARTITION BY "lds_ed_src1"."lnd_product_feat_class_rel_hkey" ORDER BY "lds_ed_src1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "lds_ed_src1"."delete_flag" AS "delete_flag"
			, "lds_ed_src1"."load_cycle_id" AS "load_cycle_id"
			, "lds_ed_src1"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."lds_sales_product_feat_class_rel" "lds_ed_src1"
	)
	SELECT 
		  "lnd_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "lnd_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "lnd_src"."product_features_hkey" AS "product_features_hkey"
		, "lnd_src"."products_hkey" AS "products_hkey"
		, 'D' AS "jrn_flag"
		, 'S' AS "record_type"
		, "lci_src"."load_cycle_id" AS "load_cycle_id"
		, "lci_src"."load_date" AS "load_date"
		, "lds_src1"."product_feature_id" AS "product_feature_id"
		, "lds_src1"."product_id" AS "product_id"
		, "lds_src1"."product_feature_class_id" AS "product_feature_class_id"
		, "lds_src1"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."lnd_product_feat_class_rel" "lnd_src"
	INNER JOIN "lds_src1" "lds_src1" ON  "lds_src1"."lnd_product_feat_class_rel_hkey" = "lnd_src"."lnd_product_feat_class_rel_hkey" AND "lds_src1"."load_end_date" =
		TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar) AND "lds_src1"."delete_flag" = 'N'::text
	LEFT OUTER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "lnd_src"."load_cycle_id"::text = "mex_src"."load_cycle_id"
	INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
	LEFT OUTER JOIN "moto_sales_stg"."product_feat_class_rel" "stg_dl_src" ON  "lnd_src"."lnd_product_feat_class_rel_hkey" = "stg_dl_src"."lnd_product_feat_class_rel_hkey"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src_bk" ON  1 = 1
	WHERE  "stg_dl_src"."load_cycle_id" IS NULL AND "mex_src"."load_cycle_id" IS NULL AND "mex_src_bk"."record_type" = 'N'
	;
END;


END;
$function$;
 
 
