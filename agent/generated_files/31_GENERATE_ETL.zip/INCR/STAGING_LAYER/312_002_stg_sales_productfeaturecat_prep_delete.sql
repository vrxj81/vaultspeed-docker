CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_productfeaturecat_prep_delete"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_prep_del_tgt

	INSERT INTO "moto_sales_stg"."product_feature_cat"(
		 "product_feature_cat_hkey"
		,"load_date"
		,"load_cycle_id"
		,"jrn_flag"
		,"record_type"
		,"product_feature_category_id"
		,"product_feature_category_code_bk"
		,"prod_feat_cat_language_code_seq"
		,"prod_feat_cat_description"
		,"update_timestamp"
	)
	WITH "sat_src1" AS 
	( 
		SELECT 
			  "sat_ed_src1"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
			, COALESCE(LEAD("sat_ed_src1"."load_date")OVER(PARTITION BY "sat_ed_src1"."product_feature_cat_hkey" ORDER BY "sat_ed_src1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "sat_ed_src1"."product_feature_category_id" AS "product_feature_category_id"
			, "sat_ed_src1"."delete_flag" AS "delete_flag"
			, "sat_ed_src1"."load_cycle_id" AS "load_cycle_id"
			, "sat_ed_src1"."prod_feat_cat_language_code_seq" AS "prod_feat_cat_language_code_seq"
			, "sat_ed_src1"."prod_feat_cat_description" AS "prod_feat_cat_description"
			, "sat_ed_src1"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."sat_sales_product_feature_cat" "sat_ed_src1"
	)
	SELECT 
		  "hub_src"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
		, "lci_src"."load_date" AS "load_date"
		, "lci_src"."load_cycle_id" AS "load_cycle_id"
		, 'D' AS "jrn_flag"
		, 'S' AS "record_type"
		, "sat_src1"."product_feature_category_id" AS "product_feature_category_id"
		, "hub_src"."product_feature_category_code_bk" AS "product_feature_category_code_bk"
		, "sat_src1"."prod_feat_cat_language_code_seq" AS "prod_feat_cat_language_code_seq"
		, "sat_src1"."prod_feat_cat_description" AS "prod_feat_cat_description"
		, "sat_src1"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."hub_product_feature_cat" "hub_src"
	INNER JOIN "sat_src1" "sat_src1" ON  "sat_src1"."product_feature_cat_hkey" = "hub_src"."product_feature_cat_hkey" AND "sat_src1"."load_end_date" =
		TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar) AND "sat_src1"."delete_flag" = 'N'::text AND "sat_src1"."prod_feat_cat_language_code_seq" = "sat_src1"."prod_feat_cat_language_code_seq"
	LEFT OUTER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "hub_src"."load_cycle_id"::text = "mex_src"."load_cycle_id"
	INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
	LEFT OUTER JOIN "moto_sales_stg"."product_feature_cat" "stg_src" ON  "hub_src"."product_feature_cat_hkey" = "stg_src"."product_feature_cat_hkey" AND "sat_src1"."prod_feat_cat_language_code_seq" =
		 "stg_src"."prod_feat_cat_language_code_seq"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src_bk" ON  1 = 1
	WHERE  "stg_src"."load_cycle_id" IS NULL AND "mex_src"."load_cycle_id" IS NULL AND "mex_src_bk"."record_type" = 'N'
	;
END;


END;
$function$;
 
 
