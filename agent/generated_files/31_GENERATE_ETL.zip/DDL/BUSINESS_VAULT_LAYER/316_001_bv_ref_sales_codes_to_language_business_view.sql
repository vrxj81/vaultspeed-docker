DROP VIEW IF EXISTS "moto_dv_bv"."ref_sales_codes_to_language";
CREATE   VIEW "moto_dv_bv"."ref_sales_codes_to_language"  AS 
	SELECT 
		  "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."language_code" AS "language_code"
		, "dvt_src"."code" AS "code"
		, "dvt_src"."record_source" AS "record_source"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."description" AS "description"
	FROM "moto_dv_fl"."ref_sales_codes_to_language" "dvt_src"
	;

 
 
