DROP VIEW IF EXISTS "moto_dv_bv"."hub_contacts";
CREATE   VIEW "moto_dv_bv"."hub_contacts"  AS 
	SELECT 
		  "dvt_src"."contacts_hkey" AS "contacts_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."contact_id_bk" AS "contact_id_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_contacts" "dvt_src"
	;

 
 
