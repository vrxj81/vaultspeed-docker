DROP VIEW IF EXISTS "moto_dv_bv"."hub_addresses";
CREATE   VIEW "moto_dv_bv"."hub_addresses"  AS 
	SELECT 
		  "dvt_src"."addresses_hkey" AS "addresses_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."street_name_bk" AS "street_name_bk"
		, "dvt_src"."street_number_bk" AS "street_number_bk"
		, "dvt_src"."postal_code_bk" AS "postal_code_bk"
		, "dvt_src"."city_bk" AS "city_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_addresses" "dvt_src"
	;

 
 
