DROP VIEW IF EXISTS "moto_dv_bv"."lks_sales_products_products_rpid";
CREATE   VIEW "moto_dv_bv"."lks_sales_products_products_rpid"  AS 
	SELECT 
		  "dvt_src"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_id" AS "product_id"
		, "dvt_src"."replacement_product_id" AS "replacement_product_id"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lks_sales_products_products_rpid" "dvt_src"
	;

 
 
