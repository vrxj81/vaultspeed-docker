DROP VIEW IF EXISTS "moto_dv_bv"."lks_sales_customers_addresses_csai";
CREATE   VIEW "moto_dv_bv"."lks_sales_customers_addresses_csai"  AS 
	SELECT 
		  "dvt_src"."lnk_customers_addresses_csai_hkey" AS "lnk_customers_addresses_csai_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."customer_number" AS "customer_number"
		, "dvt_src"."customer_ship_to_address_id" AS "customer_ship_to_address_id"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lks_sales_customers_addresses_csai" "dvt_src"
	;

 
 
