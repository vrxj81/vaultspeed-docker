DROP VIEW IF EXISTS "moto_dv_bv"."lnk_productfeatures_productfeaturecat";
CREATE   VIEW "moto_dv_bv"."lnk_productfeatures_productfeaturecat"  AS 
	SELECT 
		  "dvt_src"."product_features_hkey" AS "product_features_hkey"
		, "dvt_src"."lnk_productfeatures_productfeaturecat_hkey" AS "lnk_productfeatures_productfeaturecat_hkey"
		, "dvt_src"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnk_productfeatures_productfeaturecat" "dvt_src"
	;

 
 
