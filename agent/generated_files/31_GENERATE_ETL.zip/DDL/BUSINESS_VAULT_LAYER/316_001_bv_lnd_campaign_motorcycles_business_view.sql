DROP VIEW IF EXISTS "moto_dv_bv"."lnd_campaign_motorcycles";
CREATE   VIEW "moto_dv_bv"."lnd_campaign_motorcycles"  AS 
	SELECT 
		  "dvt_src"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
		, "dvt_src"."campaigns_hkey" AS "campaigns_hkey"
		, "dvt_src"."products_hkey" AS "products_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnd_campaign_motorcycles" "dvt_src"
	;

 
 
