DROP VIEW IF EXISTS "moto_dv_bv"."lks_sales_invoices_customers";
CREATE   VIEW "moto_dv_bv"."lks_sales_invoices_customers"  AS 
	SELECT 
		  "dvt_src"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."invoice_number" AS "invoice_number"
		, "dvt_src"."invoice_customer_id" AS "invoice_customer_id"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lks_sales_invoices_customers" "dvt_src"
	;

 
 
