DROP VIEW IF EXISTS "moto_dv_bv"."lnk_customers_addresses";
CREATE   VIEW "moto_dv_bv"."lnk_customers_addresses"  AS 
	SELECT 
		  "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."lnk_customers_addresses_hkey" AS "lnk_customers_addresses_hkey"
		, "dvt_src"."addresses_hkey" AS "addresses_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnk_customers_addresses" "dvt_src"
	;

 
 
