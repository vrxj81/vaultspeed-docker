DROP VIEW IF EXISTS "moto_dv_bv"."hub_product_feature_class";
CREATE   VIEW "moto_dv_bv"."hub_product_feature_class"  AS 
	SELECT 
		  "dvt_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_feature_class_code_bk" AS "product_feature_class_code_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_product_feature_class" "dvt_src"
	;

 
 
