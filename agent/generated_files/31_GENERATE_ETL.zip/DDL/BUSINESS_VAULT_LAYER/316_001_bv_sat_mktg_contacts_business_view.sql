DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_contacts";
CREATE   VIEW "moto_dv_bv"."sat_mktg_contacts"  AS 
	SELECT 
		  "dvt_src"."contacts_hkey" AS "contacts_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."contact_id" AS "contact_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."contact_type" AS "contact_type"
		, "dvt_src"."contact_type_desc" AS "contact_type_desc"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_mktg_contacts" "dvt_src"
	;

 
 
