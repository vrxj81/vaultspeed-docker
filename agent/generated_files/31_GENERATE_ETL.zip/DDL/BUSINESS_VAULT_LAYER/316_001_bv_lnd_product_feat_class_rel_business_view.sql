DROP VIEW IF EXISTS "moto_dv_bv"."lnd_product_feat_class_rel";
CREATE   VIEW "moto_dv_bv"."lnd_product_feat_class_rel"  AS 
	SELECT 
		  "dvt_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "dvt_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "dvt_src"."product_features_hkey" AS "product_features_hkey"
		, "dvt_src"."products_hkey" AS "products_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnd_product_feat_class_rel" "dvt_src"
	;

 
 
