DROP VIEW IF EXISTS "moto_dv_bv"."hub_product_features";
CREATE   VIEW "moto_dv_bv"."hub_product_features"  AS 
	SELECT 
		  "dvt_src"."product_features_hkey" AS "product_features_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_feature_code_bk" AS "product_feature_code_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_product_features" "dvt_src"
	;

 
 
