DROP VIEW IF EXISTS "moto_dv_bv"."hub_campaigns";
CREATE   VIEW "moto_dv_bv"."hub_campaigns"  AS 
	SELECT 
		  "dvt_src"."campaigns_hkey" AS "campaigns_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."campaign_code_bk" AS "campaign_code_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_campaigns" "dvt_src"
	;

 
 
