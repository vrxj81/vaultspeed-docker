DROP VIEW IF EXISTS "moto_dv_bv"."view_pit_daily_snapshot_products_snapshotdates";
CREATE   VIEW "moto_dv_bv"."view_pit_daily_snapshot_products_snapshotdates"  AS 
	WITH RECURSIVE "snapshotdates"("snapshot_timestamp") AS 
	( 
		SELECT 
			  date_trunc('DAY', MIN("hub_src"."load_date"))   AS "snapshot_timestamp"
		FROM "moto_dv_fl"."hub_products" "hub_src"
		UNION ALL 
		SELECT 
			  "snapshotdates"."snapshot_timestamp"  +  1 * interval'1 DAY'   AS "snapshot_timestamp"
		FROM "snapshotdates" "snapshotdates"
		INNER JOIN "moto_fmc"."fmc_bv_loading_window_table" "bvlwt_src" ON  "snapshotdates"."snapshot_timestamp"  +  1 * interval'1 DAY'   < "bvlwt_src"."fmc_end_lw_timestamp"
	)
	SELECT 
		  "snapshotdates"."snapshot_timestamp" AS "snapshot_timestamp"
	FROM "snapshotdates" "snapshotdates"
	;

 
 
