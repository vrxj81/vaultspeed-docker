DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_product_feature_cat";
CREATE   VIEW "moto_dv_bv"."sat_sales_product_feature_cat"  AS 
	SELECT 
		  "dvt_src"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_feature_category_id" AS "product_feature_category_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."prod_feat_cat_description" AS "prod_feat_cat_description"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
		, "dvt_src"."prod_feat_cat_language_code_seq" AS "prod_feat_cat_language_code_seq"
	FROM "moto_dv_fl"."sat_sales_product_feature_cat" "dvt_src"
	;

 
 
