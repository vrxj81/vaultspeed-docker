DROP VIEW IF EXISTS "moto_dv_bv"."lnk_invoices_customers";
CREATE   VIEW "moto_dv_bv"."lnk_invoices_customers"  AS 
	SELECT 
		  "dvt_src"."invoices_hkey" AS "invoices_hkey"
		, "dvt_src"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
		, "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnk_invoices_customers" "dvt_src"
	;

 
 
