DROP VIEW IF EXISTS "moto_dv_bv"."lks_mktg_customers_addresses";
CREATE   VIEW "moto_dv_bv"."lks_mktg_customers_addresses"  AS 
	SELECT 
		  "dvt_src"."lnk_customers_addresses_hkey" AS "lnk_customers_addresses_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."party_number" AS "party_number"
		, "dvt_src"."address_number" AS "address_number"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lks_mktg_customers_addresses" "dvt_src"
	;

 
 
