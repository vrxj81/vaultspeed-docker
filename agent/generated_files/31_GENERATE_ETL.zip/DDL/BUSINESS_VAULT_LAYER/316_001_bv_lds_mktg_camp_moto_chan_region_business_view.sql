DROP VIEW IF EXISTS "moto_dv_bv"."lds_mktg_camp_moto_chan_region";
CREATE   VIEW "moto_dv_bv"."lds_mktg_camp_moto_chan_region"  AS 
	SELECT 
		  "dvt_src"."lnd_camp_moto_chan_region_hkey" AS "lnd_camp_moto_chan_region_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."campaign_code" AS "campaign_code"
		, "dvt_src"."campaign_start_date" AS "campaign_start_date"
		, "dvt_src"."channel_id" AS "channel_id"
		, "dvt_src"."motorcycle_id" AS "motorcycle_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
		, "dvt_src"."region_seq" AS "region_seq"
	FROM "moto_dv_fl"."lds_mktg_camp_moto_chan_region" "dvt_src"
	;

 
 
