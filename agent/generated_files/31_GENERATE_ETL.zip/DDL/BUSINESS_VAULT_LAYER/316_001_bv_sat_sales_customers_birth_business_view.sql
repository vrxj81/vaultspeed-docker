DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_customers_birth";
CREATE   VIEW "moto_dv_bv"."sat_sales_customers_birth"  AS 
	SELECT 
		  "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."customer_number" AS "customer_number"
		, "dvt_src"."customer_invoice_address_id" AS "customer_invoice_address_id"
		, "dvt_src"."customer_ship_to_address_id" AS "customer_ship_to_address_id"
		, "dvt_src"."national_person_id" AS "national_person_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."birthdate" AS "birthdate"
		, "dvt_src"."gender" AS "gender"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_sales_customers_birth" "dvt_src"
	;

 
 
