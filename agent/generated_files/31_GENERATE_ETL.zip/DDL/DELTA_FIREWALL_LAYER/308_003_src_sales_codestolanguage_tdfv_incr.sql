DROP VIEW IF EXISTS "moto_sales_dfv"."vw_codes_to_language";
CREATE   VIEW "moto_sales_dfv"."vw_codes_to_language"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."code" AS "code"
			, "cdc_src"."language_code" AS "language_code"
			, "cdc_src"."description" AS "description"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_codes_to_language" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."code","mex_bk_src"."key_attribute_varchar") AS "code"
			, COALESCE("delta_view"."language_code","mex_bk_src"."key_attribute_varchar") AS "language_code"
			, "delta_view"."description" AS "description"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."code" AS "code"
		, "prepjoinbk"."language_code" AS "language_code"
		, "prepjoinbk"."description" AS "description"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
