DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_addresses";
CREATE   VIEW "moto_mktg_dfv"."vw_addresses"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."address_number" AS "address_number"
			, "cdc_src"."street_name" AS "street_name"
			, "cdc_src"."street_number" AS "street_number"
			, "cdc_src"."postal_code" AS "postal_code"
			, "cdc_src"."city" AS "city"
			, "cdc_src"."province" AS "province"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_addresses" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."address_number", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "address_number"
			, "delta_view"."street_name" AS "street_name"
			, "delta_view"."street_number" AS "street_number"
			, "delta_view"."postal_code" AS "postal_code"
			, "delta_view"."city" AS "city"
			, "delta_view"."province" AS "province"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."address_number" AS "address_number"
		, "prepjoinbk"."street_name" AS "street_name"
		, "prepjoinbk"."street_number" AS "street_number"
		, "prepjoinbk"."postal_code" AS "postal_code"
		, "prepjoinbk"."city" AS "city"
		, "prepjoinbk"."province" AS "province"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
