DROP VIEW IF EXISTS "moto_sales_dfv"."vw_product_feat_class_rel";
CREATE   VIEW "moto_sales_dfv"."vw_product_feat_class_rel"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."product_feature_id" AS "product_feature_id"
			, "cdc_src"."product_id" AS "product_id"
			, "cdc_src"."product_feature_class_id" AS "product_feature_class_id"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_product_feat_class_rel" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."product_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "product_id"
			, COALESCE("delta_view"."product_feature_id", CAST("mex_bk_src"."key_attribute_integer" AS INTEGER)) AS "product_feature_id"
			, COALESCE("delta_view"."product_feature_class_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "product_feature_class_id"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."product_feature_id" AS "product_feature_id"
		, "prepjoinbk"."product_id" AS "product_id"
		, "prepjoinbk"."product_feature_class_id" AS "product_feature_class_id"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
