DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_channels";
CREATE   VIEW "moto_mktg_dfv"."vw_channels"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."channel_id" AS "channel_id"
			, "cdc_src"."channel_code" AS "channel_code"
			, "cdc_src"."channel_description" AS "channel_description"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_channels" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."channel_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "channel_id"
			, "delta_view"."channel_code" AS "channel_code"
			, "delta_view"."channel_description" AS "channel_description"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."channel_id" AS "channel_id"
		, "prepjoinbk"."channel_code" AS "channel_code"
		, "prepjoinbk"."channel_description" AS "channel_description"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
