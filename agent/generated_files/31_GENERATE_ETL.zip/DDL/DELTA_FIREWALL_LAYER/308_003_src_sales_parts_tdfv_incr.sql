DROP VIEW IF EXISTS "moto_sales_dfv"."vw_parts";
CREATE   VIEW "moto_sales_dfv"."vw_parts"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."part_id" AS "part_id"
			, "cdc_src"."part_number" AS "part_number"
			, "cdc_src"."part_language_code" AS "part_language_code"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_moto_parts" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."part_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar)
				) AS "part_id"
			, "delta_view"."part_number" AS "part_number"
			, COALESCE("delta_view"."part_language_code","mex_bk_src"."key_attribute_varchar") AS "part_language_code_seq"
			, "delta_view"."part_language_code" AS "part_language_code"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."part_id" AS "part_id"
		, "prepjoinbk"."part_number" AS "part_number"
		, "prepjoinbk"."part_language_code" AS "part_language_code"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
