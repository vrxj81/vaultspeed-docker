DROP VIEW IF EXISTS "moto_sales_dfv"."vw_product_features";
CREATE   VIEW "moto_sales_dfv"."vw_product_features"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."product_feature_id" AS "product_feature_id"
			, "cdc_src"."product_feature_cat_id" AS "product_feature_cat_id"
			, "cdc_src"."product_feature_code" AS "product_feature_code"
			, "cdc_src"."product_feature_language_code" AS "product_feature_language_code"
			, "cdc_src"."product_feature_description" AS "product_feature_description"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_product_features" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."product_feature_id", CAST("mex_bk_src"."key_attribute_integer" AS INTEGER)) AS "product_feature_id"
			, COALESCE("delta_view"."product_feature_cat_id", CAST("mex_bk_src"."key_attribute_integer" AS INTEGER)) AS "product_feature_cat_id"
			, "delta_view"."product_feature_code" AS "product_feature_code"
			, COALESCE("delta_view"."product_feature_language_code","mex_bk_src"."key_attribute_varchar") AS "product_feature_language_code_seq"
			, "delta_view"."product_feature_language_code" AS "product_feature_language_code"
			, "delta_view"."product_feature_description" AS "product_feature_description"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."product_feature_id" AS "product_feature_id"
		, "prepjoinbk"."product_feature_cat_id" AS "product_feature_cat_id"
		, "prepjoinbk"."product_feature_code" AS "product_feature_code"
		, "prepjoinbk"."product_feature_language_code" AS "product_feature_language_code"
		, "prepjoinbk"."product_feature_description" AS "product_feature_description"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
