DROP VIEW IF EXISTS "moto_sales_dfv"."vw_product_feature_cat";
CREATE   VIEW "moto_sales_dfv"."vw_product_feature_cat"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."product_feature_category_id" AS "product_feature_category_id"
			, "cdc_src"."product_feature_category_code" AS "product_feature_category_code"
			, "cdc_src"."prod_feat_cat_language_code" AS "prod_feat_cat_language_code"
			, "cdc_src"."prod_feat_cat_description" AS "prod_feat_cat_description"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_product_feature_cat" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."product_feature_category_id", CAST("mex_bk_src"."key_attribute_integer" AS INTEGER)) AS "product_feature_category_id"
			, "delta_view"."product_feature_category_code" AS "product_feature_category_code"
			, COALESCE("delta_view"."prod_feat_cat_language_code","mex_bk_src"."key_attribute_varchar") AS "prod_feat_cat_language_code_seq"
			, "delta_view"."prod_feat_cat_language_code" AS "prod_feat_cat_language_code"
			, "delta_view"."prod_feat_cat_description" AS "prod_feat_cat_description"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."product_feature_category_id" AS "product_feature_category_id"
		, "prepjoinbk"."product_feature_category_code" AS "product_feature_category_code"
		, "prepjoinbk"."prod_feat_cat_language_code" AS "prod_feat_cat_language_code"
		, "prepjoinbk"."prod_feat_cat_description" AS "prod_feat_cat_description"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
