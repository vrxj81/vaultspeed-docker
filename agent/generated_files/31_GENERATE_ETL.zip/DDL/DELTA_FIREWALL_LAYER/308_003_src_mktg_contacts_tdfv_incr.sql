DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_contacts";
CREATE   VIEW "moto_mktg_dfv"."vw_contacts"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."contact_id" AS "contact_id"
			, "cdc_src"."contact_type" AS "contact_type"
			, "cdc_src"."contact_type_desc" AS "contact_type_desc"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_contacts" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."contact_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "contact_id"
			, COALESCE(UPPER( "delta_view"."contact_id"::text),"mex_bk_src"."key_attribute_numeric") AS "contact_id_bk"
			, "delta_view"."contact_type" AS "contact_type"
			, "delta_view"."contact_type_desc" AS "contact_type_desc"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."contact_id" AS "contact_id"
		, "prepjoinbk"."contact_type" AS "contact_type"
		, "prepjoinbk"."contact_type_desc" AS "contact_type_desc"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
