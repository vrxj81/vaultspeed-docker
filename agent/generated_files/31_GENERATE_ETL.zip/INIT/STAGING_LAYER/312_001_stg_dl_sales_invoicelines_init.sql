CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_sales_invoicelines_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_dl_tgt

	TRUNCATE TABLE "moto_sales_stg"."invoice_lines"  CASCADE;

	INSERT INTO "moto_sales_stg"."invoice_lines"(
		 "lnd_invoice_lines_hkey"
		,"parts_hkey"
		,"invoices_hkey"
		,"products_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"invoice_line_number"
		,"invoice_number"
		,"product_id"
		,"part_id"
		,"invoice_number_fk_invoicenumber_bk"
		,"invoice_line_number_seq"
		,"amount"
		,"quantity"
		,"unit_price"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."part_id" AS "part_id"
		FROM "moto_sales_ext"."invoice_lines" "ext_dis_io_src1"
	)
	, "dist_io_fk3" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src3"."product_id" AS "product_id"
		FROM "moto_sales_ext"."invoice_lines" "ext_dis_io_src3"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."parts_hkey" AS "parts_hkey"
			, "sat_io_src1"."part_id" AS "part_id"
			, MAX("sat_io_src1"."load_date") AS "load_date"
		FROM "dist_io_fk1" "dist_io_fk1"
		INNER JOIN "moto_dv_fl"."sat_sales_parts" "sat_io_src1" ON  "dist_io_fk1"."part_id" = "sat_io_src1"."part_id"
		GROUP BY  "sat_io_src1"."parts_hkey",  "sat_io_src1"."part_id"
	)
	, "sat_src3" AS 
	( 
		SELECT 
			  "sat_io_src3"."products_hkey" AS "products_hkey"
			, "sat_io_src3"."product_id" AS "product_id"
			, MAX("sat_io_src3"."load_date") AS "load_date"
		FROM "dist_io_fk3" "dist_io_fk3"
		INNER JOIN "moto_dv_fl"."sat_sales_products" "sat_io_src3" ON  "dist_io_fk3"."product_id" = "sat_io_src3"."product_id"
		GROUP BY  "sat_io_src3"."products_hkey",  "sat_io_src3"."product_id"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."part_id" AS "part_id"
		FROM "moto_sales_ext"."invoice_lines" "ext_dis_src1"
	)
	, "dist_fk3" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src3"."product_id" AS "product_id"
		FROM "moto_sales_ext"."invoice_lines" "ext_dis_src3"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  "hub_src1"."part_number_bk" AS "part_number_bk"
			, "dist_fk1"."part_id" AS "part_id"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."part_id" = "sat_src1"."part_id"
		INNER JOIN "moto_dv_fl"."hub_parts" "hub_src1" ON  "hub_src1"."parts_hkey" = "sat_src1"."parts_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."part_number_bk" AS "part_number_bk"
			, "dist_fk1"."part_id" AS "part_id"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_sales_ext"."parts" "ext_fkbk_src1" ON  "dist_fk1"."part_id" = "ext_fkbk_src1"."part_id"
	)
	, "prep_find_bk_fk3" AS 
	( 
		SELECT 
			  "hub_src3"."product_cc_bk" AS "product_cc_bk"
			, "hub_src3"."product_et_code_bk" AS "product_et_code_bk"
			, "hub_src3"."product_part_code_bk" AS "product_part_code_bk"
			, "dist_fk3"."product_id" AS "product_id"
			, "sat_src3"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk3" "dist_fk3"
		INNER JOIN "sat_src3" "sat_src3" ON  "dist_fk3"."product_id" = "sat_src3"."product_id"
		INNER JOIN "moto_dv_fl"."hub_products" "hub_src3" ON  "hub_src3"."products_hkey" = "sat_src3"."products_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src3"."product_cc_bk" AS "product_cc_bk"
			, "ext_fkbk_src3"."product_et_code_bk" AS "product_et_code_bk"
			, "ext_fkbk_src3"."product_part_code_bk" AS "product_part_code_bk"
			, "dist_fk3"."product_id" AS "product_id"
			, "ext_fkbk_src3"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk3" "dist_fk3"
		INNER JOIN "moto_sales_ext"."products" "ext_fkbk_src3" ON  "dist_fk3"."product_id" = "ext_fkbk_src3"."product_id"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."part_number_bk" AS "part_number_bk"
			, "prep_find_bk_fk1"."part_id" AS "part_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."part_id" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "order_bk_fk3" AS 
	( 
		SELECT 
			  "prep_find_bk_fk3"."product_cc_bk" AS "product_cc_bk"
			, "prep_find_bk_fk3"."product_et_code_bk" AS "product_et_code_bk"
			, "prep_find_bk_fk3"."product_part_code_bk" AS "product_part_code_bk"
			, "prep_find_bk_fk3"."product_id" AS "product_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk3"."product_id" ORDER BY "prep_find_bk_fk3"."general_order",
				"prep_find_bk_fk3"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk3" "prep_find_bk_fk3"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."part_number_bk" AS "part_number_bk"
			, "order_bk_fk1"."part_id" AS "part_id"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	, "find_bk_fk3" AS 
	( 
		SELECT 
			  "order_bk_fk3"."product_cc_bk" AS "product_cc_bk"
			, "order_bk_fk3"."product_et_code_bk" AS "product_et_code_bk"
			, "order_bk_fk3"."product_part_code_bk" AS "product_part_code_bk"
			, "order_bk_fk3"."product_id" AS "product_id"
		FROM "order_bk_fk3" "order_bk_fk3"
		WHERE  "order_bk_fk3"."dummy" = 1
	)
	SELECT 
		  DIGEST(  COALESCE("find_bk_fk1"."part_number_bk","mex_src"."key_attribute_varchar")|| '#' || "ext_src"."invoice_number_fk_invoicenumber_bk" || 
			'#' || COALESCE("find_bk_fk3"."product_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk3"."product_et_code_bk","mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk3"."product_part_code_bk","mex_src"."key_attribute_varchar")|| '#'  ,'SHA1') AS "lnd_invoice_lines_hkey"
		, DIGEST( COALESCE("find_bk_fk1"."part_number_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "parts_hkey"
		, DIGEST( "ext_src"."invoice_number_fk_invoicenumber_bk" || '#' ,'SHA1') AS "invoices_hkey"
		, DIGEST( COALESCE("find_bk_fk3"."product_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk3"."product_et_code_bk",
			"mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk3"."product_part_code_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "products_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.invoice_lines' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."invoice_line_number" AS "invoice_line_number"
		, "ext_src"."invoice_number" AS "invoice_number"
		, "ext_src"."product_id" AS "product_id"
		, "ext_src"."part_id" AS "part_id"
		, "ext_src"."invoice_number_fk_invoicenumber_bk" AS "invoice_number_fk_invoicenumber_bk"
		, "ext_src"."invoice_line_number_seq" AS "invoice_line_number_seq"
		, "ext_src"."amount" AS "amount"
		, "ext_src"."quantity" AS "quantity"
		, "ext_src"."unit_price" AS "unit_price"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."invoice_lines" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."part_id" = "find_bk_fk1"."part_id"
	LEFT OUTER JOIN "find_bk_fk3" "find_bk_fk3" ON  "ext_src"."product_id" = "find_bk_fk3"."product_id"
	;
END;


END;
$function$;
 
 
