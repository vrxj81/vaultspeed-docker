CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_products_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_tgt

	TRUNCATE TABLE "moto_sales_stg"."products"  CASCADE;

	INSERT INTO "moto_sales_stg"."products"(
		 "products_hkey"
		,"products_rpid_hkey"
		,"lnk_products_products_rpid_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"product_id"
		,"replacement_product_id"
		,"product_cc_bk"
		,"product_et_code_bk"
		,"product_part_code_bk"
		,"product_intro_date"
		,"product_name"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."replacement_product_id" AS "replacement_product_id"
		FROM "moto_sales_ext"."products" "ext_dis_io_src1"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."products_hkey" AS "products_hkey"
			, "sat_io_src1"."product_id" AS "product_id"
			, MAX("sat_io_src1"."load_date") AS "load_date"
		FROM "dist_io_fk1" "dist_io_fk1"
		INNER JOIN "moto_dv_fl"."sat_sales_products" "sat_io_src1" ON  "dist_io_fk1"."replacement_product_id" = "sat_io_src1"."product_id"
		GROUP BY  "sat_io_src1"."products_hkey",  "sat_io_src1"."product_id"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."replacement_product_id" AS "replacement_product_id"
		FROM "moto_sales_ext"."products" "ext_dis_src1"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  "hub_src1"."product_cc_bk" AS "product_cc_bk"
			, "hub_src1"."product_et_code_bk" AS "product_et_code_bk"
			, "hub_src1"."product_part_code_bk" AS "product_part_code_bk"
			, "dist_fk1"."replacement_product_id" AS "replacement_product_id"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."replacement_product_id" = "sat_src1"."product_id"
		INNER JOIN "moto_dv_fl"."hub_products" "hub_src1" ON  "hub_src1"."products_hkey" = "sat_src1"."products_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."product_cc_bk" AS "product_cc_bk"
			, "ext_fkbk_src1"."product_et_code_bk" AS "product_et_code_bk"
			, "ext_fkbk_src1"."product_part_code_bk" AS "product_part_code_bk"
			, "dist_fk1"."replacement_product_id" AS "replacement_product_id"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_sales_ext"."products" "ext_fkbk_src1" ON  "dist_fk1"."replacement_product_id" = "ext_fkbk_src1"."product_id"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."product_cc_bk" AS "product_cc_bk"
			, "prep_find_bk_fk1"."product_et_code_bk" AS "product_et_code_bk"
			, "prep_find_bk_fk1"."product_part_code_bk" AS "product_part_code_bk"
			, "prep_find_bk_fk1"."replacement_product_id" AS "replacement_product_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."replacement_product_id" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."product_cc_bk" AS "product_cc_bk"
			, "order_bk_fk1"."product_et_code_bk" AS "product_et_code_bk"
			, "order_bk_fk1"."product_part_code_bk" AS "product_part_code_bk"
			, "order_bk_fk1"."replacement_product_id" AS "replacement_product_id"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	SELECT 
		  DIGEST( "ext_src"."product_cc_bk" || '#' ||  "ext_src"."product_et_code_bk" || '#' ||  "ext_src"."product_part_code_bk" || 
			'#' ,'SHA1') AS "products_hkey"
		, DIGEST( COALESCE("find_bk_fk1"."product_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk1"."product_et_code_bk",
			"mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk1"."product_part_code_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "products_rpid_hkey"
		, DIGEST( "ext_src"."product_cc_bk" || '#' ||  "ext_src"."product_et_code_bk" || '#' ||  "ext_src"."product_part_code_bk" || 
			'#' || COALESCE("find_bk_fk1"."product_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk1"."product_et_code_bk","mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk1"."product_part_code_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "lnk_products_products_rpid_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.products' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."product_id" AS "product_id"
		, "ext_src"."replacement_product_id" AS "replacement_product_id"
		, "ext_src"."product_cc_bk" AS "product_cc_bk"
		, "ext_src"."product_et_code_bk" AS "product_et_code_bk"
		, "ext_src"."product_part_code_bk" AS "product_part_code_bk"
		, "ext_src"."product_intro_date" AS "product_intro_date"
		, "ext_src"."product_name" AS "product_name"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."products" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."replacement_product_id" = "find_bk_fk1"."replacement_product_id"
	;
END;


END;
$function$;
 
 
