CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_sales_payments_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_dl_tgt

	TRUNCATE TABLE "moto_sales_stg"."payments"  CASCADE;

	INSERT INTO "moto_sales_stg"."payments"(
		 "nhl_payments_hkey"
		,"invoices_hkey"
		,"customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"invoice_number"
		,"customer_number"
		,"invoice_number_fk_invoicenumber_bk"
		,"transaction_id"
		,"date_time"
		,"amount"
		,"update_timestamp"
	)
	WITH "dist_io_fk2" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src2"."customer_number" AS "customer_number"
		FROM "moto_sales_ext"."payments" "ext_dis_io_src2"
	)
	, "sat_src2" AS 
	( 
		SELECT 
			  "sat_io_src2"."customers_hkey" AS "customers_hkey"
			, "sat_io_src2"."customer_number" AS "customer_number"
			, MAX("sat_io_src2"."load_date") AS "load_date"
			, "sat_io_src2"."national_person_id" AS "national_person_id"
		FROM "dist_io_fk2" "dist_io_fk2"
		INNER JOIN "moto_dv_fl"."sat_sales_customers_birth" "sat_io_src2" ON  "dist_io_fk2"."customer_number" = "sat_io_src2"."customer_number"
		GROUP BY  "sat_io_src2"."customers_hkey",  "sat_io_src2"."customer_number",  "sat_io_src2"."national_person_id"
	)
	, "dist_fk2" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src2"."customer_number" AS "customer_number"
		FROM "moto_sales_ext"."payments" "ext_dis_src2"
	)
	, "prep_find_bk_fk2" AS 
	( 
		SELECT 
			  UPPER(REPLACE(TRIM( "sat_src2"."national_person_id"),'#','\' || '#')) AS "national_person_id_bk"
			, "dist_fk2"."customer_number" AS "customer_number"
			, "sat_src2"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk2" "dist_fk2"
		INNER JOIN "sat_src2" "sat_src2" ON  "dist_fk2"."customer_number" = "sat_src2"."customer_number"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_src2" ON  "hub_src2"."customers_hkey" = "sat_src2"."customers_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src2"."national_person_id_bk" AS "national_person_id_bk"
			, "dist_fk2"."customer_number" AS "customer_number"
			, "ext_fkbk_src2"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk2" "dist_fk2"
		INNER JOIN "moto_sales_ext"."customers" "ext_fkbk_src2" ON  "dist_fk2"."customer_number" = "ext_fkbk_src2"."customer_number"
	)
	, "order_bk_fk2" AS 
	( 
		SELECT 
			  "prep_find_bk_fk2"."national_person_id_bk" AS "national_person_id_bk"
			, "prep_find_bk_fk2"."customer_number" AS "customer_number"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk2"."customer_number" ORDER BY "prep_find_bk_fk2"."general_order",
				"prep_find_bk_fk2"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk2" "prep_find_bk_fk2"
	)
	, "find_bk_fk2" AS 
	( 
		SELECT 
			  "order_bk_fk2"."national_person_id_bk" AS "national_person_id_bk"
			, "order_bk_fk2"."customer_number" AS "customer_number"
		FROM "order_bk_fk2" "order_bk_fk2"
		WHERE  "order_bk_fk2"."dummy" = 1
	)
	SELECT 
		  DIGEST(  "ext_src"."invoice_number_fk_invoicenumber_bk" || '#' || 'ms' || '#' || COALESCE("find_bk_fk2"."national_person_id_bk",
			"mex_src"."key_attribute_varchar")|| '#'  ,'SHA1') AS "nhl_payments_hkey"
		, DIGEST( "ext_src"."invoice_number_fk_invoicenumber_bk" || '#' ,'SHA1') AS "invoices_hkey"
		, DIGEST( 'ms' || '#' || COALESCE("find_bk_fk2"."national_person_id_bk","mex_src"."key_attribute_varchar")|| '#' ,
			'SHA1') AS "customers_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.payments' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."invoice_number" AS "invoice_number"
		, "ext_src"."customer_number" AS "customer_number"
		, "ext_src"."invoice_number_fk_invoicenumber_bk" AS "invoice_number_fk_invoicenumber_bk"
		, "ext_src"."transaction_id" AS "transaction_id"
		, "ext_src"."date_time" AS "date_time"
		, "ext_src"."amount" AS "amount"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."payments" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk2" "find_bk_fk2" ON  "ext_src"."customer_number" = "find_bk_fk2"."customer_number"
	;
END;


END;
$function$;
 
 
