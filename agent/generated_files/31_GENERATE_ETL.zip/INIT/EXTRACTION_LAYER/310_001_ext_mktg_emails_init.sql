CREATE OR REPLACE FUNCTION "moto_proc"."ext_mktg_emails_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_mktg_ext"."e_mails"  CASCADE;

	INSERT INTO "moto_mktg_ext"."e_mails"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"contact_id"
		,"contact_id_fk_contactid_bk"
		,"name"
		,"update_timestamp"
	)
	WITH "prep_excep" AS 
	( 
		SELECT 
			  'I' AS "jrn_flag"
			, 'S' AS "record_type"
			, NULL AS "load_cycle_id"
			, COALESCE("ini_src"."contact_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar)
				) AS "contact_id"
			, "ini_src"."name" AS "name"
			, "ini_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_ini"."e_mails" "ini_src"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_inr_src" ON  "mex_inr_src"."record_type" = 'N'
		UNION ALL 
		SELECT 
			  'I' AS "jrn_flag"
			, "mex_ext_src"."record_type" AS "record_type"
			, "mex_ext_src"."load_cycle_id" ::int AS "load_cycle_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "contact_id"
			, "mex_ext_src"."attribute_varchar"::text AS "name"
			, TO_TIMESTAMP("mex_ext_src"."attribute_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "update_timestamp"
		FROM "moto_mktg_mtd"."mtd_exception_records" "mex_ext_src"
	)
	, "calculate_bk" AS 
	( 
		SELECT 
			  COALESCE("prep_excep"."load_cycle_id","lci_src"."load_cycle_id") AS "load_cycle_id"
			, "lci_src"."load_date" AS "load_date"
			, "prep_excep"."jrn_flag" AS "jrn_flag"
			, "prep_excep"."record_type" AS "record_type"
			, "prep_excep"."contact_id" AS "contact_id"
			, UPPER( "prep_excep"."contact_id"::text) AS "contact_id_fk_contactid_bk"
			, "prep_excep"."name" AS "name"
			, "prep_excep"."update_timestamp" AS "update_timestamp"
		FROM "prep_excep" "prep_excep"
		INNER JOIN "moto_mktg_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."contact_id" AS "contact_id"
		, "calculate_bk"."contact_id_fk_contactid_bk" AS "contact_id_fk_contactid_bk"
		, "calculate_bk"."name" AS "name"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
