CREATE OR REPLACE FUNCTION "moto_proc"."ext_sales_products_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_sales_ext"."products"  CASCADE;

	INSERT INTO "moto_sales_ext"."products"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"product_id"
		,"replacement_product_id"
		,"product_cc_bk"
		,"product_et_code_bk"
		,"product_part_code_bk"
		,"product_intro_date"
		,"product_name"
		,"update_timestamp"
	)
	WITH "prep_excep" AS 
	( 
		SELECT 
			  'I' AS "jrn_flag"
			, 'S' AS "record_type"
			, NULL AS "load_cycle_id"
			, COALESCE("ini_src"."product_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar)
				) AS "product_id"
			, COALESCE("ini_src"."replacement_product_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "replacement_product_id"
			, "ini_src"."product_cc" AS "product_cc"
			, "ini_src"."product_et_code" AS "product_et_code"
			, "ini_src"."product_part_code" AS "product_part_code"
			, "ini_src"."product_intro_date" AS "product_intro_date"
			, "ini_src"."product_name" AS "product_name"
			, "ini_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_ini"."moto_products" "ini_src"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_inr_src" ON  "mex_inr_src"."record_type" = 'N'
		UNION ALL 
		SELECT 
			  'I' AS "jrn_flag"
			, "mex_ext_src"."record_type" AS "record_type"
			, "mex_ext_src"."load_cycle_id" ::int AS "load_cycle_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "product_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "replacement_product_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "product_cc"
			, "mex_ext_src"."key_attribute_character"::text AS "product_et_code"
			, "mex_ext_src"."key_attribute_varchar"::text AS "product_part_code"
			, TO_DATE("mex_ext_src"."attribute_date", 'DD/MM/YYYY'::varchar) AS "product_intro_date"
			, "mex_ext_src"."attribute_varchar"::text AS "product_name"
			, TO_TIMESTAMP("mex_ext_src"."attribute_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "update_timestamp"
		FROM "moto_sales_mtd"."mtd_exception_records" "mex_ext_src"
	)
	, "calculate_bk" AS 
	( 
		SELECT 
			  COALESCE("prep_excep"."load_cycle_id","lci_src"."load_cycle_id") AS "load_cycle_id"
			, "lci_src"."load_date" AS "load_date"
			, "prep_excep"."jrn_flag" AS "jrn_flag"
			, "prep_excep"."record_type" AS "record_type"
			, "prep_excep"."product_id" AS "product_id"
			, "prep_excep"."replacement_product_id" AS "replacement_product_id"
			, COALESCE(UPPER( "prep_excep"."product_cc"::text),"mex_src"."key_attribute_numeric") AS "product_cc_bk"
			, COALESCE(UPPER(REPLACE(TRIM("prep_excep"."product_et_code"),'#','\' || '#')),"mex_src"."key_attribute_character") AS "product_et_code_bk"
			, COALESCE(UPPER(REPLACE(TRIM("prep_excep"."product_part_code"),'#','\' || '#')),"mex_src"."key_attribute_varchar") AS "product_part_code_bk"
			, "prep_excep"."product_intro_date" AS "product_intro_date"
			, "prep_excep"."product_name" AS "product_name"
			, "prep_excep"."update_timestamp" AS "update_timestamp"
		FROM "prep_excep" "prep_excep"
		INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."product_id" AS "product_id"
		, "calculate_bk"."replacement_product_id" AS "replacement_product_id"
		, "calculate_bk"."product_cc_bk" AS "product_cc_bk"
		, "calculate_bk"."product_et_code_bk" AS "product_et_code_bk"
		, "calculate_bk"."product_part_code_bk" AS "product_part_code_bk"
		, "calculate_bk"."product_intro_date" AS "product_intro_date"
		, "calculate_bk"."product_name" AS "product_name"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
