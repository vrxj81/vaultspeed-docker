CREATE OR REPLACE FUNCTION "moto_proc"."ext_sales_productfeaturecat_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_sales_ext"."product_feature_cat"  CASCADE;

	INSERT INTO "moto_sales_ext"."product_feature_cat"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"product_feature_category_id"
		,"product_feature_category_code_bk"
		,"prod_feat_cat_language_code_seq"
		,"prod_feat_cat_description"
		,"update_timestamp"
	)
	WITH "prep_excep" AS 
	( 
		SELECT 
			  'I' AS "jrn_flag"
			, 'S' AS "record_type"
			, NULL AS "load_cycle_id"
			, COALESCE("ini_src"."product_feature_category_id", CAST("mex_inr_src"."key_attribute_integer" AS INTEGER)) AS "product_feature_category_id"
			, "ini_src"."product_feature_category_code" AS "product_feature_category_code"
			, COALESCE("ini_src"."prod_feat_cat_language_code", "mex_inr_src"."key_attribute_varchar"::text) AS "prod_feat_cat_language_code_seq"
			, "ini_src"."prod_feat_cat_description" AS "prod_feat_cat_description"
			, "ini_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_ini"."product_feature_cat" "ini_src"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_inr_src" ON  "mex_inr_src"."record_type" = 'N'
		UNION ALL 
		SELECT 
			  'I' AS "jrn_flag"
			, "mex_ext_src"."record_type" AS "record_type"
			, "mex_ext_src"."load_cycle_id" ::int AS "load_cycle_id"
			, CAST("mex_ext_src"."key_attribute_integer" AS INTEGER) AS "product_feature_category_id"
			, "mex_ext_src"."key_attribute_varchar"::text AS "product_feature_category_code"
			, "mex_ext_src"."key_attribute_varchar"::text AS "prod_feat_cat_language_code_seq"
			, "mex_ext_src"."attribute_varchar"::text AS "prod_feat_cat_description"
			, TO_TIMESTAMP("mex_ext_src"."attribute_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "update_timestamp"
		FROM "moto_sales_mtd"."mtd_exception_records" "mex_ext_src"
	)
	, "calculate_bk" AS 
	( 
		SELECT 
			  COALESCE("prep_excep"."load_cycle_id","lci_src"."load_cycle_id") AS "load_cycle_id"
			, "lci_src"."load_date" AS "load_date"
			, "prep_excep"."jrn_flag" AS "jrn_flag"
			, "prep_excep"."record_type" AS "record_type"
			, "prep_excep"."product_feature_category_id" AS "product_feature_category_id"
			, COALESCE(UPPER(REPLACE(TRIM("prep_excep"."product_feature_category_code"),'#','\' || '#')),"mex_src"."key_attribute_varchar") AS "product_feature_category_code_bk"
			, "prep_excep"."prod_feat_cat_language_code_seq" AS "prod_feat_cat_language_code_seq"
			, "prep_excep"."prod_feat_cat_description" AS "prod_feat_cat_description"
			, "prep_excep"."update_timestamp" AS "update_timestamp"
		FROM "prep_excep" "prep_excep"
		INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."product_feature_category_id" AS "product_feature_category_id"
		, "calculate_bk"."product_feature_category_code_bk" AS "product_feature_category_code_bk"
		, "calculate_bk"."prod_feat_cat_language_code_seq" AS "prod_feat_cat_language_code_seq"
		, "calculate_bk"."prod_feat_cat_description" AS "prod_feat_cat_description"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
