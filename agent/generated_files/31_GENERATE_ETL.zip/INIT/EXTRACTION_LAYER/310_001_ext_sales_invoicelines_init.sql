CREATE OR REPLACE FUNCTION "moto_proc"."ext_sales_invoicelines_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_sales_ext"."invoice_lines"  CASCADE;

	INSERT INTO "moto_sales_ext"."invoice_lines"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"invoice_line_number"
		,"invoice_number"
		,"product_id"
		,"part_id"
		,"invoice_number_fk_invoicenumber_bk"
		,"invoice_line_number_seq"
		,"amount"
		,"quantity"
		,"unit_price"
		,"update_timestamp"
	)
	WITH "prep_excep" AS 
	( 
		SELECT 
			  'I' AS "jrn_flag"
			, 'S' AS "record_type"
			, NULL AS "load_cycle_id"
			, COALESCE("ini_src"."invoice_line_number", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "invoice_line_number"
			, COALESCE("ini_src"."invoice_number", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "invoice_number"
			, COALESCE("ini_src"."part_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar)
				) AS "part_id"
			, COALESCE("ini_src"."product_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar)
				) AS "product_id"
			, COALESCE("ini_src"."invoice_line_number", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "invoice_line_number_seq"
			, "ini_src"."amount" AS "amount"
			, "ini_src"."quantity" AS "quantity"
			, "ini_src"."unit_price" AS "unit_price"
			, "ini_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_ini"."invoice_lines" "ini_src"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_inr_src" ON  "mex_inr_src"."record_type" = 'N'
		UNION ALL 
		SELECT 
			  'I' AS "jrn_flag"
			, "mex_ext_src"."record_type" AS "record_type"
			, "mex_ext_src"."load_cycle_id" ::int AS "load_cycle_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "invoice_line_number"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "invoice_number"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "part_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "product_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "invoice_line_number_seq"
			, TO_NUMBER("mex_ext_src"."attribute_numeric", '9999999999999D9999999999'::varchar) AS "amount"
			, TO_NUMBER("mex_ext_src"."attribute_numeric", '9999999999999D9999999999'::varchar) AS "quantity"
			, TO_NUMBER("mex_ext_src"."attribute_numeric", '9999999999999D9999999999'::varchar) AS "unit_price"
			, TO_TIMESTAMP("mex_ext_src"."attribute_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "update_timestamp"
		FROM "moto_sales_mtd"."mtd_exception_records" "mex_ext_src"
	)
	, "calculate_bk" AS 
	( 
		SELECT 
			  COALESCE("prep_excep"."load_cycle_id","lci_src"."load_cycle_id") AS "load_cycle_id"
			, "lci_src"."load_date" AS "load_date"
			, "prep_excep"."jrn_flag" AS "jrn_flag"
			, "prep_excep"."record_type" AS "record_type"
			, "prep_excep"."invoice_line_number" AS "invoice_line_number"
			, "prep_excep"."invoice_number" AS "invoice_number"
			, "prep_excep"."product_id" AS "product_id"
			, "prep_excep"."part_id" AS "part_id"
			, UPPER( "prep_excep"."invoice_number"::text) AS "invoice_number_fk_invoicenumber_bk"
			, "prep_excep"."invoice_line_number_seq" AS "invoice_line_number_seq"
			, "prep_excep"."amount" AS "amount"
			, "prep_excep"."quantity" AS "quantity"
			, "prep_excep"."unit_price" AS "unit_price"
			, "prep_excep"."update_timestamp" AS "update_timestamp"
		FROM "prep_excep" "prep_excep"
		INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."invoice_line_number" AS "invoice_line_number"
		, "calculate_bk"."invoice_number" AS "invoice_number"
		, "calculate_bk"."product_id" AS "product_id"
		, "calculate_bk"."part_id" AS "part_id"
		, "calculate_bk"."invoice_number_fk_invoicenumber_bk" AS "invoice_number_fk_invoicenumber_bk"
		, "calculate_bk"."invoice_line_number_seq" AS "invoice_line_number_seq"
		, "calculate_bk"."amount" AS "amount"
		, "calculate_bk"."quantity" AS "quantity"
		, "calculate_bk"."unit_price" AS "unit_price"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
