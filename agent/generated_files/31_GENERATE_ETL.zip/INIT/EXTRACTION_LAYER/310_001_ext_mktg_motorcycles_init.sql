CREATE OR REPLACE FUNCTION "moto_proc"."ext_mktg_motorcycles_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_mktg_ext"."motorcycles"  CASCADE;

	INSERT INTO "moto_mktg_ext"."motorcycles"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"motorcycle_id"
		,"motorcycle_cc_bk"
		,"motorcycle_et_code_bk"
		,"motorcycle_part_code_bk"
		,"motorcycle_name"
		,"update_timestamp"
	)
	WITH "prep_excep" AS 
	( 
		SELECT 
			  'I' AS "jrn_flag"
			, 'S' AS "record_type"
			, NULL AS "load_cycle_id"
			, COALESCE("ini_src"."motorcycle_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "motorcycle_id"
			, "ini_src"."motorcycle_cc" AS "motorcycle_cc"
			, "ini_src"."motorcycle_et_code" AS "motorcycle_et_code"
			, "ini_src"."motorcycle_part_code" AS "motorcycle_part_code"
			, "ini_src"."motorcycle_name" AS "motorcycle_name"
			, "ini_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_ini"."motorcycles" "ini_src"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_inr_src" ON  "mex_inr_src"."record_type" = 'N'
		UNION ALL 
		SELECT 
			  'I' AS "jrn_flag"
			, "mex_ext_src"."record_type" AS "record_type"
			, "mex_ext_src"."load_cycle_id" ::int AS "load_cycle_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "motorcycle_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "motorcycle_cc"
			, "mex_ext_src"."key_attribute_character"::text AS "motorcycle_et_code"
			, "mex_ext_src"."key_attribute_varchar"::text AS "motorcycle_part_code"
			, "mex_ext_src"."attribute_varchar"::text AS "motorcycle_name"
			, TO_TIMESTAMP("mex_ext_src"."attribute_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "update_timestamp"
		FROM "moto_mktg_mtd"."mtd_exception_records" "mex_ext_src"
	)
	, "calculate_bk" AS 
	( 
		SELECT 
			  COALESCE("prep_excep"."load_cycle_id","lci_src"."load_cycle_id") AS "load_cycle_id"
			, "lci_src"."load_date" AS "load_date"
			, "prep_excep"."jrn_flag" AS "jrn_flag"
			, "prep_excep"."record_type" AS "record_type"
			, "prep_excep"."motorcycle_id" AS "motorcycle_id"
			, COALESCE(UPPER( "prep_excep"."motorcycle_cc"::text),"mex_src"."key_attribute_numeric") AS "motorcycle_cc_bk"
			, COALESCE(UPPER(REPLACE(TRIM("prep_excep"."motorcycle_et_code"),'#','\' || '#')),"mex_src"."key_attribute_character") AS "motorcycle_et_code_bk"
			, COALESCE(UPPER(REPLACE(TRIM("prep_excep"."motorcycle_part_code"),'#','\' || '#')),"mex_src"."key_attribute_varchar") AS "motorcycle_part_code_bk"
			, "prep_excep"."motorcycle_name" AS "motorcycle_name"
			, "prep_excep"."update_timestamp" AS "update_timestamp"
		FROM "prep_excep" "prep_excep"
		INNER JOIN "moto_mktg_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."motorcycle_id" AS "motorcycle_id"
		, "calculate_bk"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
		, "calculate_bk"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
		, "calculate_bk"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
		, "calculate_bk"."motorcycle_name" AS "motorcycle_name"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
