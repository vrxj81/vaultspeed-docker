CREATE OR REPLACE FUNCTION "moto_proc"."ext_sales_customers_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_sales_ext"."customers"  CASCADE;

	INSERT INTO "moto_sales_ext"."customers"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"customer_number"
		,"customer_invoice_address_id"
		,"customer_ship_to_address_id"
		,"national_person_id_bk"
		,"national_person_id"
		,"first_name"
		,"last_name"
		,"birthdate"
		,"gender"
		,"update_timestamp"
	)
	WITH "prep_excep" AS 
	( 
		SELECT 
			  'I' AS "jrn_flag"
			, 'S' AS "record_type"
			, NULL AS "load_cycle_id"
			, COALESCE("ini_src"."customer_number", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "customer_number"
			, COALESCE("ini_src"."customer_ship_to_address_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "customer_ship_to_address_id"
			, COALESCE("ini_src"."customer_invoice_address_id", TO_NUMBER("mex_inr_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "customer_invoice_address_id"
			, "ini_src"."national_person_id" AS "national_person_id"
			, "ini_src"."first_name" AS "first_name"
			, "ini_src"."last_name" AS "last_name"
			, "ini_src"."birthdate" AS "birthdate"
			, "ini_src"."gender" AS "gender"
			, "ini_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_ini"."customers" "ini_src"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_inr_src" ON  "mex_inr_src"."record_type" = 'N'
		UNION ALL 
		SELECT 
			  'I' AS "jrn_flag"
			, "mex_ext_src"."record_type" AS "record_type"
			, "mex_ext_src"."load_cycle_id" ::int AS "load_cycle_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "customer_number"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "customer_ship_to_address_id"
			, TO_NUMBER("mex_ext_src"."key_attribute_numeric", '9999999999999D9999999999'::varchar) AS "customer_invoice_address_id"
			, "mex_ext_src"."key_attribute_varchar"::text AS "national_person_id"
			, "mex_ext_src"."attribute_varchar"::text AS "first_name"
			, "mex_ext_src"."attribute_varchar"::text AS "last_name"
			, TO_DATE("mex_ext_src"."attribute_date", 'DD/MM/YYYY'::varchar) AS "birthdate"
			, "mex_ext_src"."attribute_character"::text AS "gender"
			, TO_TIMESTAMP("mex_ext_src"."attribute_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "update_timestamp"
		FROM "moto_sales_mtd"."mtd_exception_records" "mex_ext_src"
	)
	, "calculate_bk" AS 
	( 
		SELECT 
			  COALESCE("prep_excep"."load_cycle_id","lci_src"."load_cycle_id") AS "load_cycle_id"
			, "lci_src"."load_date" AS "load_date"
			, "prep_excep"."jrn_flag" AS "jrn_flag"
			, "prep_excep"."record_type" AS "record_type"
			, "prep_excep"."customer_number" AS "customer_number"
			, "prep_excep"."customer_invoice_address_id" AS "customer_invoice_address_id"
			, "prep_excep"."customer_ship_to_address_id" AS "customer_ship_to_address_id"
			, COALESCE(UPPER(REPLACE(TRIM("prep_excep"."national_person_id"),'#','\' || '#')),"mex_src"."key_attribute_varchar") AS "national_person_id_bk"
			, "prep_excep"."national_person_id" AS "national_person_id"
			, "prep_excep"."first_name" AS "first_name"
			, "prep_excep"."last_name" AS "last_name"
			, "prep_excep"."birthdate" AS "birthdate"
			, "prep_excep"."gender" AS "gender"
			, "prep_excep"."update_timestamp" AS "update_timestamp"
		FROM "prep_excep" "prep_excep"
		INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."customer_number" AS "customer_number"
		, "calculate_bk"."customer_invoice_address_id" AS "customer_invoice_address_id"
		, "calculate_bk"."customer_ship_to_address_id" AS "customer_ship_to_address_id"
		, "calculate_bk"."national_person_id_bk" AS "national_person_id_bk"
		, "calculate_bk"."national_person_id" AS "national_person_id"
		, "calculate_bk"."first_name" AS "first_name"
		, "calculate_bk"."last_name" AS "last_name"
		, "calculate_bk"."birthdate" AS "birthdate"
		, "calculate_bk"."gender" AS "gender"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
