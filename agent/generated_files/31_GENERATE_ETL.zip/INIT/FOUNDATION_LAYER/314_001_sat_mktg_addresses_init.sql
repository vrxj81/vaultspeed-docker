CREATE OR REPLACE FUNCTION "moto_proc"."sat_mktg_addresses_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- sat_tgt

	TRUNCATE TABLE "moto_dv_fl"."sat_mktg_addresses"  CASCADE;

	INSERT INTO "moto_dv_fl"."sat_mktg_addresses"(
		 "addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"address_number"
		,"street_name"
		,"street_number"
		,"postal_code"
		,"city"
		,"province"
		,"update_timestamp"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."addresses_hkey" AS "addresses_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_inr_src"."province"),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_inr_src"."update_timestamp",
				 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, 'N'::text AS "delete_flag"
			, "stg_inr_src"."address_number" AS "address_number"
			, "stg_inr_src"."street_name" AS "street_name"
			, "stg_inr_src"."street_number" AS "street_number"
			, "stg_inr_src"."postal_code" AS "postal_code"
			, "stg_inr_src"."city" AS "city"
			, "stg_inr_src"."province" AS "province"
			, "stg_inr_src"."update_timestamp" AS "update_timestamp"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."addresses_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_mktg_stg"."addresses" "stg_inr_src"
	)
	SELECT 
		  "stg_src"."addresses_hkey" AS "addresses_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."hash_diff" AS "hash_diff"
		, "stg_src"."delete_flag" AS "delete_flag"
		, "stg_src"."address_number" AS "address_number"
		, "stg_src"."street_name" AS "street_name"
		, "stg_src"."street_number" AS "street_number"
		, "stg_src"."postal_code" AS "postal_code"
		, "stg_src"."city" AS "city"
		, "stg_src"."province" AS "province"
		, "stg_src"."update_timestamp" AS "update_timestamp"
	FROM "stg_src" "stg_src"
	WHERE  "stg_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
