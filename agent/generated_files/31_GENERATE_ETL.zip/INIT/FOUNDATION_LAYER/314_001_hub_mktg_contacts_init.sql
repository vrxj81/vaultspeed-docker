CREATE OR REPLACE FUNCTION "moto_proc"."hub_mktg_contacts_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- hub_tgt

	TRUNCATE TABLE "moto_dv_fl"."hub_contacts"  CASCADE;

	INSERT INTO "moto_dv_fl"."hub_contacts"(
		 "contacts_hkey"
		,"load_date"
		,"load_cycle_id"
		,"contact_id_bk"
		,"record_source"
	)
	SELECT DISTINCT 
		  "stg_src"."contacts_hkey" AS "contacts_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."contact_id_bk" AS "contact_id_bk"
		, "stg_src"."record_source" AS "record_source"
	FROM "moto_mktg_stg"."contacts" "stg_src"
	;
END;


END;
$function$;
 
 
