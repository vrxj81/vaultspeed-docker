CREATE OR REPLACE FUNCTION "moto_proc"."lnd_mktg_partycontacts_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- lnd_tgt

	TRUNCATE TABLE "moto_dv_fl"."lnd_party_contacts"  CASCADE;

	INSERT INTO "moto_dv_fl"."lnd_party_contacts"(
		 "lnd_party_contacts_hkey"
		,"load_date"
		,"load_cycle_id"
		,"contacts_hkey"
		,"customers_hkey"
		,"record_source"
	)
	SELECT DISTINCT 
		  "stg_dl_src"."lnd_party_contacts_hkey" AS "lnd_party_contacts_hkey"
		, "stg_dl_src"."load_date" AS "load_date"
		, "stg_dl_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_dl_src"."contacts_hkey" AS "contacts_hkey"
		, "stg_dl_src"."customers_hkey" AS "customers_hkey"
		, "stg_dl_src"."record_source" AS "record_source"
	FROM "moto_mktg_stg"."party_contacts" "stg_dl_src"
	;
END;


END;
$function$;
 
 
