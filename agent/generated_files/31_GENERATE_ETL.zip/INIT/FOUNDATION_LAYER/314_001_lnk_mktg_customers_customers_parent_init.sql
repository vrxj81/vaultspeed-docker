CREATE OR REPLACE FUNCTION "moto_proc"."lnk_mktg_customers_customers_parent_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:29:23
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- lnk_tgt

	TRUNCATE TABLE "moto_dv_fl"."lnk_customers_customers_parent"  CASCADE;

	INSERT INTO "moto_dv_fl"."lnk_customers_customers_parent"(
		 "lnk_customers_customers_parent_hkey"
		,"load_date"
		,"load_cycle_id"
		,"customers_parent_hkey"
		,"customers_hkey"
		,"record_source"
	)
	SELECT DISTINCT 
		  "stg_src"."lnk_customers_customers_parent_hkey" AS "lnk_customers_customers_parent_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."customers_parent_hkey" AS "customers_parent_hkey"
		, "stg_src"."customers_hkey" AS "customers_hkey"
		, "stg_src"."record_source" AS "record_source"
	FROM "moto_mktg_stg"."party" "stg_src"
	;
END;


END;
$function$;
 
 
