CREATE OR REPLACE FUNCTION "moto_proc"."hub_sales_addresses_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- hub_tgt

	INSERT INTO "moto_dv_fl"."hub_addresses"(
		 "addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"street_name_bk"
		,"street_number_bk"
		,"postal_code_bk"
		,"city_bk"
		,"record_source"
	)
	SELECT DISTINCT 
		  "stg_src"."addresses_hkey" AS "addresses_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."street_name_bk" AS "street_name_bk"
		, "stg_src"."street_number_bk" AS "street_number_bk"
		, "stg_src"."postal_code_bk" AS "postal_code_bk"
		, "stg_src"."city_bk" AS "city_bk"
		, "stg_src"."record_source" AS "record_source"
	FROM "moto_sales_stg"."addresses" "stg_src"
	LEFT OUTER JOIN "moto_dv_fl"."hub_addresses" "hub_src" ON  "stg_src"."addresses_hkey" = "hub_src"."addresses_hkey"
	WHERE  "hub_src"."addresses_hkey" IS NULL
	;
END;


END;
$function$;
 
 
