CREATE OR REPLACE FUNCTION "moto_proc"."hub_sales_productfeatureclass_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 13:28:07
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- hub_tgt

	TRUNCATE TABLE "moto_dv_fl"."hub_product_feature_class"  CASCADE;

	INSERT INTO "moto_dv_fl"."hub_product_feature_class"(
		 "product_feature_class_hkey"
		,"load_date"
		,"load_cycle_id"
		,"product_feature_class_code_bk"
		,"record_source"
	)
	SELECT DISTINCT 
		  "stg_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."product_feature_class_code_bk" AS "product_feature_class_code_bk"
		, "stg_src"."record_source" AS "record_source"
	FROM "moto_sales_stg"."product_feature_class" "stg_src"
	;
END;


END;
$function$;
 
 
