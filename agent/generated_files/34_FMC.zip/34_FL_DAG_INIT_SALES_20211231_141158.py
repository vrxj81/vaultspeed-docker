"""
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 14:11:58
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21
 """


from datetime import datetime, timedelta
from pathlib import Path
import json

from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy_operator import DummyOperator

from vs_fmc_plugin.operators.jdbc_to_jdbc import JdbcToJdbcTransfer
from vs_fmc_plugin.operators.jdbc_operator import JdbcOperator


default_args = {
	"owner":"Vaultspeed",
	"retries": 3,
	"retry_delay": timedelta(seconds=10),
	"start_date":datetime.strptime("01-12-2021 23:00:00", "%d-%m-%Y %H:%M:%S")
}

path_to_mtd = Path(Variable.get("path_to_metadata"))
batch_size = Variable.get("batch_size")

if (path_to_mtd / "34_mappings_INIT_SALES_20211231_141158.json").exists():
	with open(path_to_mtd / "34_mappings_INIT_SALES_20211231_141158.json") as file: 
		mappings = json.load(file)

else:
	with open(path_to_mtd / "mappings_INIT_SALES.json") as file: 
		mappings = json.load(file)

INIT_SALES = DAG(
	dag_id="INIT_SALES", 
	default_args=default_args,
	description="Initial Sales Load", 
	schedule_interval="@once", 
	concurrency=8, 
	catchup=False, 
	max_active_runs=1
)

# Create initial fmc tasks
# insert load metadata
fmc_mtd = JdbcOperator(
	task_id="fmc_mtd", 
	jdbc_conn_id="pg_target", 
	sql=["""INSERT INTO "moto_fmc"."fmc_loading_history" 
		SELECT 
			'{{ dag_run.dag_id }}',
			'ms',
			{{ dag_run.id }},
			TO_TIMESTAMP('{{ execution_date.strftime("%Y-%m-%d %H:%M:%S.%f") }}', 'YYYY-MM-DD HH24:MI:SS.US'::varchar),
			null,
			TO_TIMESTAMP('{{ execution_date.strftime("%Y-%m-%d %H:%M:%S.%f") }}', 'YYYY-MM-DD HH24:MI:SS.US'::varchar),
			TO_TIMESTAMP('{{ dag_run.start_date.strftime("%Y-%m-%d %H:%M:%S.%f") }}', 'YYYY-MM-DD HH24:MI:SS.US'::varchar),
			null,
			null
		WHERE NOT EXISTS(SELECT 1 FROM "moto_fmc"."fmc_loading_history" WHERE "load_cycle_id" = {{ dag_run.id }})""", 
		"""TRUNCATE TABLE "moto_sales_mtd"."load_cycle_info" """, 
		"""INSERT INTO "moto_sales_mtd"."load_cycle_info"
			SELECT {{ dag_run.id }},TO_TIMESTAMP('{{ execution_date.strftime("%Y-%m-%d %H:%M:%S.%f") }}', 'YYYY-MM-DD HH24:MI:SS.US'::varchar)"""
	], 
	dag=INIT_SALES
)


tasks = {"fmc_mtd":fmc_mtd}

# Create source data loading tasks
if (path_to_mtd / "34_src_load_mtd_INIT_SALES_20211231_141158.json").exists():
	with open(path_to_mtd / "34_src_load_mtd_INIT_SALES_20211231_141158.json") as file: 
		src_load_mtd = json.load(file)

else:
	with open(path_to_mtd / "src_load_mtd_INIT_SALES.json") as file: 
		src_load_mtd = json.load(file)

for load_task, load_mtd in src_load_mtd.items():
	task = JdbcToJdbcTransfer(
		task_id=f"load_{load_task}", 
		src_mtd=load_mtd["source"], 
		target_mtd=load_mtd["target"], 
		src_conn_id="pg_source_moto", 
		target_conn_id="pg_target", 
		batch_size=batch_size, 
		dag=INIT_SALES
	)
	
	task << fmc_mtd
	tasks[f"load_{load_task}"] = task
	

# Create mapping tasks
for map, info in mappings.items():
	task = JdbcOperator(
		task_id=map, 
		jdbc_conn_id="pg_target", 
		sql=f"""select "moto_proc"."{map}"();""", 
		dag=INIT_SALES
	)
	

	for dep in info["dependencies"]:
		task << tasks[dep]
	
	tasks[map] = task
	

# task to indicate the end of a load
end_task = DummyOperator(
	task_id="end_of_load", 
	dag=INIT_SALES
)

# Analyze tables
if (path_to_mtd / "34_FL_mtd_INIT_SALES_20211231_141158.json").exists():
	with open(path_to_mtd / "34_FL_mtd_INIT_SALES_20211231_141158.json") as file: 
		dv_data = json.load(file)
else:
	with open(path_to_mtd / "FL_mtd_INIT_SALES.json") as file: 
		dv_data = json.load(file)

for table, deps in dv_data.items():
	task = JdbcOperator(
		task_id=f"analyze_{table}", 
		jdbc_conn_id="pg_target", 
		sql=f"analyse \"moto_dv_fl\".\"{table}\";", 
		dag=INIT_SALES
	)
	
	for dep in deps:
		task << tasks[dep]
	end_task << task

# Save load status tasks
fmc_load_fail = JdbcOperator(
	task_id="fmc_load_fail", 
	jdbc_conn_id="pg_target", 
	sql="""
		UPDATE "moto_fmc"."fmc_loading_history" 
		SET "success_flag" = 0,
		    "load_end_date" = TO_TIMESTAMP('{{ macros.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f") }}', 'YYYY-MM-DD HH24:MI:SS.US'::varchar)
		WHERE "load_cycle_id" = {{ dag_run.id }}
		;	""",
	trigger_rule="one_failed",
	dag=INIT_SALES
)
fmc_load_fail << end_task

fmc_load_success = JdbcOperator(
	task_id="fmc_load_success", 
	jdbc_conn_id="pg_target", 
	sql="""
		UPDATE "moto_fmc"."fmc_loading_history" 
		SET "success_flag" = 1,
		    "load_end_date" = TO_TIMESTAMP('{{ macros.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f") }}', 'YYYY-MM-DD HH24:MI:SS.US'::varchar)
		WHERE "load_cycle_id" = {{ dag_run.id }}
		;	""",
	dag=INIT_SALES
)
fmc_load_success << end_task

