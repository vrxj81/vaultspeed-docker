/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34
 */

/* DROP TABLES */

-- START

DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_campaign_motorcycles" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_campaigns" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_camp_moto_channel" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_camp_moto_chan_region" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_camp_part_cont" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_channels" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_e_mails" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_motorcycles" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_party" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_party_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_cdc"."cdc_phones" CASCADE;

-- END


/* CREATE TABLES */

-- START


CREATE TABLE "moto_mktg_cdc"."cdc_addresses"
(
    "address_number" NUMERIC
   ,"street_name" VARCHAR
   ,"street_number" NUMERIC
   ,"postal_code" VARCHAR
   ,"city" VARCHAR
   ,"province" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_campaign_motorcycles"
(
    "campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_class_desc" VARCHAR
   ,"motorcycle_subclass_desc" VARCHAR
   ,"motorcycle_emotion_desc" VARCHAR
   ,"motorcycle_comment" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_campaign_motorcycles" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_campaigns"
(
    "campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"campaign_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_campaigns" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_camp_moto_channel"
(
    "channel_id" NUMERIC
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_name" VARCHAR
   ,"from_date" TIMESTAMP(6)
   ,"to_date" TIMESTAMP(6)
   ,"valid_from_date" TIMESTAMP(6)
   ,"valid_to_date" TIMESTAMP(6)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_camp_moto_channel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_camp_moto_chan_region"
(
    "channel_id" NUMERIC
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"region" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_camp_moto_chan_region" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_camp_part_cont"
(
    "party_number" NUMERIC
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"contact_id" NUMERIC
   ,"marketing_program_code" CHARACTER(30)
   ,"marketing_program_name" CHARACTER(300)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_camp_part_cont" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_channels"
(
    "channel_id" NUMERIC
   ,"channel_code" VARCHAR
   ,"channel_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_channels" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_contacts"
(
    "contact_id" NUMERIC
   ,"contact_type" VARCHAR
   ,"contact_type_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_e_mails"
(
    "contact_id" NUMERIC
   ,"name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_e_mails" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_motorcycles"
(
    "motorcycle_id" NUMERIC
   ,"motorcycle_cc" NUMERIC
   ,"motorcycle_et_code" CHARACTER(30)
   ,"motorcycle_part_code" VARCHAR
   ,"motorcycle_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_motorcycles" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_party"
(
    "party_number" NUMERIC
   ,"parent_party_number" NUMERIC
   ,"name" VARCHAR
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"party_type_code" CHARACTER(6)
   ,"comments" VARCHAR
   ,"address_number" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_party" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_party_contacts"
(
    "party_number" NUMERIC
   ,"contact_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_party_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_cdc"."cdc_phones"
(
    "contact_id" NUMERIC
   ,"phone_number" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_cdc"."cdc_phones" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


-- END


