/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08
 */

/* DROP TABLES */

-- START

DROP TABLE IF EXISTS "moto_sales_stg"."addresses" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."cust_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."customers" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."invoice_lines" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."invoices" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."parts" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."payments" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."product_feat_class_rel" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."product_feature_cat" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."product_feature_class" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."product_features" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."products" CASCADE;
-- END


/* CREATE TABLES */

-- START


CREATE TABLE "moto_sales_stg"."addresses"
(
    "addresses_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"address_number" NUMERIC
   ,"street_name_bk" VARCHAR(375)
   ,"street_number_bk" VARCHAR(375)
   ,"postal_code_bk" VARCHAR(375)
   ,"city_bk" VARCHAR(375)
   ,"coordinates" TEXT
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."cust_addresses"
(
    "lnd_cust_addresses_hkey" BYTEA
   ,"customers_hkey" BYTEA
   ,"addresses_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"address_number" NUMERIC
   ,"customer_number" NUMERIC
   ,"street_name_fk_addressnumber_bk" VARCHAR(375)
   ,"street_number_fk_addressnumber_bk" VARCHAR(375)
   ,"postal_code_fk_addressnumber_bk" VARCHAR(375)
   ,"city_fk_addressnumber_bk" VARCHAR(375)
   ,"national_person_id_fk_customernumber_bk" VARCHAR(1500)
   ,"address_type_seq" VARCHAR(3)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."cust_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."customers"
(
    "customers_hkey" BYTEA
   ,"addresses_ciai_hkey" BYTEA
   ,"addresses_csai_hkey" BYTEA
   ,"lnk_customers_addresses_ciai_hkey" BYTEA
   ,"lnk_customers_addresses_csai_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"src_bk" VARCHAR
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"customers_bk" VARCHAR
   ,"national_person_id_bk" VARCHAR(1500)
   ,"national_person_id" VARCHAR
   ,"street_name_fk_customerinvoiceaddressid_bk" VARCHAR(375)
   ,"street_number_fk_customerinvoiceaddressid_bk" VARCHAR(375)
   ,"postal_code_fk_customerinvoiceaddressid_bk" VARCHAR(375)
   ,"city_fk_customerinvoiceaddressid_bk" VARCHAR(375)
   ,"street_name_fk_customershiptoaddressid_bk" VARCHAR(375)
   ,"street_number_fk_customershiptoaddressid_bk" VARCHAR(375)
   ,"postal_code_fk_customershiptoaddressid_bk" VARCHAR(375)
   ,"city_fk_customershiptoaddressid_bk" VARCHAR(375)
   ,"first_name" VARCHAR
   ,"last_name" VARCHAR
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."invoice_lines"
(
    "lnd_invoice_lines_hkey" BYTEA
   ,"products_hkey" BYTEA
   ,"parts_hkey" BYTEA
   ,"invoices_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"invoice_number" NUMERIC
   ,"invoice_line_number" NUMERIC
   ,"part_id" NUMERIC
   ,"product_id" NUMERIC
   ,"invoice_number_fk_invoicenumber_bk" VARCHAR(1500)
   ,"part_number_fk_partid_bk" VARCHAR(1500)
   ,"product_cc_fk_productid_bk" VARCHAR(500)
   ,"product_et_code_fk_productid_bk" VARCHAR(500)
   ,"product_part_code_fk_productid_bk" VARCHAR(500)
   ,"invoice_line_number_seq" NUMERIC
   ,"amount" NUMERIC
   ,"quantity" NUMERIC
   ,"unit_price" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."invoice_lines" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."invoices"
(
    "invoices_hkey" BYTEA
   ,"customers_hkey" BYTEA
   ,"lnk_invoices_customers_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"invoice_number" NUMERIC
   ,"invoice_customer_id" NUMERIC
   ,"invoice_number_bk" VARCHAR(1500)
   ,"national_person_id_fk_invoicecustomerid_bk" VARCHAR(1500)
   ,"invoice_date" DATE
   ,"amount" NUMERIC
   ,"discount" INTEGER
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."invoices" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."parts"
(
    "parts_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"part_id" NUMERIC
   ,"part_number_bk" VARCHAR(1500)
   ,"part_language_code_seq" VARCHAR(10)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."parts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."payments"
(
    "nhl_payments_hkey" BYTEA
   ,"customers_hkey" BYTEA
   ,"invoices_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"customer_number" NUMERIC
   ,"invoice_number" NUMERIC
   ,"national_person_id_fk_customernumber_bk" VARCHAR(1500)
   ,"invoice_number_fk_invoicenumber_bk" VARCHAR(1500)
   ,"transaction_id" VARCHAR(32)
   ,"date_time" TIMESTAMP(6)
   ,"amount" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."payments" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."product_feat_class_rel"
(
    "lnd_product_feat_class_rel_hkey" BYTEA
   ,"products_hkey" BYTEA
   ,"product_features_hkey" BYTEA
   ,"product_feature_class_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"product_id" NUMERIC
   ,"product_feature_class_id" NUMERIC
   ,"product_feature_id" INTEGER
   ,"product_feature_class_code_fk_productfeatureclassid_bk" VARCHAR(1500)
   ,"product_feature_code_fk_productfeatureid_bk" VARCHAR(1500)
   ,"product_cc_fk_productid_bk" VARCHAR(500)
   ,"product_et_code_fk_productid_bk" VARCHAR(500)
   ,"product_part_code_fk_productid_bk" VARCHAR(500)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."product_feat_class_rel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."product_feature_cat"
(
    "product_feature_cat_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"product_feature_category_id" INTEGER
   ,"product_feature_category_code_bk" VARCHAR(1500)
   ,"prod_feat_cat_language_code_seq" VARCHAR(10)
   ,"prod_feat_cat_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."product_feature_cat" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."product_feature_class"
(
    "product_feature_class_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"product_feature_class_id" NUMERIC
   ,"product_feature_class_code_bk" VARCHAR(1500)
   ,"product_feature_class_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."product_feature_class" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."product_features"
(
    "product_features_hkey" BYTEA
   ,"product_feature_cat_hkey" BYTEA
   ,"lnk_productfeatures_productfeaturecat_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"product_feature_id" INTEGER
   ,"product_feature_cat_id" INTEGER
   ,"product_feature_code_bk" VARCHAR(1500)
   ,"product_feature_category_code_fk_productfeaturecatid_bk" VARCHAR(1500)
   ,"product_feature_language_code_seq" VARCHAR(10)
   ,"product_feature_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."product_features" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."products"
(
    "products_hkey" BYTEA
   ,"products_rpid_hkey" BYTEA
   ,"lnk_products_products_rpid_hkey" BYTEA
   ,"load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"record_source" VARCHAR
   ,"product_id" NUMERIC
   ,"replacement_product_id" NUMERIC
   ,"product_cc_bk" VARCHAR(500)
   ,"product_et_code_bk" VARCHAR(500)
   ,"product_part_code_bk" VARCHAR(500)
   ,"product_cc_fk_replacementproductid_bk" VARCHAR(500)
   ,"product_et_code_fk_replacementproductid_bk" VARCHAR(500)
   ,"product_part_code_fk_replacementproductid_bk" VARCHAR(500)
   ,"product_intro_date" DATE
   ,"product_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_stg"."products" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


-- END


