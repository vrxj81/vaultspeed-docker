/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34
 */

/* DROP TABLES */
-- START
DROP TABLE IF EXISTS "moto_mktg_mtd"."fmc_loading_window_table" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_mtd"."load_cycle_info" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_mtd"."mtd_exception_records" CASCADE;

-- END


/* CREATE TABLES */
-- START

CREATE TABLE "moto_mktg_mtd"."fmc_loading_window_table"
(
	"fmc_begin_lw_timestamp" TIMESTAMP,
	"fmc_end_lw_timestamp" TIMESTAMP
);

COMMENT ON TABLE "moto_mktg_mtd"."fmc_loading_window_table" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_mtd"."load_cycle_info"
(
	"load_cycle_id" INTEGER,
	"load_date" TIMESTAMP
);

COMMENT ON TABLE "moto_mktg_mtd"."load_cycle_info" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_mtd"."mtd_exception_records"
(
	"load_cycle_id" VARCHAR(3),
	"record_type" VARCHAR(3),
	"key_attribute_character" VARCHAR(3),
	"key_attribute_date" VARCHAR(10),
	"key_attribute_integer" VARCHAR(11),
	"key_attribute_numeric" VARCHAR(3),
	"key_attribute_text" VARCHAR(3),
	"key_attribute_timestamp" VARCHAR(19),
	"key_attribute_varchar" VARCHAR(3),
	"attribute_character" VARCHAR(3),
	"attribute_date" VARCHAR(10),
	"attribute_integer" VARCHAR(11),
	"attribute_numeric" VARCHAR(3),
	"attribute_text" VARCHAR(3),
	"attribute_timestamp" VARCHAR(19),
	"attribute_varchar" VARCHAR(3)
);

COMMENT ON TABLE "moto_mktg_mtd"."mtd_exception_records" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


INSERT INTO "moto_mktg_mtd"."mtd_exception_records"
("load_cycle_id", "record_type", "key_attribute_character", "key_attribute_date", "key_attribute_integer", "key_attribute_numeric", "key_attribute_text", "key_attribute_timestamp", "key_attribute_varchar", "attribute_character", "attribute_date", "attribute_integer", "attribute_numeric", "attribute_text", "attribute_timestamp", "attribute_varchar") VALUES ('-2','U','~?~','01/01/2899','-2147483647','-2','~?~','01/01/2899 00:00:00','~?~','~?~','01/01/2899','-2147483647','-2','~?~','01/01/2899 00:00:00','~?~');

INSERT INTO "moto_mktg_mtd"."mtd_exception_records"
("load_cycle_id", "record_type", "key_attribute_character", "key_attribute_date", "key_attribute_integer", "key_attribute_numeric", "key_attribute_text", "key_attribute_timestamp", "key_attribute_varchar", "attribute_character", "attribute_date", "attribute_integer", "attribute_numeric", "attribute_text", "attribute_timestamp", "attribute_varchar") VALUES ('-1','N','0','01/01/2999','-2147483648','-1','0','01/01/2999 00:00:00','0','0','01/01/2999','-2147483648','-1','0','01/01/2999 00:00:00','0');

-- END


