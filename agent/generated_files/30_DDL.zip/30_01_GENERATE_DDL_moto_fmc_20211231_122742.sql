/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08
 */

DROP TABLE IF EXISTS "moto_fmc"."fmc_loading_history" CASCADE;

CREATE TABLE "moto_fmc"."fmc_loading_history"
(
	"dag_name" VARCHAR,
	"src_bk" VARCHAR,
	"load_cycle_id" INTEGER,
	"load_date" TIMESTAMP,
	"fmc_begin_lw_timestamp" TIMESTAMP,
	"fmc_end_lw_timestamp" TIMESTAMP,
	"load_start_date" TIMESTAMP WITH TIME ZONE,
	"load_end_date" TIMESTAMP WITH TIME ZONE,
	"success_flag" INTEGER
);

COMMENT ON TABLE "moto_fmc"."fmc_loading_history" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';

