/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21
 */

/* DROP TABLES */

-- START

DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_codes_to_language" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_cust_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_customers" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_invoice_lines" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_invoices" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_moto_parts" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_payments" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_product_feat_class_rel" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_product_feature_cat" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_product_feature_class" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_product_features" CASCADE;
DROP TABLE IF EXISTS "moto_sales_cdc"."cdc_moto_products" CASCADE;

-- END


/* CREATE TABLES */

-- START


CREATE TABLE "moto_sales_cdc"."cdc_addresses"
(
    "address_number" NUMERIC
   ,"street_name" VARCHAR
   ,"street_number" NUMERIC
   ,"postal_code" VARCHAR
   ,"city" VARCHAR
   ,"coordinates" TEXT
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_codes_to_language"
(
    "code" VARCHAR
   ,"language_code" VARCHAR
   ,"description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_codes_to_language" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_cust_addresses"
(
    "customer_number" NUMERIC
   ,"address_number" NUMERIC
   ,"address_type" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_cust_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_customers"
(
    "customer_number" NUMERIC
   ,"national_person_id" VARCHAR
   ,"first_name" VARCHAR
   ,"last_name" VARCHAR
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"customer_invoice_address_id" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_invoice_lines"
(
    "invoice_line_number" NUMERIC
   ,"invoice_number" NUMERIC
   ,"product_id" NUMERIC
   ,"part_id" NUMERIC
   ,"amount" NUMERIC
   ,"quantity" NUMERIC
   ,"unit_price" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_invoice_lines" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_invoices"
(
    "invoice_number" NUMERIC
   ,"invoice_date" DATE
   ,"invoice_customer_id" NUMERIC
   ,"amount" NUMERIC
   ,"discount" INTEGER
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_invoices" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_moto_parts"
(
    "part_id" NUMERIC
   ,"part_number" VARCHAR
   ,"part_language_code" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_moto_parts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_payments"
(
    "transaction_id" VARCHAR
   ,"date_time" TIMESTAMP(6)
   ,"invoice_number" NUMERIC
   ,"amount" NUMERIC
   ,"customer_number" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_payments" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_product_feat_class_rel"
(
    "product_feature_id" INTEGER
   ,"product_id" NUMERIC
   ,"product_feature_class_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_product_feat_class_rel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_product_feature_cat"
(
    "product_feature_category_id" INTEGER
   ,"product_feature_category_code" VARCHAR
   ,"prod_feat_cat_language_code" VARCHAR
   ,"prod_feat_cat_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_product_feature_cat" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_product_feature_class"
(
    "product_feature_class_id" NUMERIC
   ,"product_feature_class_code" VARCHAR
   ,"product_feature_class_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_product_feature_class" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_product_features"
(
    "product_feature_id" INTEGER
   ,"product_feature_cat_id" INTEGER
   ,"product_feature_code" VARCHAR
   ,"product_feature_language_code" VARCHAR
   ,"product_feature_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_product_features" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


CREATE TABLE "moto_sales_cdc"."cdc_moto_products"
(
    "product_id" NUMERIC
   ,"replacement_product_id" NUMERIC
   ,"product_cc" NUMERIC
   ,"product_et_code" CHARACTER(30)
   ,"product_part_code" VARCHAR
   ,"product_intro_date" DATE
   ,"product_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_sales_cdc"."cdc_moto_products" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 15:06:21';


-- END


