/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08
 */

DROP SCHEMA IF EXISTS "moto_dv_fl" CASCADE;
CREATE SCHEMA "moto_dv_fl";

DROP SCHEMA IF EXISTS "moto_dv_bv" CASCADE;
CREATE SCHEMA "moto_dv_bv";

DROP SCHEMA IF EXISTS "moto_proc" CASCADE;
CREATE SCHEMA "moto_proc";

DROP SCHEMA IF EXISTS "moto_fmc" CASCADE;
CREATE SCHEMA "moto_fmc";

DROP SCHEMA IF EXISTS "moto_pl_proc" CASCADE;
CREATE SCHEMA "moto_pl_proc";

