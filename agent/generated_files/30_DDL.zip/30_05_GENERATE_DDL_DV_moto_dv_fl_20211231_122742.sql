/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08
 */

/* DROP TABLES */

-- START
DROP TABLE IF EXISTS "moto_dv_fl"."nhl_sales_payments" CASCADE;
DROP TABLE IF EXISTS "moto_dv_bv"."las_mktg_customers_addresses_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_dv_bv"."las_mktg_customers_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_bv"."lna_customers_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."ref_sales_codes_to_language" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_mktg_campaign_motorcycles_class" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_mktg_camp_moto_channel" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_mktg_camp_moto_chan_region" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_mktg_camp_part_cont" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_mktg_party_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_sales_cust_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_sales_invoice_lines" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lds_sales_product_feat_class_rel" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_campaign_motorcycles" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_camp_moto_channel" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_camp_moto_chan_region" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_camp_part_cont" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_cust_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_invoice_lines" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_party_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnd_product_feat_class_rel" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_mktg_customers_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_mktg_customers_customers_parent" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_sales_customers_addresses_ciai" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_sales_customers_addresses_csai" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_sales_invoices_customers" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lks_sales_products_products_rpid" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_customers_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_customers_addresses_ciai" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_customers_addresses_csai" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_customers_customers_parent" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_invoices_customers" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_productfeatures_productfeaturecat" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."lnk_products_products_rpid" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_campaigns" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_channels" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_customers" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_e_mails" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_phones" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_mktg_products" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_customers_birth" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_customers_name" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_invoices" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_parts" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_product_feature_cat" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_product_feature_class" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_product_features" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."sat_sales_products" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_campaigns" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_channels" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_customers" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_invoices" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_parts" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_product_feature_cat" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_product_feature_class" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_product_features" CASCADE;
DROP TABLE IF EXISTS "moto_dv_fl"."hub_products" CASCADE;

-- END


/* CREATE TABLES */

-- START

CREATE TABLE "moto_dv_fl"."hub_addresses"
(
    "addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"street_name_bk" VARCHAR(375)
   ,"street_number_bk" VARCHAR(375)
   ,"postal_code_bk" VARCHAR(375)
   ,"city_bk" VARCHAR(375)
   ,CONSTRAINT "hub_addresses_pk" PRIMARY KEY ("addresses_hkey")
   ,CONSTRAINT "hub_addresses_uk" UNIQUE ("street_name_bk", "street_number_bk", "postal_code_bk", "city_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_campaigns"
(
    "campaigns_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"campaign_code_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_campaigns_pk" PRIMARY KEY ("campaigns_hkey")
   ,CONSTRAINT "hub_campaigns_uk" UNIQUE ("campaign_code_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_campaigns" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_channels"
(
    "channels_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"channel_code_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_channels_pk" PRIMARY KEY ("channels_hkey")
   ,CONSTRAINT "hub_channels_uk" UNIQUE ("channel_code_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_channels" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_contacts"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"contact_id_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_contacts_pk" PRIMARY KEY ("contacts_hkey")
   ,CONSTRAINT "hub_contacts_uk" UNIQUE ("contact_id_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_customers"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"src_bk" VARCHAR NOT NULL
   ,"customers_bk" VARCHAR NOT NULL
   ,CONSTRAINT "hub_customers_pk" PRIMARY KEY ("customers_hkey")
   ,CONSTRAINT "hub_customers_uk" UNIQUE ("customers_bk", "src_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_invoices"
(
    "invoices_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"invoice_number_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_invoices_pk" PRIMARY KEY ("invoices_hkey")
   ,CONSTRAINT "hub_invoices_uk" UNIQUE ("invoice_number_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_invoices" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_parts"
(
    "parts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"part_number_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_parts_pk" PRIMARY KEY ("parts_hkey")
   ,CONSTRAINT "hub_parts_uk" UNIQUE ("part_number_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_parts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_product_feature_cat"
(
    "product_feature_cat_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"product_feature_category_code_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_productfeaturecat_pk" PRIMARY KEY ("product_feature_cat_hkey")
   ,CONSTRAINT "hub_productfeaturecat_uk" UNIQUE ("product_feature_category_code_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_product_feature_cat" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_product_feature_class"
(
    "product_feature_class_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"product_feature_class_code_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_productfeatureclass_pk" PRIMARY KEY ("product_feature_class_hkey")
   ,CONSTRAINT "hub_productfeatureclass_uk" UNIQUE ("product_feature_class_code_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_product_feature_class" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_product_features"
(
    "product_features_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"product_feature_code_bk" VARCHAR(1500)
   ,CONSTRAINT "hub_productfeatures_pk" PRIMARY KEY ("product_features_hkey")
   ,CONSTRAINT "hub_productfeatures_uk" UNIQUE ("product_feature_code_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_product_features" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."hub_products"
(
    "products_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"product_cc_bk" VARCHAR(500)
   ,"product_et_code_bk" VARCHAR(500)
   ,"product_part_code_bk" VARCHAR(500)
   ,CONSTRAINT "hub_products_pk" PRIMARY KEY ("products_hkey")
   ,CONSTRAINT "hub_products_uk" UNIQUE ("product_cc_bk", "product_et_code_bk", "product_part_code_bk")
);

COMMENT ON TABLE "moto_dv_fl"."hub_products" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_addresses"
(
    "addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"street_name" VARCHAR
   ,"street_number" NUMERIC
   ,"postal_code" VARCHAR
   ,"city" VARCHAR
   ,"address_number" NUMERIC
   ,"province" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_addresses_uk" UNIQUE ("addresses_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_addresses" ADD CONSTRAINT "sat_mktg_addresses_fk" FOREIGN KEY ("addresses_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_campaigns"
(
    "campaigns_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_start_date_seq" DATE NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"campaign_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_campaigns_uk" UNIQUE ("campaigns_hkey", "load_date", "campaign_start_date_seq")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_campaigns" ADD CONSTRAINT "sat_mktg_campaigns_fk" FOREIGN KEY ("campaigns_hkey") REFERENCES "moto_dv_fl"."hub_campaigns"("campaigns_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_campaigns" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_campaigns" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_channels"
(
    "channels_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"channel_id" NUMERIC
   ,"channel_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_channels_uk" UNIQUE ("channels_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_channels" ADD CONSTRAINT "sat_mktg_channels_fk" FOREIGN KEY ("channels_hkey") REFERENCES "moto_dv_fl"."hub_channels"("channels_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_channels" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_channels" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_contacts"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"contact_id" NUMERIC
   ,"contact_type" VARCHAR
   ,"contact_type_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_contacts_uk" UNIQUE ("contacts_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_contacts" ADD CONSTRAINT "sat_mktg_contacts_fk" FOREIGN KEY ("contacts_hkey") REFERENCES "moto_dv_fl"."hub_contacts"("contacts_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_contacts" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_customers"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"name" VARCHAR
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"party_type_code" CHARACTER(6)
   ,"party_number" NUMERIC
   ,"address_number" NUMERIC
   ,"parent_party_number" NUMERIC
   ,"comments" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_customers_uk" UNIQUE ("customers_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_customers" ADD CONSTRAINT "sat_mktg_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_customers" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_e_mails"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"contact_id" NUMERIC
   ,"name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_emails_uk" UNIQUE ("contacts_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_e_mails" ADD CONSTRAINT "sat_mktg_emails_fk" FOREIGN KEY ("contacts_hkey") REFERENCES "moto_dv_fl"."hub_contacts"("contacts_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_e_mails" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_e_mails" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_phones"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"contact_id" NUMERIC
   ,"phone_number" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_phones_uk" UNIQUE ("contacts_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_phones" ADD CONSTRAINT "sat_mktg_phones_fk" FOREIGN KEY ("contacts_hkey") REFERENCES "moto_dv_fl"."hub_contacts"("contacts_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_phones" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_phones" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_mktg_products"
(
    "products_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_mktg_products_uk" UNIQUE ("products_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_mktg_products" ADD CONSTRAINT "sat_mktg_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."sat_mktg_products" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_mktg_products" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_addresses"
(
    "addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"address_number" NUMERIC
   ,"coordinates" TEXT
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_addresses_uk" UNIQUE ("addresses_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_sales_addresses" ADD CONSTRAINT "sat_sales_addresses_fk" FOREIGN KEY ("addresses_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_customers_birth"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"national_person_id" VARCHAR
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_customers_birth_uk" UNIQUE ("customers_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_sales_customers_birth" ADD CONSTRAINT "sat_sales_customers_birth_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_customers_birth" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_customers_birth" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_customers_name"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"national_person_id" VARCHAR
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"first_name" VARCHAR
   ,"last_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_customers_name_uk" UNIQUE ("customers_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_sales_customers_name" ADD CONSTRAINT "sat_sales_customers_name_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_customers_name" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_customers_name" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_invoices"
(
    "invoices_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"invoice_number" NUMERIC
   ,"invoice_customer_id" NUMERIC
   ,"invoice_date" DATE
   ,"amount" NUMERIC
   ,"discount" INTEGER
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_invoices_uk" UNIQUE ("invoices_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_sales_invoices" ADD CONSTRAINT "sat_sales_invoices_fk" FOREIGN KEY ("invoices_hkey") REFERENCES "moto_dv_fl"."hub_invoices"("invoices_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_invoices" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_invoices" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_parts"
(
    "parts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"part_language_code_seq" VARCHAR NOT NULL
   ,"part_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_parts_uk" UNIQUE ("parts_hkey", "load_date", "part_language_code_seq")
);

ALTER TABLE "moto_dv_fl"."sat_sales_parts" ADD CONSTRAINT "sat_sales_parts_fk" FOREIGN KEY ("parts_hkey") REFERENCES "moto_dv_fl"."hub_parts"("parts_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_parts" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_parts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_product_feature_cat"
(
    "product_feature_cat_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"prod_feat_cat_language_code_seq" VARCHAR NOT NULL
   ,"product_feature_category_id" INTEGER
   ,"prod_feat_cat_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_productfeaturecat_uk" UNIQUE ("product_feature_cat_hkey", "load_date", "prod_feat_cat_language_code_seq")
);

ALTER TABLE "moto_dv_fl"."sat_sales_product_feature_cat" ADD CONSTRAINT "sat_sales_productfeaturecat_fk" FOREIGN KEY ("product_feature_cat_hkey") REFERENCES "moto_dv_fl"."hub_product_feature_cat"("product_feature_cat_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_product_feature_cat" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_product_feature_cat" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_product_feature_class"
(
    "product_feature_class_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_feature_class_id" NUMERIC
   ,"product_feature_class_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_productfeatureclass_uk" UNIQUE ("product_feature_class_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_sales_product_feature_class" ADD CONSTRAINT "sat_sales_productfeatureclass_fk" FOREIGN KEY ("product_feature_class_hkey") REFERENCES "moto_dv_fl"."hub_product_feature_class"("product_feature_class_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_product_feature_class" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_product_feature_class" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_product_features"
(
    "product_features_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_feature_language_code_seq" VARCHAR NOT NULL
   ,"product_feature_id" INTEGER
   ,"product_feature_cat_id" INTEGER
   ,"product_feature_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_productfeatures_uk" UNIQUE ("product_features_hkey", "load_date", "product_feature_language_code_seq")
);

ALTER TABLE "moto_dv_fl"."sat_sales_product_features" ADD CONSTRAINT "sat_sales_productfeatures_fk" FOREIGN KEY ("product_features_hkey") REFERENCES "moto_dv_fl"."hub_product_features"("product_features_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_product_features" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_product_features" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."sat_sales_products"
(
    "products_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_id" NUMERIC
   ,"replacement_product_id" NUMERIC
   ,"product_intro_date" DATE
   ,"product_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "sat_sales_products_uk" UNIQUE ("products_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."sat_sales_products" ADD CONSTRAINT "sat_sales_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."sat_sales_products" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."sat_sales_products" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_customers_addresses"
(
    "lnk_customers_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,"addresses_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_customers_addresses_pk" PRIMARY KEY ("lnk_customers_addresses_hkey")
   ,CONSTRAINT "lnk_customers_addresses_uk" UNIQUE ("customers_hkey", "addresses_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_customers_addresses" ADD CONSTRAINT "lnk_customers_addresses_addresses_fk" FOREIGN KEY ("addresses_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_addresses" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_customers_addresses" ADD CONSTRAINT "lnk_customers_addresses_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_customers_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_customers_addresses_ciai"
(
    "lnk_customers_addresses_ciai_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,"addresses_ciai_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_customers_addresses_ciai_pk" PRIMARY KEY ("lnk_customers_addresses_ciai_hkey")
   ,CONSTRAINT "lnk_customers_addresses_ciai_uk" UNIQUE ("customers_hkey", "addresses_ciai_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_ciai" ADD CONSTRAINT "lnk_customers_addresses_ciai_addresses_fk" FOREIGN KEY ("addresses_ciai_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_ciai" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_ciai" ADD CONSTRAINT "lnk_customers_addresses_ciai_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_ciai" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_customers_addresses_ciai" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_customers_addresses_csai"
(
    "lnk_customers_addresses_csai_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,"addresses_csai_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_customers_addresses_csai_pk" PRIMARY KEY ("lnk_customers_addresses_csai_hkey")
   ,CONSTRAINT "lnk_customers_addresses_csai_uk" UNIQUE ("customers_hkey", "addresses_csai_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_csai" ADD CONSTRAINT "lnk_customers_addresses_csai_addresses_fk" FOREIGN KEY ("addresses_csai_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_csai" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_csai" ADD CONSTRAINT "lnk_customers_addresses_csai_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_addresses_csai" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_customers_addresses_csai" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_customers_customers_parent"
(
    "lnk_customers_customers_parent_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,"customers_parent_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_customers_customers_parent_pk" PRIMARY KEY ("lnk_customers_customers_parent_hkey")
   ,CONSTRAINT "lnk_customers_customers_parent_uk" UNIQUE ("customers_hkey", "customers_parent_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_customers_customers_parent" ADD CONSTRAINT "lnk_customers_customers_parent_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_customers_parent" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_customers_customers_parent" ADD CONSTRAINT "lnk_customers_customers_parent_parent_fk" FOREIGN KEY ("customers_parent_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_customers_customers_parent" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_customers_customers_parent" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_invoices_customers"
(
    "lnk_invoices_customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"invoices_hkey" BYTEA NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_invoices_customers_pk" PRIMARY KEY ("lnk_invoices_customers_hkey")
   ,CONSTRAINT "lnk_invoices_customers_uk" UNIQUE ("invoices_hkey", "customers_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_invoices_customers" ADD CONSTRAINT "lnk_invoices_customers_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_invoices_customers" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_invoices_customers" ADD CONSTRAINT "lnk_invoices_customers_invoices_fk" FOREIGN KEY ("invoices_hkey") REFERENCES "moto_dv_fl"."hub_invoices"("invoices_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_invoices_customers" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_invoices_customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_productfeatures_productfeaturecat"
(
    "lnk_productfeatures_productfeaturecat_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"product_features_hkey" BYTEA NOT NULL
   ,"product_feature_cat_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_productfeatures_productfeaturecat_pk" PRIMARY KEY ("lnk_productfeatures_productfeaturecat_hkey")
   ,CONSTRAINT "lnk_productfeatures_productfeaturecat_uk" UNIQUE ("product_features_hkey", "product_feature_cat_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_productfeatures_productfeaturecat" ADD CONSTRAINT "lnk_productfeatures_productfeaturecat_productfeaturecat_fk" FOREIGN KEY ("product_feature_cat_hkey") REFERENCES "moto_dv_fl"."hub_product_feature_cat"("product_feature_cat_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_productfeatures_productfeaturecat" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_productfeatures_productfeaturecat" ADD CONSTRAINT "lnk_productfeatures_productfeaturecat_productfeatures_fk" FOREIGN KEY ("product_features_hkey") REFERENCES "moto_dv_fl"."hub_product_features"("product_features_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_productfeatures_productfeaturecat" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_productfeatures_productfeaturecat" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnk_products_products_rpid"
(
    "lnk_products_products_rpid_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"products_hkey" BYTEA NOT NULL
   ,"products_rpid_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnk_products_products_rpid_pk" PRIMARY KEY ("lnk_products_products_rpid_hkey")
   ,CONSTRAINT "lnk_products_products_rpid_uk" UNIQUE ("products_hkey", "products_rpid_hkey")
);

ALTER TABLE "moto_dv_fl"."lnk_products_products_rpid" ADD CONSTRAINT "lnk_products_products_rpid_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_products_products_rpid" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnk_products_products_rpid" ADD CONSTRAINT "lnk_products_products_rpid_rpid_fk" FOREIGN KEY ("products_rpid_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."lnk_products_products_rpid" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnk_products_products_rpid" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_mktg_customers_addresses"
(
    "lnk_customers_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"party_number" NUMERIC
   ,"address_number" NUMERIC
   ,CONSTRAINT "lks_mktg_customers_addresses_uk" UNIQUE ("lnk_customers_addresses_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_mktg_customers_addresses" ADD CONSTRAINT "lks_mktg_customers_addresses_fk" FOREIGN KEY ("lnk_customers_addresses_hkey") REFERENCES "moto_dv_fl"."lnk_customers_addresses"("lnk_customers_addresses_hkey");
 ALTER TABLE "moto_dv_fl"."lks_mktg_customers_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_mktg_customers_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_mktg_customers_customers_parent"
(
    "lnk_customers_customers_parent_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"party_number" NUMERIC
   ,"parent_party_number" NUMERIC
   ,CONSTRAINT "lks_mktg_customers_customers_parent_uk" UNIQUE ("lnk_customers_customers_parent_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_mktg_customers_customers_parent" ADD CONSTRAINT "lks_mktg_customers_customers_parent_fk" FOREIGN KEY ("lnk_customers_customers_parent_hkey") REFERENCES "moto_dv_fl"."lnk_customers_customers_parent"("lnk_customers_customers_parent_hkey");
 ALTER TABLE "moto_dv_fl"."lks_mktg_customers_customers_parent" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_mktg_customers_customers_parent" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_sales_customers_addresses_ciai"
(
    "lnk_customers_addresses_ciai_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,CONSTRAINT "lks_sales_customers_addresses_ciai_uk" UNIQUE ("lnk_customers_addresses_ciai_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_sales_customers_addresses_ciai" ADD CONSTRAINT "lks_sales_customers_addresses_ciai_fk" FOREIGN KEY ("lnk_customers_addresses_ciai_hkey") REFERENCES "moto_dv_fl"."lnk_customers_addresses_ciai"("lnk_customers_addresses_ciai_hkey");
 ALTER TABLE "moto_dv_fl"."lks_sales_customers_addresses_ciai" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_sales_customers_addresses_ciai" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_sales_customers_addresses_csai"
(
    "lnk_customers_addresses_csai_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"customer_number" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,CONSTRAINT "lks_sales_customers_addresses_csai_uk" UNIQUE ("lnk_customers_addresses_csai_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_sales_customers_addresses_csai" ADD CONSTRAINT "lks_sales_customers_addresses_csai_fk" FOREIGN KEY ("lnk_customers_addresses_csai_hkey") REFERENCES "moto_dv_fl"."lnk_customers_addresses_csai"("lnk_customers_addresses_csai_hkey");
 ALTER TABLE "moto_dv_fl"."lks_sales_customers_addresses_csai" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_sales_customers_addresses_csai" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_sales_invoices_customers"
(
    "lnk_invoices_customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"invoice_number" NUMERIC
   ,"invoice_customer_id" NUMERIC
   ,CONSTRAINT "lks_sales_invoices_customers_uk" UNIQUE ("lnk_invoices_customers_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_sales_invoices_customers" ADD CONSTRAINT "lks_sales_invoices_customers_fk" FOREIGN KEY ("lnk_invoices_customers_hkey") REFERENCES "moto_dv_fl"."lnk_invoices_customers"("lnk_invoices_customers_hkey");
 ALTER TABLE "moto_dv_fl"."lks_sales_invoices_customers" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_sales_invoices_customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat"
(
    "lnk_productfeatures_productfeaturecat_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_feature_id" INTEGER
   ,"product_feature_cat_id" INTEGER
   ,CONSTRAINT "lks_sales_productfeatures_productfeaturecat_uk" UNIQUE ("lnk_productfeatures_productfeaturecat_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat" ADD CONSTRAINT "lks_sales_productfeatures_productfeaturecat_fk" FOREIGN KEY ("lnk_productfeatures_productfeaturecat_hkey") REFERENCES "moto_dv_fl"."lnk_productfeatures_productfeaturecat"("lnk_productfeatures_productfeaturecat_hkey");
 ALTER TABLE "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lks_sales_products_products_rpid"
(
    "lnk_products_products_rpid_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_id" NUMERIC
   ,"replacement_product_id" NUMERIC
   ,CONSTRAINT "lks_sales_products_products_rpid_uk" UNIQUE ("lnk_products_products_rpid_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lks_sales_products_products_rpid" ADD CONSTRAINT "lks_sales_products_products_rpid_fk" FOREIGN KEY ("lnk_products_products_rpid_hkey") REFERENCES "moto_dv_fl"."lnk_products_products_rpid"("lnk_products_products_rpid_hkey");
 ALTER TABLE "moto_dv_fl"."lks_sales_products_products_rpid" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lks_sales_products_products_rpid" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_campaign_motorcycles"
(
    "lnd_campaign_motorcycles_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"campaigns_hkey" BYTEA NOT NULL
   ,"products_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_campaignmotorcycles_pk" PRIMARY KEY ("lnd_campaign_motorcycles_hkey")
   ,CONSTRAINT "lnd_campaignmotorcycles_uk" UNIQUE ("campaigns_hkey", "products_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_campaign_motorcycles" ADD CONSTRAINT "lnd_campaignmotorcycles_campaigns_fk" FOREIGN KEY ("campaigns_hkey") REFERENCES "moto_dv_fl"."hub_campaigns"("campaigns_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_campaign_motorcycles" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_campaign_motorcycles" ADD CONSTRAINT "lnd_campaignmotorcycles_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_campaign_motorcycles" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_campaign_motorcycles" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_camp_moto_channel"
(
    "lnd_camp_moto_channel_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"campaigns_hkey" BYTEA NOT NULL
   ,"channels_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_campmotochannel_pk" PRIMARY KEY ("lnd_camp_moto_channel_hkey")
   ,CONSTRAINT "lnd_campmotochannel_uk" UNIQUE ("campaigns_hkey", "channels_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_camp_moto_channel" ADD CONSTRAINT "lnd_campmotochannel_campaigns_fk" FOREIGN KEY ("campaigns_hkey") REFERENCES "moto_dv_fl"."hub_campaigns"("campaigns_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_moto_channel" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_camp_moto_channel" ADD CONSTRAINT "lnd_campmotochannel_channels_fk" FOREIGN KEY ("channels_hkey") REFERENCES "moto_dv_fl"."hub_channels"("channels_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_moto_channel" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_camp_moto_channel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_camp_moto_chan_region"
(
    "lnd_camp_moto_chan_region_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"campaigns_hkey" BYTEA NOT NULL
   ,"channels_hkey" BYTEA NOT NULL
   ,"products_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_campmotochanregion_pk" PRIMARY KEY ("lnd_camp_moto_chan_region_hkey")
   ,CONSTRAINT "lnd_campmotochanregion_uk" UNIQUE ("campaigns_hkey", "channels_hkey", "products_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" ADD CONSTRAINT "lnd_campmotochanregion_campaigns_fk" FOREIGN KEY ("campaigns_hkey") REFERENCES "moto_dv_fl"."hub_campaigns"("campaigns_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" ADD CONSTRAINT "lnd_campmotochanregion_channels_fk" FOREIGN KEY ("channels_hkey") REFERENCES "moto_dv_fl"."hub_channels"("channels_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" ADD CONSTRAINT "lnd_campmotochanregion_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_camp_moto_chan_region" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_camp_part_cont"
(
    "lnd_camp_part_cont_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"campaigns_hkey" BYTEA NOT NULL
   ,"contacts_hkey" BYTEA NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_camppartcont_pk" PRIMARY KEY ("lnd_camp_part_cont_hkey")
   ,CONSTRAINT "lnd_camppartcont_uk" UNIQUE ("campaigns_hkey", "contacts_hkey", "customers_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_camp_part_cont" ADD CONSTRAINT "lnd_camppartcont_campaigns_fk" FOREIGN KEY ("campaigns_hkey") REFERENCES "moto_dv_fl"."hub_campaigns"("campaigns_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_part_cont" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_camp_part_cont" ADD CONSTRAINT "lnd_camppartcont_contacts_fk" FOREIGN KEY ("contacts_hkey") REFERENCES "moto_dv_fl"."hub_contacts"("contacts_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_part_cont" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_camp_part_cont" ADD CONSTRAINT "lnd_camppartcont_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_camp_part_cont" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_camp_part_cont" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_cust_addresses"
(
    "lnd_cust_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"addresses_hkey" BYTEA NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_custaddresses_pk" PRIMARY KEY ("lnd_cust_addresses_hkey")
   ,CONSTRAINT "lnd_custaddresses_uk" UNIQUE ("addresses_hkey", "customers_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_cust_addresses" ADD CONSTRAINT "lnd_custaddresses_addresses_fk" FOREIGN KEY ("addresses_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_cust_addresses" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_cust_addresses" ADD CONSTRAINT "lnd_custaddresses_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_cust_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_cust_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_invoice_lines"
(
    "lnd_invoice_lines_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"invoices_hkey" BYTEA NOT NULL
   ,"parts_hkey" BYTEA NOT NULL
   ,"products_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_invoicelines_pk" PRIMARY KEY ("lnd_invoice_lines_hkey")
   ,CONSTRAINT "lnd_invoicelines_uk" UNIQUE ("invoices_hkey", "parts_hkey", "products_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_invoice_lines" ADD CONSTRAINT "lnd_invoicelines_invoices_fk" FOREIGN KEY ("invoices_hkey") REFERENCES "moto_dv_fl"."hub_invoices"("invoices_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_invoice_lines" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_invoice_lines" ADD CONSTRAINT "lnd_invoicelines_parts_fk" FOREIGN KEY ("parts_hkey") REFERENCES "moto_dv_fl"."hub_parts"("parts_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_invoice_lines" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_invoice_lines" ADD CONSTRAINT "lnd_invoicelines_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_invoice_lines" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_invoice_lines" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_party_contacts"
(
    "lnd_party_contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"contacts_hkey" BYTEA NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_partycontacts_pk" PRIMARY KEY ("lnd_party_contacts_hkey")
   ,CONSTRAINT "lnd_partycontacts_uk" UNIQUE ("contacts_hkey", "customers_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_party_contacts" ADD CONSTRAINT "lnd_partycontacts_contacts_fk" FOREIGN KEY ("contacts_hkey") REFERENCES "moto_dv_fl"."hub_contacts"("contacts_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_party_contacts" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_party_contacts" ADD CONSTRAINT "lnd_partycontacts_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_party_contacts" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_party_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lnd_product_feat_class_rel"
(
    "lnd_product_feat_class_rel_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"product_feature_class_hkey" BYTEA NOT NULL
   ,"product_features_hkey" BYTEA NOT NULL
   ,"products_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lnd_productfeatclassrel_pk" PRIMARY KEY ("lnd_product_feat_class_rel_hkey")
   ,CONSTRAINT "lnd_productfeatclassrel_uk" UNIQUE ("product_feature_class_hkey", "product_features_hkey", "products_hkey")
);

ALTER TABLE "moto_dv_fl"."lnd_product_feat_class_rel" ADD CONSTRAINT "lnd_productfeatclassrel_productfeatureclass_fk" FOREIGN KEY ("product_feature_class_hkey") REFERENCES "moto_dv_fl"."hub_product_feature_class"("product_feature_class_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_product_feat_class_rel" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_product_feat_class_rel" ADD CONSTRAINT "lnd_productfeatclassrel_productfeatures_fk" FOREIGN KEY ("product_features_hkey") REFERENCES "moto_dv_fl"."hub_product_features"("product_features_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_product_feat_class_rel" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."lnd_product_feat_class_rel" ADD CONSTRAINT "lnd_productfeatclassrel_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_fl"."lnd_product_feat_class_rel" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lnd_product_feat_class_rel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_class"
(
    "lnd_campaign_motorcycles_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_class_desc" VARCHAR
   ,"motorcycle_subclass_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_mktg_campaignmotorcycles_class_uk" UNIQUE ("lnd_campaign_motorcycles_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_class" ADD CONSTRAINT "lds_mktg_campaignmotorcycles_class_fk" FOREIGN KEY ("lnd_campaign_motorcycles_hkey") REFERENCES "moto_dv_fl"."lnd_campaign_motorcycles"("lnd_campaign_motorcycles_hkey");
 ALTER TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_class" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_class" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo"
(
    "lnd_campaign_motorcycles_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_emotion_desc" VARCHAR
   ,"motorcycle_comment" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_mktg_campaignmotorcycles_emo_uk" UNIQUE ("lnd_campaign_motorcycles_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" ADD CONSTRAINT "lds_mktg_campaignmotorcycles_emo_fk" FOREIGN KEY ("lnd_campaign_motorcycles_hkey") REFERENCES "moto_dv_fl"."lnd_campaign_motorcycles"("lnd_campaign_motorcycles_hkey");
 ALTER TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_mktg_camp_moto_channel"
(
    "lnd_camp_moto_channel_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"from_date_seq" TIMESTAMP(6) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"channel_id" NUMERIC
   ,"motorcycle_name" VARCHAR
   ,"to_date" TIMESTAMP(6)
   ,"valid_from_date" TIMESTAMP(6)
   ,"valid_to_date" TIMESTAMP(6)
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_mktg_campmotochannel_uk" UNIQUE ("from_date_seq", "lnd_camp_moto_channel_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_mktg_camp_moto_channel" ADD CONSTRAINT "lds_mktg_campmotochannel_fk" FOREIGN KEY ("lnd_camp_moto_channel_hkey") REFERENCES "moto_dv_fl"."lnd_camp_moto_channel"("lnd_camp_moto_channel_hkey");
 ALTER TABLE "moto_dv_fl"."lds_mktg_camp_moto_channel" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_mktg_camp_moto_channel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_mktg_camp_moto_chan_region"
(
    "lnd_camp_moto_chan_region_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"region_seq" VARCHAR NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"channel_id" NUMERIC
   ,"motorcycle_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_mktg_campmotochanregion_uk" UNIQUE ("region_seq", "lnd_camp_moto_chan_region_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_mktg_camp_moto_chan_region" ADD CONSTRAINT "lds_mktg_campmotochanregion_fk" FOREIGN KEY ("lnd_camp_moto_chan_region_hkey") REFERENCES "moto_dv_fl"."lnd_camp_moto_chan_region"("lnd_camp_moto_chan_region_hkey");
 ALTER TABLE "moto_dv_fl"."lds_mktg_camp_moto_chan_region" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_mktg_camp_moto_chan_region" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_mktg_camp_part_cont"
(
    "lnd_camp_part_cont_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"contact_id" NUMERIC
   ,"party_number" NUMERIC
   ,"marketing_program_code" CHARACTER(30)
   ,"marketing_program_name" CHARACTER(300)
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_mktg_camppartcont_uk" UNIQUE ("lnd_camp_part_cont_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_mktg_camp_part_cont" ADD CONSTRAINT "lds_mktg_camppartcont_fk" FOREIGN KEY ("lnd_camp_part_cont_hkey") REFERENCES "moto_dv_fl"."lnd_camp_part_cont"("lnd_camp_part_cont_hkey");
 ALTER TABLE "moto_dv_fl"."lds_mktg_camp_part_cont" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_mktg_camp_part_cont" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_mktg_party_contacts"
(
    "lnd_party_contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"party_number" NUMERIC
   ,"contact_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_mktg_partycontacts_uk" UNIQUE ("lnd_party_contacts_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_mktg_party_contacts" ADD CONSTRAINT "lds_mktg_partycontacts_fk" FOREIGN KEY ("lnd_party_contacts_hkey") REFERENCES "moto_dv_fl"."lnd_party_contacts"("lnd_party_contacts_hkey");
 ALTER TABLE "moto_dv_fl"."lds_mktg_party_contacts" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_mktg_party_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_sales_cust_addresses"
(
    "lnd_cust_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"address_type_seq" VARCHAR NOT NULL
   ,"address_number" NUMERIC
   ,"customer_number" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_sales_custaddresses_uk" UNIQUE ("address_type_seq", "lnd_cust_addresses_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_sales_cust_addresses" ADD CONSTRAINT "lds_sales_custaddresses_fk" FOREIGN KEY ("lnd_cust_addresses_hkey") REFERENCES "moto_dv_fl"."lnd_cust_addresses"("lnd_cust_addresses_hkey");
 ALTER TABLE "moto_dv_fl"."lds_sales_cust_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_sales_cust_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_sales_invoice_lines"
(
    "lnd_invoice_lines_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"invoice_number" NUMERIC NOT NULL
   ,"invoice_line_number_seq" NUMERIC NOT NULL
   ,"part_id" NUMERIC
   ,"product_id" NUMERIC
   ,"amount" NUMERIC
   ,"quantity" NUMERIC
   ,"unit_price" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_sales_invoicelines_uk" UNIQUE ("invoice_line_number_seq", "lnd_invoice_lines_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_sales_invoice_lines" ADD CONSTRAINT "lds_sales_invoicelines_fk" FOREIGN KEY ("lnd_invoice_lines_hkey") REFERENCES "moto_dv_fl"."lnd_invoice_lines"("lnd_invoice_lines_hkey");
 ALTER TABLE "moto_dv_fl"."lds_sales_invoice_lines" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_sales_invoice_lines" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."lds_sales_product_feat_class_rel"
(
    "lnd_product_feat_class_rel_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_id" NUMERIC
   ,"product_feature_class_id" NUMERIC
   ,"product_feature_id" INTEGER
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "lds_sales_productfeatclassrel_uk" UNIQUE ("lnd_product_feat_class_rel_hkey", "load_date")
);

ALTER TABLE "moto_dv_fl"."lds_sales_product_feat_class_rel" ADD CONSTRAINT "lds_sales_productfeatclassrel_fk" FOREIGN KEY ("lnd_product_feat_class_rel_hkey") REFERENCES "moto_dv_fl"."lnd_product_feat_class_rel"("lnd_product_feat_class_rel_hkey");
 ALTER TABLE "moto_dv_fl"."lds_sales_product_feat_class_rel" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."lds_sales_product_feat_class_rel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."ref_sales_codes_to_language"
(
    "load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"language_code" VARCHAR
   ,"code" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"description" VARCHAR
   ,CONSTRAINT "codes_to_language_pk" PRIMARY KEY ("load_date", "code", "language_code")
);

COMMENT ON TABLE "moto_dv_fl"."ref_sales_codes_to_language" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_bv"."lna_customers_addresses"
(
    "lna_customers_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,"addresses_hkey" BYTEA NOT NULL
   ,CONSTRAINT "lna_customers_addresses_pk" PRIMARY KEY ("lna_customers_addresses_hkey")
   ,CONSTRAINT "lna_customers_addresses_uk" UNIQUE ("customers_hkey", "addresses_hkey")
);

ALTER TABLE "moto_dv_bv"."lna_customers_addresses" ADD CONSTRAINT "lna_customers_addresses_addresses_fk" FOREIGN KEY ("addresses_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_bv"."lna_customers_addresses" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."lna_customers_addresses" ADD CONSTRAINT "lna_customers_addresses_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_bv"."lna_customers_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_bv"."lna_customers_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_bv"."las_mktg_customers_addresses"
(
    "lna_customers_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"address_number" NUMERIC
   ,"party_number" NUMERIC NOT NULL
   ,CONSTRAINT "las_mktg_customers_addresses_uk" UNIQUE ("lna_customers_addresses_hkey", "load_date")
);

ALTER TABLE "moto_dv_bv"."las_mktg_customers_addresses" ADD CONSTRAINT "las_mktg_customers_addresses_fk" FOREIGN KEY ("lna_customers_addresses_hkey") REFERENCES "moto_dv_bv"."lna_customers_addresses"("lna_customers_addresses_hkey");
 ALTER TABLE "moto_dv_bv"."las_mktg_customers_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_bv"."las_mktg_customers_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_bv"."las_mktg_customers_addresses_tmp"
(
    "lna_customers_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"address_number" NUMERIC
   ,"party_number" NUMERIC NOT NULL
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"addresses_hkey" BYTEA
   ,"customers_hkey" BYTEA
);

COMMENT ON TABLE "moto_dv_bv"."las_mktg_customers_addresses_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_dv_fl"."nhl_sales_payments"
(
    "nhl_payments_hkey" BYTEA NOT NULL
   ,"invoices_hkey" BYTEA NOT NULL
   ,"customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"record_source" VARCHAR NOT NULL
   ,"customer_number" NUMERIC
   ,"invoice_number" NUMERIC
   ,"transaction_id" VARCHAR
   ,"date_time" TIMESTAMP(6)
   ,"amount" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,CONSTRAINT "nhl_payments_pk" PRIMARY KEY ("nhl_payments_hkey", "transaction_id")
);

ALTER TABLE "moto_dv_fl"."nhl_sales_payments" ADD CONSTRAINT "nhl_payments_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_fl"."nhl_sales_payments" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_fl"."nhl_sales_payments" ADD CONSTRAINT "nhl_payments_invoices_fk" FOREIGN KEY ("invoices_hkey") REFERENCES "moto_dv_fl"."hub_invoices"("invoices_hkey");
 ALTER TABLE "moto_dv_fl"."nhl_sales_payments" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_fl"."nhl_sales_payments" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


-- END


