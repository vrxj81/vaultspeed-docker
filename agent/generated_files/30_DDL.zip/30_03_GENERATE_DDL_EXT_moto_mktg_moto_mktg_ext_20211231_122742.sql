/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34
 */

/* DROP TABLES */

-- START

DROP TABLE IF EXISTS "moto_mktg_ext"."addresses" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."campaign_motorcycles" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."campaigns" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."camp_moto_channel" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."camp_moto_chan_region" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."camp_part_cont" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."channels" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."contacts" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."e_mails" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."motorcycles" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."party" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."party_contacts" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_ext"."phones" CASCADE;

-- END


/* CREATE TABLES */

-- START


CREATE TABLE "moto_mktg_ext"."addresses"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"address_number" NUMERIC
   ,"street_name_bk" VARCHAR(375)
   ,"street_name" VARCHAR
   ,"street_number_bk" VARCHAR(375)
   ,"street_number" NUMERIC
   ,"postal_code_bk" VARCHAR(375)
   ,"postal_code" VARCHAR
   ,"city_bk" VARCHAR(375)
   ,"city" VARCHAR
   ,"province" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."campaign_motorcycles"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"campaign_code_fk_campaignstartdate_bk" VARCHAR(1500)
   ,"motorcycle_class_desc" VARCHAR
   ,"motorcycle_subclass_desc" VARCHAR
   ,"motorcycle_emotion_desc" VARCHAR
   ,"motorcycle_comment" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."campaign_motorcycles" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."campaigns"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"campaign_code_bk" VARCHAR(1500)
   ,"campaign_start_date_seq" DATE
   ,"campaign_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."campaigns" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."camp_moto_channel"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"channel_id" NUMERIC
   ,"campaign_code_fk_campaignstartdate_bk" VARCHAR(1500)
   ,"from_date_seq" TIMESTAMP(6)
   ,"motorcycle_name" VARCHAR
   ,"to_date" TIMESTAMP(6)
   ,"valid_from_date" TIMESTAMP(6)
   ,"valid_to_date" TIMESTAMP(6)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."camp_moto_channel" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."camp_moto_chan_region"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"channel_id" NUMERIC
   ,"motorcycle_id" NUMERIC
   ,"campaign_code_fk_campaignstartdate_bk" VARCHAR(1500)
   ,"region_seq" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."camp_moto_chan_region" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."camp_part_cont"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"contact_id" NUMERIC
   ,"party_number" NUMERIC
   ,"campaign_code_fk_campaignstartdate_bk" VARCHAR(1500)
   ,"contact_id_fk_contactid_bk" VARCHAR(1500)
   ,"marketing_program_code" CHARACTER(30)
   ,"marketing_program_name" CHARACTER(300)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."camp_part_cont" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."channels"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"channel_id" NUMERIC
   ,"channel_code_bk" VARCHAR(1500)
   ,"channel_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."channels" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."contacts"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"contact_id" NUMERIC
   ,"contact_id_bk" VARCHAR(1500)
   ,"contact_type" VARCHAR
   ,"contact_type_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."e_mails"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"contact_id" NUMERIC
   ,"contact_id_fk_contactid_bk" VARCHAR(1500)
   ,"name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."e_mails" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."motorcycles"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_cc_bk" VARCHAR(500)
   ,"motorcycle_et_code_bk" VARCHAR(500)
   ,"motorcycle_part_code_bk" VARCHAR(500)
   ,"motorcycle_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."motorcycles" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."party"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"party_number" NUMERIC
   ,"address_number" NUMERIC
   ,"parent_party_number" NUMERIC
   ,"name_bk" VARCHAR(375)
   ,"name" VARCHAR
   ,"birthdate_bk" VARCHAR(375)
   ,"birthdate" DATE
   ,"gender_bk" VARCHAR(375)
   ,"gender" CHARACTER(24)
   ,"party_type_code_bk" VARCHAR(375)
   ,"party_type_code" CHARACTER(6)
   ,"street_name_fk_addressnumber_bk" VARCHAR(375)
   ,"street_number_fk_addressnumber_bk" VARCHAR(375)
   ,"postal_code_fk_addressnumber_bk" VARCHAR(375)
   ,"city_fk_addressnumber_bk" VARCHAR(375)
   ,"name_fk_parentpartynumber_bk" VARCHAR(375)
   ,"birthdate_fk_parentpartynumber_bk" VARCHAR(375)
   ,"gender_fk_parentpartynumber_bk" VARCHAR(375)
   ,"party_type_code_fk_parentpartynumber_bk" VARCHAR(375)
   ,"comments" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."party" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."party_contacts"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"party_number" NUMERIC
   ,"contact_id" NUMERIC
   ,"contact_id_fk_contactid_bk" VARCHAR(1500)
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."party_contacts" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


CREATE TABLE "moto_mktg_ext"."phones"
(
    "load_date" TIMESTAMP
   ,"load_cycle_id" INTEGER
   ,"jrn_flag" VARCHAR
   ,"record_type" VARCHAR
   ,"contact_id" NUMERIC
   ,"contact_id_fk_contactid_bk" VARCHAR(1500)
   ,"phone_number" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
);

COMMENT ON TABLE "moto_mktg_ext"."phones" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 15:16:34';


-- END


