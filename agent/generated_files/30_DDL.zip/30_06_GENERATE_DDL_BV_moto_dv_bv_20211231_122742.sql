/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44
 */

/* DROP TABLES */

-- START
DROP TABLE IF EXISTS "moto_dv_bv"."pit_daily_snapshot_addresses" CASCADE;
DROP TABLE IF EXISTS "moto_dv_bv"."pit_daily_snapshot_customers" CASCADE;
DROP TABLE IF EXISTS "moto_dv_bv"."pit_daily_snapshot_products" CASCADE;
DROP TABLE IF EXISTS "moto_dv_bv"."bridge_cust_part_pro_fea" CASCADE;
DROP TABLE IF EXISTS "moto_fmc"."fmc_bv_loading_window_table" CASCADE;
DROP TABLE IF EXISTS "moto_fmc"."load_cycle_info" CASCADE;
DROP TABLE IF EXISTS "moto_fmc"."dv_load_cycle_info" CASCADE;

-- END


/* CREATE TABLES */

-- START

CREATE TABLE "moto_dv_bv"."pit_daily_snapshot_addresses"
(
	 "pit_daily_snapshot_addresses_hkey" BYTEA
	,"snapshot_timestamp" TIMESTAMP
	,"load_cycle_id" INTEGER
	,"addresses_hkey" BYTEA
	,"sat_mktg_addresses_hkey" BYTEA
	,"sat_mktg_addresses_load_date" TIMESTAMP
	,"sat_sales_addresses_hkey" BYTEA
	,"sat_sales_addresses_load_date" TIMESTAMP
   ,CONSTRAINT "pit_daily_snapshot_addresses_pk" PRIMARY KEY ("pit_daily_snapshot_addresses_hkey")
   ,CONSTRAINT "pit_daily_snapshot_addresses_uk" UNIQUE ("addresses_hkey", "snapshot_timestamp")
);

ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" ADD CONSTRAINT "pit_daily_snapshot_addresses_fk" FOREIGN KEY ("addresses_hkey") REFERENCES "moto_dv_fl"."hub_addresses"("addresses_hkey");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" ADD CONSTRAINT "pit_daily_snapshot_addresses_sat_mktg_fk" FOREIGN KEY ("sat_mktg_addresses_hkey", "sat_mktg_addresses_load_date") REFERENCES "moto_dv_fl"."sat_mktg_addresses"("addresses_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" ADD CONSTRAINT "pit_daily_snapshot_addresses_sat_sales_fk" FOREIGN KEY ("sat_sales_addresses_hkey", "sat_sales_addresses_load_date") REFERENCES "moto_dv_fl"."sat_sales_addresses"("addresses_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_bv"."pit_daily_snapshot_addresses" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


CREATE TABLE "moto_dv_bv"."pit_daily_snapshot_customers"
(
	 "pit_daily_snapshot_customers_hkey" BYTEA
	,"snapshot_timestamp" TIMESTAMP
	,"load_cycle_id" INTEGER
	,"customers_hkey" BYTEA
	,"sat_mktg_customers_hkey" BYTEA
	,"sat_mktg_customers_load_date" TIMESTAMP
	,"sat_sales_customers_name_hkey" BYTEA
	,"sat_sales_customers_name_load_date" TIMESTAMP
	,"sat_sales_customers_birth_hkey" BYTEA
	,"sat_sales_customers_birth_load_date" TIMESTAMP
   ,CONSTRAINT "pit_daily_snapshot_customers_pk" PRIMARY KEY ("pit_daily_snapshot_customers_hkey")
   ,CONSTRAINT "pit_daily_snapshot_customers_uk" UNIQUE ("customers_hkey", "snapshot_timestamp")
);

ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" ADD CONSTRAINT "pit_daily_snapshot_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" ADD CONSTRAINT "pit_daily_snapshot_customers_sat_mktg_fk" FOREIGN KEY ("sat_mktg_customers_hkey", "sat_mktg_customers_load_date") REFERENCES "moto_dv_fl"."sat_mktg_customers"("customers_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" ADD CONSTRAINT "pit_daily_snapshot_customers_sat_sales_birth_fk" FOREIGN KEY ("sat_sales_customers_birth_hkey", "sat_sales_customers_birth_load_date") REFERENCES "moto_dv_fl"."sat_sales_customers_birth"("customers_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" ADD CONSTRAINT "pit_daily_snapshot_customers_sat_sales_name_fk" FOREIGN KEY ("sat_sales_customers_name_hkey", "sat_sales_customers_name_load_date") REFERENCES "moto_dv_fl"."sat_sales_customers_name"("customers_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_customers" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_bv"."pit_daily_snapshot_customers" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


CREATE TABLE "moto_dv_bv"."pit_daily_snapshot_products"
(
	 "pit_daily_snapshot_products_hkey" BYTEA
	,"snapshot_timestamp" TIMESTAMP
	,"load_cycle_id" INTEGER
	,"products_hkey" BYTEA
	,"sat_mktg_products_hkey" BYTEA
	,"sat_mktg_products_load_date" TIMESTAMP
	,"sat_sales_products_hkey" BYTEA
	,"sat_sales_products_load_date" TIMESTAMP
   ,CONSTRAINT "pit_daily_snapshot_products_pk" PRIMARY KEY ("pit_daily_snapshot_products_hkey")
   ,CONSTRAINT "pit_daily_snapshot_products_uk" UNIQUE ("products_hkey", "snapshot_timestamp")
);

ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_products" ADD CONSTRAINT "pit_daily_snapshot_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_products" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_products" ADD CONSTRAINT "pit_daily_snapshot_products_sat_mktg_fk" FOREIGN KEY ("sat_mktg_products_hkey", "sat_mktg_products_load_date") REFERENCES "moto_dv_fl"."sat_mktg_products"("products_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_products" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_products" ADD CONSTRAINT "pit_daily_snapshot_products_sat_sales_fk" FOREIGN KEY ("sat_sales_products_hkey", "sat_sales_products_load_date") REFERENCES "moto_dv_fl"."sat_sales_products"("products_hkey", "load_date");
 ALTER TABLE "moto_dv_bv"."pit_daily_snapshot_products" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_bv"."pit_daily_snapshot_products" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


CREATE TABLE "moto_dv_bv"."bridge_cust_part_pro_fea"
(
	 "load_date" TIMESTAMP
	,"load_cycle_id" INTEGER
	,"products_hkey" BYTEA
	,"customers_hkey" BYTEA
	,"product_feature_class_hkey" BYTEA
	,"parts_hkey" BYTEA
	,"invoices_hkey" BYTEA
	,"lnk_invoices_customers_hkey" BYTEA
	,"lnd_invoice_lines_hkey" BYTEA
	,"lnd_product_feat_class_rel_hkey" BYTEA
	,"product_cc_bk" VARCHAR(500)
	,"product_et_code_bk" VARCHAR(500)
	,"product_part_code_bk" VARCHAR(500)
	,"customers_bk" VARCHAR
	,"product_feature_class_code_bk" VARCHAR(1500)
	,"part_number_bk" VARCHAR(1500)
	,"invoice_number_bk" VARCHAR(1500)
   ,CONSTRAINT "bridge_cust_part_pro_fea_uk" UNIQUE ("products_hkey","customers_hkey","product_feature_class_hkey","parts_hkey","invoices_hkey")
);

ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_parts_fk" FOREIGN KEY ("parts_hkey") REFERENCES "moto_dv_fl"."hub_parts"("parts_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_invoice_lines_fk" FOREIGN KEY ("lnd_invoice_lines_hkey") REFERENCES "moto_dv_fl"."lnd_invoice_lines"("lnd_invoice_lines_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_invoices_fk" FOREIGN KEY ("invoices_hkey") REFERENCES "moto_dv_fl"."hub_invoices"("invoices_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_invoices_customers_fk" FOREIGN KEY ("lnk_invoices_customers_hkey") REFERENCES "moto_dv_fl"."lnk_invoices_customers"("lnk_invoices_customers_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_customers_fk" FOREIGN KEY ("customers_hkey") REFERENCES "moto_dv_fl"."hub_customers"("customers_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_products_fk" FOREIGN KEY ("products_hkey") REFERENCES "moto_dv_fl"."hub_products"("products_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_product_feat_class_rel_fk" FOREIGN KEY ("lnd_product_feat_class_rel_hkey") REFERENCES "moto_dv_fl"."lnd_product_feat_class_rel"("lnd_product_feat_class_rel_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" ADD CONSTRAINT "bridge_cust_part_pro_fea_product_feature_class_fk" FOREIGN KEY ("product_feature_class_hkey") REFERENCES "moto_dv_fl"."hub_product_feature_class"("product_feature_class_hkey");
 ALTER TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" DISABLE TRIGGER ALL;
COMMENT ON TABLE "moto_dv_bv"."bridge_cust_part_pro_fea" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


CREATE TABLE "moto_fmc"."fmc_bv_loading_window_table"
(
	"fmc_begin_lw_timestamp" TIMESTAMP,
	"fmc_end_lw_timestamp" TIMESTAMP
);

COMMENT ON TABLE "moto_fmc"."fmc_bv_loading_window_table" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


CREATE TABLE "moto_fmc"."load_cycle_info"
(
	"load_cycle_id" INTEGER,
	"load_date" TIMESTAMP
);

COMMENT ON TABLE "moto_fmc"."load_cycle_info" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


CREATE TABLE "moto_fmc"."dv_load_cycle_info"
(
	"dv_load_cycle_id" INTEGER
);

COMMENT ON TABLE "moto_fmc"."dv_load_cycle_info" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08, 
BV release: recursive_hierarchies_on_lnd(4) - Comment:  - Release date: 2021/12/30 08:38:44';


-- END


