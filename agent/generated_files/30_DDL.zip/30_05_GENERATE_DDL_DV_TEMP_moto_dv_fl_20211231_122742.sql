/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 12:27:42
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08
 */

/* DROP TABLES */

-- START
DROP TABLE IF EXISTS "moto_mktg_stg"."lds_mktg_campaign_motorcycles_class_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lds_mktg_campaign_motorcycles_emo_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lds_mktg_camp_moto_channel_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lds_mktg_camp_moto_chan_region_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lds_mktg_camp_part_cont_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lds_mktg_party_contacts_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lds_sales_cust_addresses_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lds_sales_invoice_lines_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lds_sales_product_feat_class_rel_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lks_mktg_customers_addresses_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."lks_mktg_customers_customers_parent_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lks_sales_customers_addresses_ciai_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lks_sales_customers_addresses_csai_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lks_sales_invoices_customers_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lks_sales_productfeatures_productfeaturecat_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."lks_sales_products_products_rpid_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_addresses_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_campaigns_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_channels_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_contacts_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_customers_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_e_mails_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_phones_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_mktg_stg"."sat_mktg_products_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_addresses_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_customers_birth_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_customers_name_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_invoices_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_parts_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_product_feature_cat_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_product_feature_class_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_product_features_tmp" CASCADE;
DROP TABLE IF EXISTS "moto_sales_stg"."sat_sales_products_tmp" CASCADE;

-- END


/* CREATE TABLES */

-- START

CREATE TABLE "moto_mktg_stg"."sat_mktg_addresses_tmp"
(
    "addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"street_name" VARCHAR
   ,"street_number" NUMERIC
   ,"postal_code" VARCHAR
   ,"city" VARCHAR
   ,"address_number" NUMERIC
   ,"province" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_addresses_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_campaigns_tmp"
(
    "campaigns_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_start_date_seq" DATE NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"campaign_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_campaigns_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_channels_tmp"
(
    "channels_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"channel_id" NUMERIC
   ,"channel_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_channels_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_contacts_tmp"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"contact_id" NUMERIC
   ,"contact_type" VARCHAR
   ,"contact_type_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_contacts_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_customers_tmp"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"name" VARCHAR
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"party_type_code" CHARACTER(6)
   ,"party_number" NUMERIC
   ,"address_number" NUMERIC
   ,"parent_party_number" NUMERIC
   ,"comments" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_customers_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_e_mails_tmp"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"contact_id" NUMERIC
   ,"name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_e_mails_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_phones_tmp"
(
    "contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"contact_id" NUMERIC
   ,"phone_number" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_phones_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."sat_mktg_products_tmp"
(
    "products_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_mktg_stg"."sat_mktg_products_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_addresses_tmp"
(
    "addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"address_number" NUMERIC
   ,"coordinates" TEXT
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_addresses_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_customers_birth_tmp"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"national_person_id" VARCHAR
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"birthdate" DATE
   ,"gender" CHARACTER(24)
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_customers_birth_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_customers_name_tmp"
(
    "customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"national_person_id" VARCHAR
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"first_name" VARCHAR
   ,"last_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_customers_name_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_invoices_tmp"
(
    "invoices_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"invoice_number" NUMERIC
   ,"invoice_customer_id" NUMERIC
   ,"invoice_date" DATE
   ,"amount" NUMERIC
   ,"discount" INTEGER
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_invoices_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_parts_tmp"
(
    "parts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"part_language_code_seq" VARCHAR NOT NULL
   ,"part_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_parts_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_product_feature_cat_tmp"
(
    "product_feature_cat_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"prod_feat_cat_language_code_seq" VARCHAR NOT NULL
   ,"product_feature_category_id" INTEGER
   ,"prod_feat_cat_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_product_feature_cat_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_product_feature_class_tmp"
(
    "product_feature_class_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_feature_class_id" NUMERIC
   ,"product_feature_class_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_product_feature_class_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_product_features_tmp"
(
    "product_features_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_feature_language_code_seq" VARCHAR NOT NULL
   ,"product_feature_id" INTEGER
   ,"product_feature_cat_id" INTEGER
   ,"product_feature_description" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_product_features_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."sat_sales_products_tmp"
(
    "products_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_id" NUMERIC
   ,"replacement_product_id" NUMERIC
   ,"product_intro_date" DATE
   ,"product_name" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
);

COMMENT ON TABLE "moto_sales_stg"."sat_sales_products_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lks_mktg_customers_addresses_tmp"
(
    "lnk_customers_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"party_number" NUMERIC
   ,"address_number" NUMERIC
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"addresses_hkey" BYTEA
   ,"customers_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lks_mktg_customers_addresses_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lks_mktg_customers_customers_parent_tmp"
(
    "lnk_customers_customers_parent_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"party_number" NUMERIC
   ,"parent_party_number" NUMERIC
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"customers_parent_hkey" BYTEA
   ,"customers_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lks_mktg_customers_customers_parent_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lks_sales_customers_addresses_ciai_tmp"
(
    "lnk_customers_addresses_ciai_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"customer_number" NUMERIC
   ,"customer_invoice_address_id" NUMERIC
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"addresses_ciai_hkey" BYTEA
   ,"customers_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lks_sales_customers_addresses_ciai_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lks_sales_customers_addresses_csai_tmp"
(
    "lnk_customers_addresses_csai_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"customer_number" NUMERIC
   ,"customer_ship_to_address_id" NUMERIC
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"addresses_csai_hkey" BYTEA
   ,"customers_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lks_sales_customers_addresses_csai_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lks_sales_invoices_customers_tmp"
(
    "lnk_invoices_customers_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"invoice_number" NUMERIC
   ,"invoice_customer_id" NUMERIC
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"customers_hkey" BYTEA
   ,"invoices_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lks_sales_invoices_customers_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lks_sales_productfeatures_productfeaturecat_tmp"
(
    "lnk_productfeatures_productfeaturecat_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_feature_id" INTEGER
   ,"product_feature_cat_id" INTEGER
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"product_feature_cat_hkey" BYTEA
   ,"product_features_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lks_sales_productfeatures_productfeaturecat_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lks_sales_products_products_rpid_tmp"
(
    "lnk_products_products_rpid_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_id" NUMERIC
   ,"replacement_product_id" NUMERIC
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"products_rpid_hkey" BYTEA
   ,"products_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lks_sales_products_products_rpid_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lds_mktg_campaign_motorcycles_class_tmp"
(
    "lnd_campaign_motorcycles_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_class_desc" VARCHAR
   ,"motorcycle_subclass_desc" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"products_hkey" BYTEA
   ,"campaigns_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lds_mktg_campaign_motorcycles_class_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lds_mktg_campaign_motorcycles_emo_tmp"
(
    "lnd_campaign_motorcycles_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"motorcycle_id" NUMERIC
   ,"motorcycle_emotion_desc" VARCHAR
   ,"motorcycle_comment" VARCHAR
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"products_hkey" BYTEA
   ,"campaigns_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lds_mktg_campaign_motorcycles_emo_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lds_mktg_camp_moto_channel_tmp"
(
    "lnd_camp_moto_channel_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"from_date_seq" TIMESTAMP(6) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"channel_id" NUMERIC
   ,"motorcycle_name" VARCHAR
   ,"to_date" TIMESTAMP(6)
   ,"valid_from_date" TIMESTAMP(6)
   ,"valid_to_date" TIMESTAMP(6)
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"channels_hkey" BYTEA
   ,"campaigns_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lds_mktg_camp_moto_channel_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lds_mktg_camp_moto_chan_region_tmp"
(
    "lnd_camp_moto_chan_region_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"region_seq" VARCHAR NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"channel_id" NUMERIC
   ,"motorcycle_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"products_hkey" BYTEA
   ,"channels_hkey" BYTEA
   ,"campaigns_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lds_mktg_camp_moto_chan_region_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lds_mktg_camp_part_cont_tmp"
(
    "lnd_camp_part_cont_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"campaign_code" VARCHAR
   ,"campaign_start_date" DATE
   ,"contact_id" NUMERIC
   ,"party_number" NUMERIC
   ,"marketing_program_code" CHARACTER(30)
   ,"marketing_program_name" CHARACTER(300)
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"customers_hkey" BYTEA
   ,"contacts_hkey" BYTEA
   ,"campaigns_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lds_mktg_camp_part_cont_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_mktg_stg"."lds_mktg_party_contacts_tmp"
(
    "lnd_party_contacts_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"party_number" NUMERIC
   ,"contact_id" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"customers_hkey" BYTEA
   ,"contacts_hkey" BYTEA
);

COMMENT ON TABLE "moto_mktg_stg"."lds_mktg_party_contacts_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lds_sales_cust_addresses_tmp"
(
    "lnd_cust_addresses_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"address_type_seq" VARCHAR NOT NULL
   ,"address_number" NUMERIC
   ,"customer_number" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"customers_hkey" BYTEA
   ,"addresses_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lds_sales_cust_addresses_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lds_sales_invoice_lines_tmp"
(
    "lnd_invoice_lines_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"invoice_number" NUMERIC NOT NULL
   ,"invoice_line_number_seq" NUMERIC NOT NULL
   ,"part_id" NUMERIC
   ,"product_id" NUMERIC
   ,"amount" NUMERIC
   ,"quantity" NUMERIC
   ,"unit_price" NUMERIC
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"products_hkey" BYTEA
   ,"parts_hkey" BYTEA
   ,"invoices_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lds_sales_invoice_lines_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


CREATE TABLE "moto_sales_stg"."lds_sales_product_feat_class_rel_tmp"
(
    "lnd_product_feat_class_rel_hkey" BYTEA NOT NULL
   ,"load_date" TIMESTAMP NOT NULL
   ,"load_cycle_id" INTEGER NOT NULL
   ,"hash_diff" BYTEA
   ,"delete_flag" VARCHAR(3) NOT NULL
   ,"product_id" NUMERIC
   ,"product_feature_class_id" NUMERIC
   ,"product_feature_id" INTEGER
   ,"update_timestamp" TIMESTAMP(6)
   ,"source" VARCHAR
   ,"equal" NUMERIC
   ,"record_type" VARCHAR
   ,"products_hkey" BYTEA
   ,"product_features_hkey" BYTEA
   ,"product_feature_class_hkey" BYTEA
);

COMMENT ON TABLE "moto_sales_stg"."lds_sales_product_feat_class_rel_tmp" IS 'DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 15:18:08';


-- END


