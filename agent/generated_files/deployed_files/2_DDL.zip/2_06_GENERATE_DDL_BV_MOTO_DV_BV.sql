/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 17:00:58
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 16:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09
 */

/* CREATE TABLES */

-- START

CREATE TABLE "VAULTSPEED_HANDSON_FMC"."FMC_BV_LOADING_WINDOW_TABLE"
(
	"FMC_BEGIN_LW_TIMESTAMP" TIMESTAMP,
	"FMC_END_LW_TIMESTAMP" TIMESTAMP
);

COMMENT ON TABLE "VAULTSPEED_HANDSON_FMC"."FMC_BV_LOADING_WINDOW_TABLE" IS 'DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 16:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09';


CREATE TABLE "VAULTSPEED_HANDSON_FMC"."LOAD_CYCLE_INFO"
(
	"LOAD_CYCLE_ID" INTEGER,
	"LOAD_DATE" TIMESTAMP
);

COMMENT ON TABLE "VAULTSPEED_HANDSON_FMC"."LOAD_CYCLE_INFO" IS 'DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 16:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09';


CREATE TABLE "VAULTSPEED_HANDSON_FMC"."DV_LOAD_CYCLE_INFO"
(
	"DV_LOAD_CYCLE_ID" INTEGER
);

COMMENT ON TABLE "VAULTSPEED_HANDSON_FMC"."DV_LOAD_CYCLE_INFO" IS 'DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 16:53:05, 
BV release: init(1) - Comment: initial release - Release date: 2022/03/21 17:00:09';


-- END


