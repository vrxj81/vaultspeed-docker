/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 17:00:58
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 16:53:05
 */

DROP SCHEMA IF EXISTS "MOTO_SALES_MTD" CASCADE;
CREATE SCHEMA "MOTO_SALES_MTD";

DROP SCHEMA IF EXISTS "MOTO_SALES_DFV" CASCADE;
CREATE SCHEMA "MOTO_SALES_DFV";

DROP SCHEMA IF EXISTS "MOTO_SALES_EXT" CASCADE;
CREATE SCHEMA "MOTO_SALES_EXT";

DROP SCHEMA IF EXISTS "MOTO_SALES_STG" CASCADE;
CREATE SCHEMA "MOTO_SALES_STG";

