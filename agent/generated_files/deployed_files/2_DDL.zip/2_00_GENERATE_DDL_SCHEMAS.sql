/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 5.0.0.0, generation date: 2022/03/21 17:00:58
DV_NAME: MOTORCYCLE_DATA_VAULT - Release: Initial DV(1) - Comment:  - Release date: 2022/03/21 16:53:05
 */

DROP SCHEMA IF EXISTS "MOTO_DV_FL" CASCADE;
CREATE SCHEMA "MOTO_DV_FL";

DROP SCHEMA IF EXISTS "MOTO_DV_BV" CASCADE;
CREATE SCHEMA "MOTO_DV_BV";

DROP SCHEMA IF EXISTS "VAULTSPEED_HANDSON_PROC" CASCADE;
CREATE SCHEMA "VAULTSPEED_HANDSON_PROC";

DROP SCHEMA IF EXISTS "VAULTSPEED_HANDSON_FMC" CASCADE;
CREATE SCHEMA "VAULTSPEED_HANDSON_FMC";

