DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_campaigns_curr";
CREATE   VIEW "moto_dv_bv"."sat_mktg_campaigns_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."campaigns_hkey" AS "campaigns_hkey"
		FROM "moto_dv_fl"."sat_mktg_campaigns" "sat_curr"
		GROUP BY  "sat_curr"."campaigns_hkey"
	)
	SELECT 
		  "sat_src"."campaigns_hkey" AS "campaigns_hkey"
		, "sat_src"."campaign_start_date_seq" AS "campaign_start_date_seq"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."campaign_code" AS "campaign_code"
		, "sat_src"."campaign_start_date" AS "campaign_start_date"
		, "sat_src"."campaign_name" AS "campaign_name"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_mktg_campaigns" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."campaigns_hkey" = "curr_ld"."campaigns_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
