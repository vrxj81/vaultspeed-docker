DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_channels_enddt";
CREATE   VIEW "moto_dv_bv"."sat_mktg_channels_enddt"  AS 
	SELECT 
		  "sat_src"."channels_hkey" AS "channels_hkey"
		, "sat_src"."load_date" AS "load_date"
		, COALESCE(LEAD("sat_src"."load_date",1)OVER(PARTITION BY "sat_src"."channels_hkey" ORDER BY "sat_src"."load_date")
			, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "end_load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."channel_id" AS "channel_id"
		, "sat_src"."channel_description" AS "channel_description"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_mktg_channels" "sat_src"
	;

 
 
