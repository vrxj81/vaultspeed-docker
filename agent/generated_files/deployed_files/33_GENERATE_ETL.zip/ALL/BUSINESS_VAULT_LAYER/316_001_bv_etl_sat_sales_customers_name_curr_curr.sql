DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_customers_name_curr";
CREATE   VIEW "moto_dv_bv"."sat_sales_customers_name_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."customers_hkey" AS "customers_hkey"
		FROM "moto_dv_fl"."sat_sales_customers_name" "sat_curr"
		GROUP BY  "sat_curr"."customers_hkey"
	)
	SELECT 
		  "sat_src"."customers_hkey" AS "customers_hkey"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."customer_number" AS "customer_number"
		, "sat_src"."customer_invoice_address_id" AS "customer_invoice_address_id"
		, "sat_src"."customer_ship_to_address_id" AS "customer_ship_to_address_id"
		, "sat_src"."first_name" AS "first_name"
		, "sat_src"."last_name" AS "last_name"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_customers_name" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."customers_hkey" = "curr_ld"."customers_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
