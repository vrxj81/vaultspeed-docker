DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_channels_curr";
CREATE   VIEW "moto_dv_bv"."sat_mktg_channels_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."channels_hkey" AS "channels_hkey"
		FROM "moto_dv_fl"."sat_mktg_channels" "sat_curr"
		GROUP BY  "sat_curr"."channels_hkey"
	)
	SELECT 
		  "sat_src"."channels_hkey" AS "channels_hkey"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."channel_id" AS "channel_id"
		, "sat_src"."channel_description" AS "channel_description"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_mktg_channels" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."channels_hkey" = "curr_ld"."channels_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
