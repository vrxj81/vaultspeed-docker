DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_addresses_curr";
CREATE   VIEW "moto_dv_bv"."sat_sales_addresses_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."addresses_hkey" AS "addresses_hkey"
		FROM "moto_dv_fl"."sat_sales_addresses" "sat_curr"
		GROUP BY  "sat_curr"."addresses_hkey"
	)
	SELECT 
		  "sat_src"."addresses_hkey" AS "addresses_hkey"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."address_number" AS "address_number"
		, "sat_src"."coordinates" AS "coordinates"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_addresses" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."addresses_hkey" = "curr_ld"."addresses_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
