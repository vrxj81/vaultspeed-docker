DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_customers_birth_enddt";
CREATE   VIEW "moto_dv_bv"."sat_sales_customers_birth_enddt"  AS 
	SELECT 
		  "sat_src"."customers_hkey" AS "customers_hkey"
		, "sat_src"."load_date" AS "load_date"
		, COALESCE(LEAD("sat_src"."load_date",1)OVER(PARTITION BY "sat_src"."customers_hkey" ORDER BY "sat_src"."load_date")
			, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "end_load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."customer_number" AS "customer_number"
		, "sat_src"."customer_invoice_address_id" AS "customer_invoice_address_id"
		, "sat_src"."customer_ship_to_address_id" AS "customer_ship_to_address_id"
		, "sat_src"."birthdate" AS "birthdate"
		, "sat_src"."gender" AS "gender"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_customers_birth" "sat_src"
	;

 
 
