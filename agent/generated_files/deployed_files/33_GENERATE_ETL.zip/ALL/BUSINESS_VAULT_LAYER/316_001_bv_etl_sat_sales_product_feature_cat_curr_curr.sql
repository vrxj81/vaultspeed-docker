DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_product_feature_cat_curr";
CREATE   VIEW "moto_dv_bv"."sat_sales_product_feature_cat_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
		FROM "moto_dv_fl"."sat_sales_product_feature_cat" "sat_curr"
		GROUP BY  "sat_curr"."product_feature_cat_hkey"
	)
	SELECT 
		  "sat_src"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
		, "sat_src"."prod_feat_cat_language_code_seq" AS "prod_feat_cat_language_code_seq"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."product_feature_category_id" AS "product_feature_category_id"
		, "sat_src"."prod_feat_cat_description" AS "prod_feat_cat_description"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_product_feature_cat" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."product_feature_cat_hkey" = "curr_ld"."product_feature_cat_hkey" AND "sat_src"."load_date" = 
		"curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
