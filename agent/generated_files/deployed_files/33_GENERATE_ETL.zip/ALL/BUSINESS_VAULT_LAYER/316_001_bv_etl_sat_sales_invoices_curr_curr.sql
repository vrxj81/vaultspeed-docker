DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_invoices_curr";
CREATE   VIEW "moto_dv_bv"."sat_sales_invoices_curr"  AS 
	WITH "curr_ld" AS 
	( 
		SELECT 
			  MAX("sat_curr"."load_date") AS "load_date"
			, "sat_curr"."invoices_hkey" AS "invoices_hkey"
		FROM "moto_dv_fl"."sat_sales_invoices" "sat_curr"
		GROUP BY  "sat_curr"."invoices_hkey"
	)
	SELECT 
		  "sat_src"."invoices_hkey" AS "invoices_hkey"
		, "sat_src"."load_date" AS "load_date"
		, "sat_src"."load_cycle_id" AS "load_cycle_id"
		, "sat_src"."hash_diff" AS "hash_diff"
		, "sat_src"."delete_flag" AS "delete_flag"
		, "sat_src"."invoice_number" AS "invoice_number"
		, "sat_src"."invoice_customer_id" AS "invoice_customer_id"
		, "sat_src"."invoice_date" AS "invoice_date"
		, "sat_src"."amount" AS "amount"
		, "sat_src"."discount" AS "discount"
		, "sat_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."sat_sales_invoices" "sat_src"
	INNER JOIN "curr_ld" "curr_ld" ON  "sat_src"."invoices_hkey" = "curr_ld"."invoices_hkey" AND "sat_src"."load_date" = "curr_ld"."load_date"
	WHERE  "sat_src"."delete_flag" = 'N'::text
	;

 
 
