CREATE OR REPLACE FUNCTION "moto_proc"."lna_mktg_customers_addresses_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:59
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- lna_tgt

	INSERT INTO "moto_dv_bv"."lna_customers_addresses"(
		 "lna_customers_addresses_hkey"
		,"customers_hkey"
		,"addresses_hkey"
		,"load_cycle_id"
		,"load_date"
		,"record_source"
	)
	WITH "prep_set" AS 
	( 
		SELECT 
			  DIGEST( "hub_pk_src"."src_bk" || '#' || "hub_pk_src"."customers_bk" || '#' || COALESCE("hub_fk_src"."street_name_bk",
				"unhub_fk_src"."street_name_bk")|| '#' ||  COALESCE("hub_fk_src"."street_number_bk","unhub_fk_src"."street_number_bk")|| '#' ||  COALESCE("hub_fk_src"."postal_code_bk","unhub_fk_src"."postal_code_bk")|| '#' ||  COALESCE("hub_fk_src"."city_bk","unhub_fk_src"."city_bk")|| '#' ,'SHA1') AS "lna_customers_addresses_hkey"
			, "sat_pk_src"."customers_hkey" AS "customers_hkey"
			, COALESCE("hub_fk_src"."addresses_hkey","unhub_fk_src"."addresses_hkey") AS "addresses_hkey"
			, "bvlci_src"."load_cycle_id" AS "load_cycle_id"
			, "bvlci_src"."load_date" AS "load_date"
			, "hub_pk_src"."record_source" AS "record_source"
		FROM "moto_dv_fl"."sat_mktg_customers" "sat_pk_src"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_pk_src" ON  "sat_pk_src"."customers_hkey" = "hub_pk_src"."customers_hkey"
		LEFT OUTER JOIN "moto_dv_fl"."sat_sales_addresses" "sat_fk_src" ON  "sat_fk_src"."address_number" = "sat_pk_src"."address_number"
		LEFT OUTER JOIN "moto_dv_fl"."hub_addresses" "hub_fk_src" ON  "sat_fk_src"."addresses_hkey" = "hub_fk_src"."addresses_hkey"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		INNER JOIN "moto_dv_fl"."hub_addresses" "unhub_fk_src" ON  "mex_src"."load_cycle_id"::int = "unhub_fk_src"."load_cycle_id"
		INNER JOIN "moto_fmc"."dv_load_cycle_info" "dvlci_src" ON  "dvlci_src"."dv_load_cycle_id" = "sat_pk_src"."load_cycle_id" OR "dvlci_src"."dv_load_cycle_id" = "sat_fk_src"."load_cycle_id"
		INNER JOIN "moto_fmc"."load_cycle_info" "bvlci_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'U'
		GROUP BY  DIGEST( "hub_pk_src"."src_bk" || '#' || "hub_pk_src"."customers_bk" || '#' || COALESCE("hub_fk_src"."street_name_bk",
			"unhub_fk_src"."street_name_bk")|| '#' ||  COALESCE("hub_fk_src"."street_number_bk","unhub_fk_src"."street_number_bk")|| '#' ||  COALESCE("hub_fk_src"."postal_code_bk","unhub_fk_src"."postal_code_bk")|| '#' ||  COALESCE("hub_fk_src"."city_bk","unhub_fk_src"."city_bk")|| '#' ,'SHA1'),  "sat_pk_src"."customers_hkey",  COALESCE("hub_fk_src"."addresses_hkey","unhub_fk_src"."addresses_hkey"),  "bvlci_src"."load_cycle_id",  "bvlci_src"."load_date",  "hub_pk_src"."record_source"
	)
	SELECT 
		  "prep_set"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
		, "prep_set"."customers_hkey" AS "customers_hkey"
		, "prep_set"."addresses_hkey" AS "addresses_hkey"
		, "prep_set"."load_cycle_id" AS "load_cycle_id"
		, "prep_set"."load_date" AS "load_date"
		, "prep_set"."record_source" AS "record_source"
	FROM "prep_set" "prep_set"
	LEFT OUTER JOIN "moto_dv_bv"."lna_customers_addresses" "lna_src" ON  "prep_set"."lna_customers_addresses_hkey" = "lna_src"."lna_customers_addresses_hkey"
	WHERE  "lna_src"."lna_customers_addresses_hkey" is NULL
	;
END;


END;
$function$;
 
 
