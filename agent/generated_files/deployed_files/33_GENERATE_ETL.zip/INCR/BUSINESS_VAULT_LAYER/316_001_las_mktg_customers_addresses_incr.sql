CREATE OR REPLACE FUNCTION "moto_proc"."las_mktg_customers_addresses_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:59
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- las_prep

	INSERT INTO "moto_dv_bv"."las_mktg_customers_addresses"(
		 "lna_customers_addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"party_number"
		,"address_number"
	)
	WITH "las_set" AS 
	( 
		SELECT DISTINCT 
 			  DIGEST( "hub_set_pk_src"."src_bk" || '#' || "hub_set_pk_src"."customers_bk" || '#' || "hub_set_fk_src"."street_name_bk" || 
				'#' ||  "hub_set_fk_src"."street_number_bk" || '#' ||  "hub_set_fk_src"."postal_code_bk" || '#' ||  "hub_set_fk_src"."city_bk" || '#' ,'SHA1') AS "lna_customers_addresses_hkey"
			, "las_set_src"."lna_customers_addresses_hkey" AS "object_l_h_key_prev"
			, "las_set_src"."load_date" AS "load_date"
			, "bvlci_src"."load_cycle_id" AS "load_cycle_id"
			, "las_set_src"."delete_flag" AS "delete_flag"
			, "las_set_src"."party_number" AS "party_number"
			, "las_set_src"."address_number" AS "address_number"
		FROM "moto_dv_bv"."las_mktg_customers_addresses" "las_set_src"
		INNER JOIN "moto_dv_bv"."lna_customers_addresses" "lna_set_src" ON  "las_set_src"."lna_customers_addresses_hkey" = "lna_set_src"."lna_customers_addresses_hkey"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_set_src" ON  1 = 1
		INNER JOIN "moto_dv_fl"."hub_addresses" "unhub_set_fk_src" ON  "mex_set_src"."load_cycle_id"::int = "unhub_set_fk_src"."load_cycle_id" AND "lna_set_src"."addresses_hkey" = 
			"unhub_set_fk_src"."addresses_hkey"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_set_pk_src" ON  "hub_set_pk_src"."customers_hkey" = "lna_set_src"."customers_hkey"
		INNER JOIN "moto_dv_fl"."sat_sales_addresses" "sat_set_fk_src" ON  "sat_set_fk_src"."address_number" = "las_set_src"."address_number"
		INNER JOIN "moto_dv_fl"."hub_addresses" "hub_set_fk_src" ON  "hub_set_fk_src"."addresses_hkey" = "sat_set_fk_src"."addresses_hkey"
		INNER JOIN "moto_fmc"."dv_load_cycle_info" "dvlci_src" ON  "dvlci_src"."dv_load_cycle_id" = "sat_set_fk_src"."load_cycle_id"
		INNER JOIN "moto_fmc"."load_cycle_info" "bvlci_src" ON  1 = 1
		WHERE  "mex_set_src"."record_type" = 'U'
	)
	SELECT 
		  "las_set"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
		, "las_set"."load_date" AS "load_date"
		, "las_set"."load_cycle_id" AS "load_cycle_id"
		, "las_set"."delete_flag" AS "delete_flag"
		, "las_set"."party_number" AS "party_number"
		, "las_set"."address_number" AS "address_number"
	FROM "las_set" "las_set"
	;
END;


BEGIN -- las_temp_tgt

	TRUNCATE TABLE "moto_dv_bv"."las_mktg_customers_addresses_tmp"  CASCADE;

	INSERT INTO "moto_dv_bv"."las_mktg_customers_addresses_tmp"(
		 "lna_customers_addresses_hkey"
		,"addresses_hkey"
		,"customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"source"
		,"equal"
		,"delete_flag"
		,"party_number"
		,"address_number"
	)
	WITH "dist_sat_pk" AS 
	( 
		SELECT DISTINCT 
 			  "sat_pk_dis"."customers_hkey" AS "customers_hkey"
		FROM "moto_dv_fl"."sat_mktg_customers" "sat_pk_dis"
		INNER JOIN "moto_fmc"."dv_load_cycle_info" "dvlci_dis" ON  "dvlci_dis"."dv_load_cycle_id" = "sat_pk_dis"."load_cycle_id"
	)
	, "las_temp_set" AS 
	( 
		SELECT 
			  DIGEST( "hub_pk_src"."src_bk" || '#' || "hub_pk_src"."customers_bk" || '#' || COALESCE("hub_fk_src"."street_name_bk",
				"unhub_fk_src"."street_name_bk")|| '#' ||  COALESCE("hub_fk_src"."street_number_bk","unhub_fk_src"."street_number_bk")|| '#' ||  COALESCE("hub_fk_src"."postal_code_bk","unhub_fk_src"."postal_code_bk")|| '#' ||  COALESCE("hub_fk_src"."city_bk","unhub_fk_src"."city_bk")|| '#' ,'SHA1') AS "lna_customers_addresses_hkey"
			, COALESCE("hub_fk_src"."addresses_hkey","unhub_fk_src"."addresses_hkey") AS "addresses_hkey"
			, "hub_pk_src"."customers_hkey" AS "customers_hkey"
			, "sat_pk_src"."load_date" AS "load_date"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, "bvlci_sat"."load_cycle_id" AS "load_cycle_id"
			, 1 AS "source"
			, "sat_pk_src"."delete_flag" AS "delete_flag"
			, "sat_pk_src"."party_number" AS "party_number"
			, "sat_pk_src"."address_number" AS "address_number"
		FROM "moto_dv_fl"."sat_mktg_customers" "sat_pk_src"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_pk_src" ON  "sat_pk_src"."customers_hkey" = "hub_pk_src"."customers_hkey"
		LEFT OUTER JOIN "moto_dv_fl"."sat_sales_addresses" "sat_fk_src" ON  "sat_pk_src"."address_number" = "sat_fk_src"."address_number"
		LEFT OUTER JOIN "moto_dv_fl"."hub_addresses" "hub_fk_src" ON  "sat_fk_src"."addresses_hkey" = "hub_fk_src"."addresses_hkey"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		INNER JOIN "moto_dv_fl"."hub_addresses" "unhub_fk_src" ON  "mex_src"."load_cycle_id"::int = "unhub_fk_src"."load_cycle_id"
		INNER JOIN "moto_fmc"."dv_load_cycle_info" "dvlci_sat" ON  "dvlci_sat"."dv_load_cycle_id" = "sat_pk_src"."load_cycle_id"
		INNER JOIN "moto_fmc"."load_cycle_info" "bvlci_sat" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'U'
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "las_temp_set"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
			, "las_temp_set"."addresses_hkey" AS "addresses_hkey"
			, "las_temp_set"."customers_hkey" AS "customers_hkey"
			, "las_temp_set"."load_date" AS "load_date"
			, "las_temp_set"."load_end_date" AS "load_end_date"
			, "las_temp_set"."load_cycle_id" AS "load_cycle_id"
			, "las_temp_set"."source" AS "source"
			, "las_temp_set"."delete_flag" AS "delete_flag"
			, "las_temp_set"."party_number" AS "party_number"
			, "las_temp_set"."address_number" AS "address_number"
		FROM "las_temp_set" "las_temp_set"
		UNION ALL 
		SELECT 
			  "las_src"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
			, "lna_src"."addresses_hkey" AS "addresses_hkey"
			, "lna_src"."customers_hkey" AS "customers_hkey"
			, "las_src"."load_date" AS "load_date"
			, MAX("las_src"."load_date")OVER(PARTITION BY "lna_src"."customers_hkey") AS "load_end_date"
			, "las_src"."load_cycle_id" AS "load_cycle_id"
			, 0 AS "source"
			, "las_src"."delete_flag" AS "delete_flag"
			, "las_src"."party_number" AS "party_number"
			, "las_src"."address_number" AS "address_number"
		FROM "moto_dv_bv"."las_mktg_customers_addresses" "las_src"
		INNER JOIN "moto_dv_bv"."lna_customers_addresses" "lna_src" ON  "las_src"."lna_customers_addresses_hkey" = "lna_src"."lna_customers_addresses_hkey"
		INNER JOIN "dist_sat_pk" "dist_sat_pk" ON  "lna_src"."customers_hkey" = "dist_sat_pk"."customers_hkey"
	)
	SELECT 
		  "temp_table_set"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
		, "temp_table_set"."addresses_hkey" AS "addresses_hkey"
		, "temp_table_set"."customers_hkey" AS "customers_hkey"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."source" ::text AS "source"
		, CASE WHEN "temp_table_set"."source" = 1 AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."addresses_hkey",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."addresses_hkey",'hex'),1)OVER(PARTITION BY "temp_table_set"."customers_hkey" ORDER BY "temp_table_set"."load_date","temp_table_set"."source")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."party_number" AS "party_number"
		, "temp_table_set"."address_number" AS "address_number"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 1 OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 0)
	;
END;


BEGIN -- las_inur_tgt

	INSERT INTO "moto_dv_bv"."las_mktg_customers_addresses"(
		 "lna_customers_addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"party_number"
		,"address_number"
	)
	SELECT 
		  "las_temp_src_inur"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
		, "las_temp_src_inur"."load_date" AS "load_date"
		, "las_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "las_temp_src_inur"."delete_flag" AS "delete_flag"
		, "las_temp_src_inur"."party_number" AS "party_number"
		, "las_temp_src_inur"."address_number" AS "address_number"
	FROM "moto_dv_bv"."las_mktg_customers_addresses_tmp" "las_temp_src_inur"
	WHERE  "las_temp_src_inur"."source" = '1' AND "las_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
