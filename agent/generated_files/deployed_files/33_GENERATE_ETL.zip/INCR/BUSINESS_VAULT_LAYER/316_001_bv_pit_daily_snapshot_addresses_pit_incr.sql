CREATE OR REPLACE FUNCTION "moto_proc"."bv_pit_daily_snapshot_addresses_pit_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:59
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- pit_upd

	WITH "snapshotdates_upd" AS 
	( 
		SELECT 
			  "ssdv_src_upd"."snapshot_timestamp" AS "snapshot_timestamp"
		FROM "moto_dv_bv"."view_pit_daily_snapshot_addresses_snapshotdates" "ssdv_src_upd"
		INNER JOIN "moto_fmc"."fmc_bv_loading_window_table" "bvlwt_src_upd" ON  1 = 1
		WHERE  "ssdv_src_upd"."snapshot_timestamp" >= "bvlwt_src_upd"."fmc_begin_lw_timestamp"
	)
	, "sat_src_upd1" AS 
	( 
		SELECT 
			  "sat_ed_src_upd1"."addresses_hkey" AS "addresses_hkey"
			, "sat_ed_src_upd1"."load_date" AS "load_date"
			, COALESCE(LEAD("sat_ed_src_upd1"."load_date")OVER(PARTITION BY "sat_ed_src_upd1"."addresses_hkey" ORDER BY "sat_ed_src_upd1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59' , 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "sat_ed_src_upd1"."delete_flag" AS "delete_flag"
		FROM "moto_dv_fl"."sat_mktg_addresses" "sat_ed_src_upd1"
	)
	, "sat_src_upd2" AS 
	( 
		SELECT 
			  "sat_ed_src_upd2"."addresses_hkey" AS "addresses_hkey"
			, "sat_ed_src_upd2"."load_date" AS "load_date"
			, COALESCE(LEAD("sat_ed_src_upd2"."load_date")OVER(PARTITION BY "sat_ed_src_upd2"."addresses_hkey" ORDER BY "sat_ed_src_upd2"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59' , 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "sat_ed_src_upd2"."delete_flag" AS "delete_flag"
		FROM "moto_dv_fl"."sat_sales_addresses" "sat_ed_src_upd2"
	)
	, "miv_upd" AS 
	( 
		SELECT 
			  DIGEST( encode("hub_src_upd"."addresses_hkey",'hex') || '#' || TO_CHAR("snapshotdates_upd"."snapshot_timestamp",
				 'DD/MM/YYYY HH24:MI:SS.US'::varchar) ,'SHA1') AS "pit_daily_snapshot_addresses_hkey"
			, "hub_src_upd"."addresses_hkey" AS "addresses_hkey"
			, "snapshotdates_upd"."snapshot_timestamp" AS "snapshot_timestamp"
			, COALESCE("sat_src_upd1"."addresses_hkey","unsat_src_upd1"."addresses_hkey") AS "sat_mktg_addresses_hkey"
			, COALESCE("sat_src_upd2"."addresses_hkey","unsat_src_upd2"."addresses_hkey") AS "sat_sales_addresses_hkey"
			, COALESCE("sat_src_upd1"."load_date","unsat_src_upd1"."load_date") AS "sat_mktg_addresses_load_date"
			, COALESCE("sat_src_upd2"."load_date","unsat_src_upd2"."load_date") AS "sat_sales_addresses_load_date"
		FROM "moto_dv_fl"."hub_addresses" "hub_src_upd"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src_upd" ON  "mex_src_upd"."record_type" = 'U'
		INNER JOIN "moto_fmc"."load_cycle_info" "bvlci_upd" ON  1 = 1
		INNER JOIN "snapshotdates_upd" "snapshotdates_upd" ON  "hub_src_upd"."load_date" <= "snapshotdates_upd"."snapshot_timestamp"
		LEFT OUTER JOIN "sat_src_upd1" "sat_src_upd1" ON  "hub_src_upd"."addresses_hkey" = "sat_src_upd1"."addresses_hkey" AND "snapshotdates_upd"."snapshot_timestamp" >=
			 "sat_src_upd1"."load_date" AND "snapshotdates_upd"."snapshot_timestamp" < "sat_src_upd1"."load_end_date" AND "sat_src_upd1"."delete_flag" != 'Y'::text
		LEFT OUTER JOIN "sat_src_upd2" "sat_src_upd2" ON  "hub_src_upd"."addresses_hkey" = "sat_src_upd2"."addresses_hkey" AND "snapshotdates_upd"."snapshot_timestamp" >=
			 "sat_src_upd2"."load_date" AND "snapshotdates_upd"."snapshot_timestamp" < "sat_src_upd2"."load_end_date" AND "sat_src_upd2"."delete_flag" != 'Y'::text
		INNER JOIN "moto_dv_fl"."sat_mktg_addresses" "unsat_src_upd1" ON  "mex_src_upd"."load_cycle_id"::int = "unsat_src_upd1"."load_cycle_id"
		INNER JOIN "moto_dv_fl"."sat_sales_addresses" "unsat_src_upd2" ON  "mex_src_upd"."load_cycle_id"::int = "unsat_src_upd2"."load_cycle_id"
	)
	, "upd_data_src" AS 
	( 
		SELECT 
			  "miv_upd"."pit_daily_snapshot_addresses_hkey" AS "pit_daily_snapshot_addresses_hkey"
			, "miv_upd"."addresses_hkey" AS "addresses_hkey"
			, "miv_upd"."snapshot_timestamp" AS "snapshot_timestamp"
			, "miv_upd"."sat_sales_addresses_hkey" AS "sat_sales_addresses_hkey"
			, "miv_upd"."sat_mktg_addresses_hkey" AS "sat_mktg_addresses_hkey"
			, "miv_upd"."sat_sales_addresses_load_date" AS "sat_sales_addresses_load_date"
			, "miv_upd"."sat_mktg_addresses_load_date" AS "sat_mktg_addresses_load_date"
		FROM "miv_upd" "miv_upd"
		LEFT OUTER JOIN "moto_dv_bv"."pit_daily_snapshot_addresses" "pit_upd_tgt" ON  "miv_upd"."pit_daily_snapshot_addresses_hkey" = "pit_upd_tgt"."pit_daily_snapshot_addresses_hkey" AND 
			"miv_upd"."sat_sales_addresses_hkey" = "pit_upd_tgt"."sat_sales_addresses_hkey" AND "miv_upd"."sat_mktg_addresses_hkey" = "pit_upd_tgt"."sat_mktg_addresses_hkey" AND "miv_upd"."sat_sales_addresses_load_date" = "pit_upd_tgt"."sat_sales_addresses_load_date" AND "miv_upd"."sat_mktg_addresses_load_date" = "pit_upd_tgt"."sat_mktg_addresses_load_date"
		WHERE  "pit_upd_tgt"."pit_daily_snapshot_addresses_hkey" IS NULL
	)
	UPDATE "moto_dv_bv"."pit_daily_snapshot_addresses" "pit_upd_tgt"
	SET 
		 "sat_sales_addresses_hkey" =  "upd_data_src"."sat_sales_addresses_hkey"
		,"sat_mktg_addresses_hkey" =  "upd_data_src"."sat_mktg_addresses_hkey"
		,"sat_sales_addresses_load_date" =  "upd_data_src"."sat_sales_addresses_load_date"
		,"sat_mktg_addresses_load_date" =  "upd_data_src"."sat_mktg_addresses_load_date"
	FROM "upd_data_src"
	WHERE "pit_upd_tgt"."pit_daily_snapshot_addresses_hkey" =  "upd_data_src"."pit_daily_snapshot_addresses_hkey"
	;
END;


BEGIN -- pit_tgt

	INSERT INTO "moto_dv_bv"."pit_daily_snapshot_addresses"(
		 "pit_daily_snapshot_addresses_hkey"
		,"addresses_hkey"
		,"snapshot_timestamp"
		,"load_cycle_id"
		,"sat_sales_addresses_hkey"
		,"sat_mktg_addresses_hkey"
		,"sat_sales_addresses_load_date"
		,"sat_mktg_addresses_load_date"
	)
	WITH "snapshotdates" AS 
	( 
		SELECT 
			  "ssdv_src"."snapshot_timestamp" AS "snapshot_timestamp"
		FROM "moto_dv_bv"."view_pit_daily_snapshot_addresses_snapshotdates" "ssdv_src"
		INNER JOIN "moto_fmc"."fmc_bv_loading_window_table" "bvlwt_src" ON  1 = 1
		WHERE  "ssdv_src"."snapshot_timestamp" >= "bvlwt_src"."fmc_begin_lw_timestamp"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_ed_src1"."addresses_hkey" AS "addresses_hkey"
			, "sat_ed_src1"."load_date" AS "load_date"
			, COALESCE(LEAD("sat_ed_src1"."load_date")OVER(PARTITION BY "sat_ed_src1"."addresses_hkey" ORDER BY "sat_ed_src1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59' , 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "sat_ed_src1"."delete_flag" AS "delete_flag"
		FROM "moto_dv_fl"."sat_mktg_addresses" "sat_ed_src1"
	)
	, "sat_src2" AS 
	( 
		SELECT 
			  "sat_ed_src2"."addresses_hkey" AS "addresses_hkey"
			, "sat_ed_src2"."load_date" AS "load_date"
			, COALESCE(LEAD("sat_ed_src2"."load_date")OVER(PARTITION BY "sat_ed_src2"."addresses_hkey" ORDER BY "sat_ed_src2"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59' , 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "sat_ed_src2"."delete_flag" AS "delete_flag"
		FROM "moto_dv_fl"."sat_sales_addresses" "sat_ed_src2"
	)
	, "miv" AS 
	( 
		SELECT 
			  DIGEST( encode("hub_src"."addresses_hkey",'hex') || '#' || TO_CHAR("snapshotdates"."snapshot_timestamp", 
				'DD/MM/YYYY HH24:MI:SS.US'::varchar) ,'SHA1') AS "pit_daily_snapshot_addresses_hkey"
			, "hub_src"."addresses_hkey" AS "addresses_hkey"
			, "snapshotdates"."snapshot_timestamp" AS "snapshot_timestamp"
			, "bvlci_src"."load_cycle_id" AS "load_cycle_id"
			, COALESCE("sat_src1"."addresses_hkey","unsat_src1"."addresses_hkey") AS "sat_mktg_addresses_hkey"
			, COALESCE("sat_src2"."addresses_hkey","unsat_src2"."addresses_hkey") AS "sat_sales_addresses_hkey"
			, COALESCE("sat_src1"."load_date","unsat_src1"."load_date") AS "sat_mktg_addresses_load_date"
			, COALESCE("sat_src2"."load_date","unsat_src2"."load_date") AS "sat_sales_addresses_load_date"
		FROM "moto_dv_fl"."hub_addresses" "hub_src"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
		INNER JOIN "moto_fmc"."load_cycle_info" "bvlci_src" ON  1 = 1
		INNER JOIN "snapshotdates" "snapshotdates" ON  "hub_src"."load_date" <= "snapshotdates"."snapshot_timestamp"
		LEFT OUTER JOIN "sat_src1" "sat_src1" ON  "hub_src"."addresses_hkey" = "sat_src1"."addresses_hkey" AND "snapshotdates"."snapshot_timestamp" >= 
			"sat_src1"."load_date" AND "snapshotdates"."snapshot_timestamp" < "sat_src1"."load_end_date" AND "sat_src1"."delete_flag" != 'Y'::text
		LEFT OUTER JOIN "sat_src2" "sat_src2" ON  "hub_src"."addresses_hkey" = "sat_src2"."addresses_hkey" AND "snapshotdates"."snapshot_timestamp" >= 
			"sat_src2"."load_date" AND "snapshotdates"."snapshot_timestamp" < "sat_src2"."load_end_date" AND "sat_src2"."delete_flag" != 'Y'::text
		INNER JOIN "moto_dv_fl"."sat_mktg_addresses" "unsat_src1" ON  "mex_src"."load_cycle_id"::int = "unsat_src1"."load_cycle_id"
		INNER JOIN "moto_dv_fl"."sat_sales_addresses" "unsat_src2" ON  "mex_src"."load_cycle_id"::int = "unsat_src2"."load_cycle_id"
	)
	SELECT 
		  "miv"."pit_daily_snapshot_addresses_hkey" AS "pit_daily_snapshot_addresses_hkey"
		, "miv"."addresses_hkey" AS "addresses_hkey"
		, "miv"."snapshot_timestamp" AS "snapshot_timestamp"
		, "miv"."load_cycle_id" AS "load_cycle_id"
		, "miv"."sat_sales_addresses_hkey" AS "sat_sales_addresses_hkey"
		, "miv"."sat_mktg_addresses_hkey" AS "sat_mktg_addresses_hkey"
		, "miv"."sat_sales_addresses_load_date" AS "sat_sales_addresses_load_date"
		, "miv"."sat_mktg_addresses_load_date" AS "sat_mktg_addresses_load_date"
	FROM "miv" "miv"
	LEFT OUTER JOIN "moto_dv_bv"."pit_daily_snapshot_addresses" "pit_src" ON  "pit_src"."pit_daily_snapshot_addresses_hkey" = "miv"."pit_daily_snapshot_addresses_hkey"
	WHERE  "pit_src"."snapshot_timestamp" IS NULL
	;
END;


END;
$function$;
 
 
