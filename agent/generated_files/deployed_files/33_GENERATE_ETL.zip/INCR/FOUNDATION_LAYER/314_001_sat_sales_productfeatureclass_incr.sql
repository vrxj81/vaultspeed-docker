CREATE OR REPLACE FUNCTION "moto_proc"."sat_sales_productfeatureclass_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- sat_temp_tgt

	TRUNCATE TABLE "moto_sales_stg"."sat_sales_product_feature_class_tmp"  CASCADE;

	INSERT INTO "moto_sales_stg"."sat_sales_product_feature_class_tmp"(
		 "product_feature_class_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_type"
		,"source"
		,"equal"
		,"hash_diff"
		,"delete_flag"
		,"product_feature_class_id"
		,"product_feature_class_desc"
		,"update_timestamp"
	)
	WITH "dist_stg" AS 
	( 
		SELECT DISTINCT 
 			  "stg_dis_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, "stg_dis_src"."load_cycle_id" AS "load_cycle_id"
		FROM "moto_sales_stg"."product_feature_class" "stg_dis_src"
		WHERE  "stg_dis_src"."record_type" = 'S'
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "stg_temp_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, "stg_temp_src"."load_date" AS "load_date"
			, "stg_temp_src"."load_cycle_id" AS "load_cycle_id"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, "stg_temp_src"."record_type" AS "record_type"
			, 'STG' AS "source"
			, 1 AS "origin_id"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_temp_src"."product_feature_class_desc"),'~'),'#','\' || 
				'#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_temp_src"."update_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, CASE WHEN "stg_temp_src"."jrn_flag" = 'D' THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
			, "stg_temp_src"."product_feature_class_id" AS "product_feature_class_id"
			, "stg_temp_src"."product_feature_class_desc" AS "product_feature_class_desc"
			, "stg_temp_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_stg"."product_feature_class" "stg_temp_src"
		WHERE  "stg_temp_src"."record_type" = 'S'
		UNION ALL 
		SELECT 
			  "sat_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, "sat_src"."load_date" AS "load_date"
			, "sat_src"."load_cycle_id" AS "load_cycle_id"
			, MAX("sat_src"."load_date")OVER( PARTITION BY "sat_src"."product_feature_class_hkey") AS "load_end_date"
			, 'SAT' AS "record_type"
			, 'SAT' AS "source"
			, 0 AS "origin_id"
			, "sat_src"."hash_diff" AS "hash_diff"
			, "sat_src"."delete_flag" AS "delete_flag"
			, "sat_src"."product_feature_class_id" AS "product_feature_class_id"
			, "sat_src"."product_feature_class_desc" AS "product_feature_class_desc"
			, "sat_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."sat_sales_product_feature_class" "sat_src"
		INNER JOIN "dist_stg" "dist_stg" ON  "sat_src"."product_feature_class_hkey" = "dist_stg"."product_feature_class_hkey"
	)
	SELECT 
		  "temp_table_set"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."record_type" AS "record_type"
		, "temp_table_set"."source" AS "source"
		, CASE WHEN "temp_table_set"."source" = 'STG' AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",'hex'),1)OVER(PARTITION BY "temp_table_set"."product_feature_class_hkey" ORDER BY "temp_table_set"."load_date","temp_table_set"."origin_id")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."hash_diff" AS "hash_diff"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."product_feature_class_id" AS "product_feature_class_id"
		, "temp_table_set"."product_feature_class_desc" AS "product_feature_class_desc"
		, "temp_table_set"."update_timestamp" AS "update_timestamp"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 'STG' OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 'SAT')
	;
END;


BEGIN -- sat_inur_tgt

	INSERT INTO "moto_dv_fl"."sat_sales_product_feature_class"(
		 "product_feature_class_hkey"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"product_feature_class_id"
		,"product_feature_class_desc"
		,"update_timestamp"
	)
	SELECT 
		  "sat_temp_src_inur"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "sat_temp_src_inur"."load_date" AS "load_date"
		, "sat_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "sat_temp_src_inur"."hash_diff" AS "hash_diff"
		, "sat_temp_src_inur"."delete_flag" AS "delete_flag"
		, "sat_temp_src_inur"."product_feature_class_id" AS "product_feature_class_id"
		, "sat_temp_src_inur"."product_feature_class_desc" AS "product_feature_class_desc"
		, "sat_temp_src_inur"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_stg"."sat_sales_product_feature_class_tmp" "sat_temp_src_inur"
	WHERE  "sat_temp_src_inur"."source" = 'STG' AND "sat_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
