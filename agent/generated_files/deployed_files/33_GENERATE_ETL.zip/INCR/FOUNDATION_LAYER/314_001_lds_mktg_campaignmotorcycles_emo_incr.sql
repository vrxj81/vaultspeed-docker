CREATE OR REPLACE FUNCTION "moto_proc"."lds_mktg_campaignmotorcycles_emo_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- lds_temp_tgt

	TRUNCATE TABLE "moto_mktg_stg"."lds_mktg_campaign_motorcycles_emo_tmp"  CASCADE;

	INSERT INTO "moto_mktg_stg"."lds_mktg_campaign_motorcycles_emo_tmp"(
		 "lnd_campaign_motorcycles_hkey"
		,"campaigns_hkey"
		,"products_hkey"
		,"campaign_code"
		,"campaign_start_date"
		,"motorcycle_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"record_type"
		,"source"
		,"equal"
		,"delete_flag"
		,"motorcycle_emotion_desc"
		,"motorcycle_comment"
		,"update_timestamp"
	)
	WITH "dist_stg" AS 
	( 
		SELECT 
			  "stg_dis_src"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
			, "stg_dis_src"."load_cycle_id" AS "load_cycle_id"
			, MIN("stg_dis_src"."load_date") AS "min_load_timestamp"
		FROM "moto_mktg_stg"."campaign_motorcycles" "stg_dis_src"
		GROUP BY  "stg_dis_src"."lnd_campaign_motorcycles_hkey",  "stg_dis_src"."load_cycle_id"
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "stg_temp_src"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
			, "stg_temp_src"."campaigns_hkey" AS "campaigns_hkey"
			, "stg_temp_src"."products_hkey" AS "products_hkey"
			, "stg_temp_src"."campaign_code" AS "campaign_code"
			, "stg_temp_src"."campaign_start_date" AS "campaign_start_date"
			, "stg_temp_src"."motorcycle_id" AS "motorcycle_id"
			, "stg_temp_src"."load_date" AS "load_date"
			, "stg_temp_src"."load_cycle_id" AS "load_cycle_id"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_temp_src"."motorcycle_emotion_desc"),'~'),'#','\' || '#')
				|| '#' ||  REPLACE(COALESCE(TRIM( "stg_temp_src"."motorcycle_comment"),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_temp_src"."update_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, "stg_temp_src"."record_type" AS "record_type"
			, 'STG' AS "source"
			, 1 AS "origin_id"
			, CASE WHEN "stg_temp_src"."jrn_flag" = 'D' THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
			, "stg_temp_src"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
			, "stg_temp_src"."motorcycle_comment" AS "motorcycle_comment"
			, "stg_temp_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_stg"."campaign_motorcycles" "stg_temp_src"
		UNION ALL 
		SELECT 
			  "lds_src"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
			, "lnd_src"."campaigns_hkey" AS "campaigns_hkey"
			, "lnd_src"."products_hkey" AS "products_hkey"
			, "lds_src"."campaign_code" AS "campaign_code"
			, "lds_src"."campaign_start_date" AS "campaign_start_date"
			, "lds_src"."motorcycle_id" AS "motorcycle_id"
			, "lds_src"."load_date" AS "load_date"
			, "lds_src"."load_cycle_id" AS "load_cycle_id"
			, MAX("lds_src"."load_date")OVER(PARTITION BY "lds_src"."lnd_campaign_motorcycles_hkey") AS "load_end_date"
			, "lds_src"."hash_diff" AS "hash_diff"
			, 'SAT' AS "record_type"
			, 'LDS' AS "source"
			, 0 AS "origin_id"
			, "lds_src"."delete_flag" AS "delete_flag"
			, "lds_src"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
			, "lds_src"."motorcycle_comment" AS "motorcycle_comment"
			, "lds_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" "lds_src"
		INNER JOIN "moto_dv_fl"."lnd_campaign_motorcycles" "lnd_src" ON  "lds_src"."lnd_campaign_motorcycles_hkey" = "lnd_src"."lnd_campaign_motorcycles_hkey"
		INNER JOIN "dist_stg" "dist_stg" ON  "lds_src"."lnd_campaign_motorcycles_hkey" = "dist_stg"."lnd_campaign_motorcycles_hkey"
	)
	SELECT 
		  "temp_table_set"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
		, "temp_table_set"."campaigns_hkey" AS "campaigns_hkey"
		, "temp_table_set"."products_hkey" AS "products_hkey"
		, "temp_table_set"."campaign_code" AS "campaign_code"
		, "temp_table_set"."campaign_start_date" AS "campaign_start_date"
		, "temp_table_set"."motorcycle_id" AS "motorcycle_id"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."hash_diff" AS "hash_diff"
		, "temp_table_set"."record_type" AS "record_type"
		, "temp_table_set"."source" AS "source"
		, CASE WHEN "temp_table_set"."source" = 'STG' AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."hash_diff",'hex'),1)OVER(PARTITION BY "temp_table_set"."lnd_campaign_motorcycles_hkey" ORDER BY "temp_table_set"."load_date","temp_table_set"."origin_id")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
		, "temp_table_set"."motorcycle_comment" AS "motorcycle_comment"
		, "temp_table_set"."update_timestamp" AS "update_timestamp"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 'STG' OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 'LDS')
	;
END;


BEGIN -- lds_inur_tgt

	INSERT INTO "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo"(
		 "lnd_campaign_motorcycles_hkey"
		,"campaign_code"
		,"campaign_start_date"
		,"motorcycle_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"motorcycle_emotion_desc"
		,"motorcycle_comment"
		,"update_timestamp"
	)
	SELECT 
		  "lds_temp_src_inur"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
		, "lds_temp_src_inur"."campaign_code" AS "campaign_code"
		, "lds_temp_src_inur"."campaign_start_date" AS "campaign_start_date"
		, "lds_temp_src_inur"."motorcycle_id" AS "motorcycle_id"
		, "lds_temp_src_inur"."load_date" AS "load_date"
		, "lds_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "lds_temp_src_inur"."hash_diff" AS "hash_diff"
		, "lds_temp_src_inur"."delete_flag" AS "delete_flag"
		, "lds_temp_src_inur"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
		, "lds_temp_src_inur"."motorcycle_comment" AS "motorcycle_comment"
		, "lds_temp_src_inur"."update_timestamp" AS "update_timestamp"
	FROM "moto_mktg_stg"."lds_mktg_campaign_motorcycles_emo_tmp" "lds_temp_src_inur"
	WHERE  "lds_temp_src_inur"."source" = 'STG' AND "lds_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
