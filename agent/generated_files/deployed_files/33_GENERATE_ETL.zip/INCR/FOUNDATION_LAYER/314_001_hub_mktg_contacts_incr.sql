CREATE OR REPLACE FUNCTION "moto_proc"."hub_mktg_contacts_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- hub_tgt

	INSERT INTO "moto_dv_fl"."hub_contacts"(
		 "contacts_hkey"
		,"load_date"
		,"load_cycle_id"
		,"contact_id_bk"
		,"record_source"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."contacts_hkey" AS "contacts_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, "stg_inr_src"."contact_id_bk" AS "contact_id_bk"
			, "stg_inr_src"."record_source" AS "record_source"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."contacts_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_mktg_stg"."contacts" "stg_inr_src"
		WHERE  "stg_inr_src"."record_type" = 'S'
	)
	SELECT 
		  "stg_src"."contacts_hkey" AS "contacts_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."contact_id_bk" AS "contact_id_bk"
		, "stg_src"."record_source" AS "record_source"
	FROM "stg_src" "stg_src"
	LEFT OUTER JOIN "moto_dv_fl"."hub_contacts" "hub_src" ON  "stg_src"."contacts_hkey" = "hub_src"."contacts_hkey"
	WHERE  "stg_src"."dummy" = 1 AND "hub_src"."contacts_hkey" is NULL
	;
END;


END;
$function$;
 
 
