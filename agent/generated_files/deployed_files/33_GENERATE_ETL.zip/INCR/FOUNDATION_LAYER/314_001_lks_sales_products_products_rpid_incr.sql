CREATE OR REPLACE FUNCTION "moto_proc"."lks_sales_products_products_rpid_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lks_temp_tgt

	TRUNCATE TABLE "moto_sales_stg"."lks_sales_products_products_rpid_tmp"  CASCADE;

	INSERT INTO "moto_sales_stg"."lks_sales_products_products_rpid_tmp"(
		 "lnk_products_products_rpid_hkey"
		,"products_rpid_hkey"
		,"products_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_type"
		,"source"
		,"equal"
		,"delete_flag"
		,"product_id"
		,"replacement_product_id"
	)
	WITH "dist_stg" AS 
	( 
		SELECT 
			  "stg_dis_src"."products_hkey" AS "products_hkey"
			, "stg_dis_src"."load_cycle_id" AS "load_cycle_id"
			, MIN("stg_dis_src"."load_date") AS "min_load_timestamp"
		FROM "moto_sales_stg"."products" "stg_dis_src"
		GROUP BY  "stg_dis_src"."products_hkey",  "stg_dis_src"."load_cycle_id"
	)
	, "temp_table_set" AS 
	( 
		SELECT 
			  "stg_temp_src"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
			, "stg_temp_src"."products_rpid_hkey" AS "products_rpid_hkey"
			, "stg_temp_src"."products_hkey" AS "products_hkey"
			, "stg_temp_src"."load_date" AS "load_date"
			, "stg_temp_src"."load_cycle_id" AS "load_cycle_id"
			, TO_TIMESTAMP(NULL, 'DD/MM/YYYY HH24:MI:SS'::varchar) AS "load_end_date"
			, "stg_temp_src"."record_type" AS "record_type"
			, 'STG' AS "source"
			, 1 AS "origin_id"
			, CASE WHEN "stg_temp_src"."jrn_flag" = 'D' THEN 'Y'::text ELSE 'N'::text END AS "delete_flag"
			, "stg_temp_src"."product_id" AS "product_id"
			, "stg_temp_src"."replacement_product_id" AS "replacement_product_id"
		FROM "moto_sales_stg"."products" "stg_temp_src"
		UNION 
		SELECT 
			  "lks_src"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
			, "lnk_src"."products_rpid_hkey" AS "products_rpid_hkey"
			, "lnk_src"."products_hkey" AS "products_hkey"
			, "lks_src"."load_date" AS "load_date"
			, "lks_src"."load_cycle_id" AS "load_cycle_id"
			, MAX("lks_src"."load_date")OVER(PARTITION BY "lnk_src"."products_hkey") AS "load_end_date"
			, 'SAT' AS "record_type"
			, 'LKS' AS "source"
			, 0 AS "origin_id"
			, "lks_src"."delete_flag" AS "delete_flag"
			, "lks_src"."product_id" AS "product_id"
			, "lks_src"."replacement_product_id" AS "replacement_product_id"
		FROM "moto_dv_fl"."lks_sales_products_products_rpid" "lks_src"
		INNER JOIN "moto_dv_fl"."lnk_products_products_rpid" "lnk_src" ON  "lks_src"."lnk_products_products_rpid_hkey" = "lnk_src"."lnk_products_products_rpid_hkey"
		INNER JOIN "dist_stg" "dist_stg" ON  "lnk_src"."products_hkey" = "dist_stg"."products_hkey"
	)
	SELECT 
		  "temp_table_set"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
		, "temp_table_set"."products_rpid_hkey" AS "products_rpid_hkey"
		, "temp_table_set"."products_hkey" AS "products_hkey"
		, "temp_table_set"."load_date" AS "load_date"
		, "temp_table_set"."load_cycle_id" AS "load_cycle_id"
		, "temp_table_set"."record_type" AS "record_type"
		, "temp_table_set"."source" AS "source"
		, CASE WHEN "temp_table_set"."source" = 'STG' AND "temp_table_set"."delete_flag"::text || encode("temp_table_set"."products_rpid_hkey",
			'hex') = LAG( "temp_table_set"."delete_flag"::text || encode("temp_table_set"."products_rpid_hkey",'hex'),1)OVER(PARTITION BY "temp_table_set"."products_hkey" ORDER BY "temp_table_set"."load_date","temp_table_set"."origin_id")THEN 1 ELSE 0 END AS "equal"
		, "temp_table_set"."delete_flag" AS "delete_flag"
		, "temp_table_set"."product_id" AS "product_id"
		, "temp_table_set"."replacement_product_id" AS "replacement_product_id"
	FROM "temp_table_set" "temp_table_set"
	WHERE  "temp_table_set"."source" = 'STG' OR("temp_table_set"."load_date" = "temp_table_set"."load_end_date" AND "temp_table_set"."source" = 'LKS')
	;
END;


BEGIN -- lks_inur_tgt

	INSERT INTO "moto_dv_fl"."lks_sales_products_products_rpid"(
		 "lnk_products_products_rpid_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"product_id"
		,"replacement_product_id"
	)
	SELECT 
		  "lks_temp_src_inur"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
		, "lks_temp_src_inur"."load_date" AS "load_date"
		, "lks_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "lks_temp_src_inur"."delete_flag" AS "delete_flag"
		, "lks_temp_src_inur"."product_id" AS "product_id"
		, "lks_temp_src_inur"."replacement_product_id" AS "replacement_product_id"
	FROM "moto_sales_stg"."lks_sales_products_products_rpid_tmp" "lks_temp_src_inur"
	WHERE  "lks_temp_src_inur"."source" = 'STG' AND "lks_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
