CREATE OR REPLACE FUNCTION "moto_proc"."hub_sales_addresses_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- hub_tgt

	INSERT INTO "moto_dv_fl"."hub_addresses"(
		 "addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"street_name_bk"
		,"street_number_bk"
		,"postal_code_bk"
		,"city_bk"
		,"record_source"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."addresses_hkey" AS "addresses_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, "stg_inr_src"."street_name_bk" AS "street_name_bk"
			, "stg_inr_src"."street_number_bk" AS "street_number_bk"
			, "stg_inr_src"."postal_code_bk" AS "postal_code_bk"
			, "stg_inr_src"."city_bk" AS "city_bk"
			, "stg_inr_src"."record_source" AS "record_source"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."addresses_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_sales_stg"."addresses" "stg_inr_src"
		WHERE  "stg_inr_src"."record_type" = 'S'
	)
	SELECT 
		  "stg_src"."addresses_hkey" AS "addresses_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."street_name_bk" AS "street_name_bk"
		, "stg_src"."street_number_bk" AS "street_number_bk"
		, "stg_src"."postal_code_bk" AS "postal_code_bk"
		, "stg_src"."city_bk" AS "city_bk"
		, "stg_src"."record_source" AS "record_source"
	FROM "stg_src" "stg_src"
	LEFT OUTER JOIN "moto_dv_fl"."hub_addresses" "hub_src" ON  "stg_src"."addresses_hkey" = "hub_src"."addresses_hkey"
	WHERE  "stg_src"."dummy" = 1 AND "hub_src"."addresses_hkey" is NULL
	;
END;


END;
$function$;
 
 
