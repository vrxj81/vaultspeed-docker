CREATE OR REPLACE FUNCTION "moto_proc"."ext_sales_productfeatclassrel_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- ext_tgt

	TRUNCATE TABLE "moto_sales_ext"."product_feat_class_rel"  CASCADE;

	INSERT INTO "moto_sales_ext"."product_feat_class_rel"(
		 "load_cycle_id"
		,"load_date"
		,"jrn_flag"
		,"record_type"
		,"product_feature_id"
		,"product_id"
		,"product_feature_class_id"
		,"update_timestamp"
	)
	WITH "calculate_bk" AS 
	( 
		SELECT 
			  "lci_src"."load_cycle_id" AS "load_cycle_id"
			, CURRENT_TIMESTAMP + row_number() over (order by "lci_src"."load_date") * interval'2 microsecond'   AS "load_date"
			, "mex_src"."attribute_varchar" AS "jrn_flag"
			, "tdfv_src"."record_type" AS "record_type"
			, "tdfv_src"."product_feature_id" AS "product_feature_id"
			, "tdfv_src"."product_id" AS "product_id"
			, "tdfv_src"."product_feature_class_id" AS "product_feature_class_id"
			, "tdfv_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_dfv"."vw_product_feat_class_rel" "tdfv_src"
		INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		WHERE  "mex_src"."record_type" = 'N'
	)
	SELECT 
		  "calculate_bk"."load_cycle_id" AS "load_cycle_id"
		, "calculate_bk"."load_date" AS "load_date"
		, "calculate_bk"."jrn_flag" AS "jrn_flag"
		, "calculate_bk"."record_type" AS "record_type"
		, "calculate_bk"."product_feature_id" AS "product_feature_id"
		, "calculate_bk"."product_id" AS "product_id"
		, "calculate_bk"."product_feature_class_id" AS "product_feature_class_id"
		, "calculate_bk"."update_timestamp" AS "update_timestamp"
	FROM "calculate_bk" "calculate_bk"
	;
END;


END;
$function$;
 
 
