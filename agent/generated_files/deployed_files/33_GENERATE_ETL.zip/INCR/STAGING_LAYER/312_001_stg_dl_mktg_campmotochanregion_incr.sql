CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_mktg_campmotochanregion_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- stg_dl_tgt

	TRUNCATE TABLE "moto_mktg_stg"."camp_moto_chan_region"  CASCADE;

	INSERT INTO "moto_mktg_stg"."camp_moto_chan_region"(
		 "lnd_camp_moto_chan_region_hkey"
		,"channels_hkey"
		,"products_hkey"
		,"campaigns_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"channel_id"
		,"campaign_code"
		,"campaign_start_date"
		,"motorcycle_id"
		,"campaign_code_fk_campaignstartdate_bk"
		,"region_seq"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."channel_id" AS "channel_id"
		FROM "moto_mktg_ext"."camp_moto_chan_region" "ext_dis_io_src1"
	)
	, "dist_io_fk2" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src2"."motorcycle_id" AS "motorcycle_id"
		FROM "moto_mktg_ext"."camp_moto_chan_region" "ext_dis_io_src2"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."channels_hkey" AS "channels_hkey"
			, "sat_io_src1"."channel_id" AS "channel_id"
			, MAX("sat_io_src1"."load_date") AS "load_date"
		FROM "moto_dv_fl"."sat_mktg_channels" "sat_io_src1"
		INNER JOIN "dist_io_fk1" "dist_io_fk1" ON  "dist_io_fk1"."channel_id" = "sat_io_src1"."channel_id"
		GROUP BY  "sat_io_src1"."channels_hkey",  "sat_io_src1"."channel_id"
	)
	, "sat_src2" AS 
	( 
		SELECT 
			  "sat_io_src2"."products_hkey" AS "products_hkey"
			, "sat_io_src2"."motorcycle_id" AS "motorcycle_id"
			, MAX("sat_io_src2"."load_date") AS "load_date"
		FROM "moto_dv_fl"."sat_mktg_products" "sat_io_src2"
		INNER JOIN "dist_io_fk2" "dist_io_fk2" ON  "dist_io_fk2"."motorcycle_id" = "sat_io_src2"."motorcycle_id"
		GROUP BY  "sat_io_src2"."products_hkey",  "sat_io_src2"."motorcycle_id"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."channel_id" AS "channel_id"
		FROM "moto_mktg_ext"."camp_moto_chan_region" "ext_dis_src1"
	)
	, "dist_fk2" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src2"."motorcycle_id" AS "motorcycle_id"
		FROM "moto_mktg_ext"."camp_moto_chan_region" "ext_dis_src2"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  "hub_src1"."channel_code_bk" AS "channel_code_bk"
			, "dist_fk1"."channel_id" AS "channel_id"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."channel_id" = "sat_src1"."channel_id"
		INNER JOIN "moto_dv_fl"."hub_channels" "hub_src1" ON  "hub_src1"."channels_hkey" = "sat_src1"."channels_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."channel_code_bk" AS "channel_code_bk"
			, "dist_fk1"."channel_id" AS "channel_id"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_mktg_ext"."channels" "ext_fkbk_src1" ON  "dist_fk1"."channel_id" = "ext_fkbk_src1"."channel_id"
	)
	, "prep_find_bk_fk2" AS 
	( 
		SELECT 
			  "hub_src2"."product_cc_bk" AS "motorcycle_cc_bk"
			, "hub_src2"."product_et_code_bk" AS "motorcycle_et_code_bk"
			, "hub_src2"."product_part_code_bk" AS "motorcycle_part_code_bk"
			, "dist_fk2"."motorcycle_id" AS "motorcycle_id"
			, "sat_src2"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk2" "dist_fk2"
		INNER JOIN "sat_src2" "sat_src2" ON  "dist_fk2"."motorcycle_id" = "sat_src2"."motorcycle_id"
		INNER JOIN "moto_dv_fl"."hub_products" "hub_src2" ON  "hub_src2"."products_hkey" = "sat_src2"."products_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src2"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
			, "ext_fkbk_src2"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
			, "ext_fkbk_src2"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
			, "dist_fk2"."motorcycle_id" AS "motorcycle_id"
			, "ext_fkbk_src2"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk2" "dist_fk2"
		INNER JOIN "moto_mktg_ext"."motorcycles" "ext_fkbk_src2" ON  "dist_fk2"."motorcycle_id" = "ext_fkbk_src2"."motorcycle_id"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."channel_code_bk" AS "channel_code_bk"
			, "prep_find_bk_fk1"."channel_id" AS "channel_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."channel_id" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "order_bk_fk2" AS 
	( 
		SELECT 
			  "prep_find_bk_fk2"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
			, "prep_find_bk_fk2"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
			, "prep_find_bk_fk2"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
			, "prep_find_bk_fk2"."motorcycle_id" AS "motorcycle_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk2"."motorcycle_id" ORDER BY "prep_find_bk_fk2"."general_order",
				"prep_find_bk_fk2"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk2" "prep_find_bk_fk2"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."channel_code_bk" AS "channel_code_bk"
			, "order_bk_fk1"."channel_id" AS "channel_id"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	, "find_bk_fk2" AS 
	( 
		SELECT 
			  "order_bk_fk2"."motorcycle_cc_bk" AS "motorcycle_cc_bk"
			, "order_bk_fk2"."motorcycle_et_code_bk" AS "motorcycle_et_code_bk"
			, "order_bk_fk2"."motorcycle_part_code_bk" AS "motorcycle_part_code_bk"
			, "order_bk_fk2"."motorcycle_id" AS "motorcycle_id"
		FROM "order_bk_fk2" "order_bk_fk2"
		WHERE  "order_bk_fk2"."dummy" = 1
	)
	SELECT 
		  DIGEST(  COALESCE("find_bk_fk1"."channel_code_bk","mex_src"."key_attribute_varchar")|| '#' || COALESCE("find_bk_fk2"."motorcycle_cc_bk",
			"mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk2"."motorcycle_et_code_bk","mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk2"."motorcycle_part_code_bk","mex_src"."key_attribute_varchar")|| '#' || "ext_src"."campaign_code_fk_campaignstartdate_bk" || '#'  ,'SHA1') AS "lnd_camp_moto_chan_region_hkey"
		, DIGEST( COALESCE("find_bk_fk1"."channel_code_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "channels_hkey"
		, DIGEST( COALESCE("find_bk_fk2"."motorcycle_cc_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk2"."motorcycle_et_code_bk",
			"mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk2"."motorcycle_part_code_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "products_hkey"
		, DIGEST( "ext_src"."campaign_code_fk_campaignstartdate_bk" || '#' ,'SHA1') AS "campaigns_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'mm.camp_moto_chan_region' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."channel_id" AS "channel_id"
		, "ext_src"."campaign_code" AS "campaign_code"
		, "ext_src"."campaign_start_date" AS "campaign_start_date"
		, "ext_src"."motorcycle_id" AS "motorcycle_id"
		, "ext_src"."campaign_code_fk_campaignstartdate_bk" AS "campaign_code_fk_campaignstartdate_bk"
		, "ext_src"."region_seq" AS "region_seq"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_mktg_ext"."camp_moto_chan_region" "ext_src"
	INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."channel_id" = "find_bk_fk1"."channel_id"
	LEFT OUTER JOIN "find_bk_fk2" "find_bk_fk2" ON  "ext_src"."motorcycle_id" = "find_bk_fk2"."motorcycle_id"
	;
END;


END;
$function$;
 
 
