CREATE OR REPLACE FUNCTION "moto_proc"."stg_mktg_campaigns_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- stg_tgt

	TRUNCATE TABLE "moto_mktg_stg"."campaigns"  CASCADE;

	INSERT INTO "moto_mktg_stg"."campaigns"(
		 "campaigns_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"campaign_code"
		,"campaign_start_date"
		,"campaign_code_bk"
		,"campaign_start_date_seq"
		,"campaign_name"
		,"update_timestamp"
	)
	SELECT 
		  DIGEST( "ext_src"."campaign_code_bk" || '#' ,'SHA1') AS "campaigns_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'mm.campaigns' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."campaign_code" AS "campaign_code"
		, "ext_src"."campaign_start_date" AS "campaign_start_date"
		, "ext_src"."campaign_code_bk" AS "campaign_code_bk"
		, "ext_src"."campaign_start_date_seq" AS "campaign_start_date_seq"
		, "ext_src"."campaign_name" AS "campaign_name"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_mktg_ext"."campaigns" "ext_src"
	INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	;
END;


END;
$function$;
 
 
