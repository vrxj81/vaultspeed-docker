CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_invoices_prep_delete"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_prep_del_tgt

	INSERT INTO "moto_sales_stg"."invoices"(
		 "invoices_hkey"
		,"customers_hkey"
		,"lnk_invoices_customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"jrn_flag"
		,"record_type"
		,"invoice_number"
		,"invoice_customer_id"
		,"invoice_number_bk"
		,"invoice_date"
		,"amount"
		,"discount"
		,"update_timestamp"
	)
	WITH "sat_src1" AS 
	( 
		SELECT 
			  "sat_ed_src1"."invoices_hkey" AS "invoices_hkey"
			, COALESCE(LEAD("sat_ed_src1"."load_date")OVER(PARTITION BY "sat_ed_src1"."invoices_hkey" ORDER BY "sat_ed_src1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "sat_ed_src1"."invoice_number" AS "invoice_number"
			, "sat_ed_src1"."delete_flag" AS "delete_flag"
			, "sat_ed_src1"."load_cycle_id" AS "load_cycle_id"
			, "sat_ed_src1"."invoice_date" AS "invoice_date"
			, "sat_ed_src1"."amount" AS "amount"
			, "sat_ed_src1"."discount" AS "discount"
			, "sat_ed_src1"."update_timestamp" AS "update_timestamp"
		FROM "moto_dv_fl"."sat_sales_invoices" "sat_ed_src1"
	)
	, "lks_src1" AS 
	( 
		SELECT 
			  "lks_ed_src1"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
			, "lks_ed_src1"."invoice_customer_id" AS "invoice_customer_id"
			, COALESCE(LEAD("lks_ed_src1"."load_date")OVER(PARTITION BY "lnk_ed_src1"."invoices_hkey" ORDER BY "lks_ed_src1"."load_date")
				, TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "load_end_date"
			, "lks_ed_src1"."delete_flag" AS "delete_flag"
		FROM "moto_dv_fl"."lks_sales_invoices_customers" "lks_ed_src1"
		INNER JOIN "moto_dv_fl"."lnk_invoices_customers" "lnk_ed_src1" ON  "lks_ed_src1"."lnk_invoices_customers_hkey" = "lnk_ed_src1"."lnk_invoices_customers_hkey"
	)
	SELECT 
		  "hub_src"."invoices_hkey" AS "invoices_hkey"
		, "lnk_src1"."customers_hkey" AS "customers_hkey"
		, "lnk_src1"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
		, "lci_src"."load_date" AS "load_date"
		, "lci_src"."load_cycle_id" AS "load_cycle_id"
		, 'D' AS "jrn_flag"
		, 'S' AS "record_type"
		, "sat_src1"."invoice_number" AS "invoice_number"
		, "lks_src1"."invoice_customer_id" AS "invoice_customer_id"
		, "hub_src"."invoice_number_bk" AS "invoice_number_bk"
		, "sat_src1"."invoice_date" AS "invoice_date"
		, "sat_src1"."amount" AS "amount"
		, "sat_src1"."discount" AS "discount"
		, "sat_src1"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."hub_invoices" "hub_src"
	INNER JOIN "sat_src1" "sat_src1" ON  "sat_src1"."invoices_hkey" = "hub_src"."invoices_hkey" AND "sat_src1"."load_end_date" = TO_TIMESTAMP('31/12/2999 23:59:59',
		 'DD/MM/YYYY HH24:MI:SS'::varchar) AND "sat_src1"."delete_flag" = 'N'::text
	INNER JOIN "moto_dv_fl"."lnk_invoices_customers" "lnk_src1" ON  "lnk_src1"."invoices_hkey" = "hub_src"."invoices_hkey"
	INNER JOIN "lks_src1" "lks_src1" ON  "lks_src1"."lnk_invoices_customers_hkey" = "lnk_src1"."lnk_invoices_customers_hkey" AND "lks_src1"."load_end_date" =
		TO_TIMESTAMP('31/12/2999 23:59:59', 'DD/MM/YYYY HH24:MI:SS'::varchar) AND "lks_src1"."delete_flag" = 'N'::text
	LEFT OUTER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "hub_src"."load_cycle_id"::text = "mex_src"."load_cycle_id"
	INNER JOIN "moto_sales_mtd"."load_cycle_info" "lci_src" ON  1 = 1
	LEFT OUTER JOIN "moto_sales_stg"."invoices" "stg_src" ON  "hub_src"."invoices_hkey" = "stg_src"."invoices_hkey"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src_bk" ON  1 = 1
	WHERE  "stg_src"."load_cycle_id" IS NULL AND "mex_src"."load_cycle_id" IS NULL AND "mex_src_bk"."record_type" = 'N'
	;
END;


END;
$function$;
 
 
