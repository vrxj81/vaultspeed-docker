CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_parts_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_tgt

	TRUNCATE TABLE "moto_sales_stg"."parts"  CASCADE;

	INSERT INTO "moto_sales_stg"."parts"(
		 "parts_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"part_id"
		,"part_number_bk"
		,"part_language_code_seq"
		,"update_timestamp"
	)
	SELECT 
		  DIGEST( "ext_src"."part_number_bk" || '#' ,'SHA1') AS "parts_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.parts' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."part_id" AS "part_id"
		, "ext_src"."part_number_bk" AS "part_number_bk"
		, "ext_src"."part_language_code_seq" AS "part_language_code_seq"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."parts" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	;
END;


END;
$function$;
 
 
