CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_invoices_incr"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_tgt

	TRUNCATE TABLE "moto_sales_stg"."invoices"  CASCADE;

	INSERT INTO "moto_sales_stg"."invoices"(
		 "invoices_hkey"
		,"customers_hkey"
		,"lnk_invoices_customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"invoice_number"
		,"invoice_customer_id"
		,"invoice_number_bk"
		,"invoice_date"
		,"amount"
		,"discount"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."invoice_customer_id" AS "invoice_customer_id"
		FROM "moto_sales_ext"."invoices" "ext_dis_io_src1"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."customers_hkey" AS "customers_hkey"
			, "sat_io_src1"."customer_number" AS "customer_number"
			, MAX("sat_io_src1"."load_date") AS "load_date"
			, "sat_io_src1"."national_person_id" AS "national_person_id"
		FROM "dist_io_fk1" "dist_io_fk1"
		INNER JOIN "moto_dv_fl"."sat_sales_customers_birth" "sat_io_src1" ON  "dist_io_fk1"."invoice_customer_id" = "sat_io_src1"."customer_number"
		GROUP BY  "sat_io_src1"."customers_hkey",  "sat_io_src1"."customer_number",  "sat_io_src1"."national_person_id"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."invoice_customer_id" AS "invoice_customer_id"
		FROM "moto_sales_ext"."invoices" "ext_dis_src1"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  UPPER(REPLACE(TRIM( "sat_src1"."national_person_id"),'#','\' || '#')) AS "national_person_id_bk"
			, "dist_fk1"."invoice_customer_id" AS "invoice_customer_id"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."invoice_customer_id" = "sat_src1"."customer_number"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_src1" ON  "hub_src1"."customers_hkey" = "sat_src1"."customers_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."national_person_id_bk" AS "national_person_id_bk"
			, "dist_fk1"."invoice_customer_id" AS "invoice_customer_id"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_sales_ext"."customers" "ext_fkbk_src1" ON  "dist_fk1"."invoice_customer_id" = "ext_fkbk_src1"."customer_number"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."national_person_id_bk" AS "national_person_id_bk"
			, "prep_find_bk_fk1"."invoice_customer_id" AS "invoice_customer_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."invoice_customer_id" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."national_person_id_bk" AS "national_person_id_bk"
			, "order_bk_fk1"."invoice_customer_id" AS "invoice_customer_id"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	SELECT 
		  DIGEST( "ext_src"."invoice_number_bk" || '#' ,'SHA1') AS "invoices_hkey"
		, DIGEST( 'ms' || '#' || COALESCE("find_bk_fk1"."national_person_id_bk","mex_src"."key_attribute_varchar")|| '#' ,
			'SHA1') AS "customers_hkey"
		, DIGEST( "ext_src"."invoice_number_bk" || '#' || 'ms' || '#' || COALESCE("find_bk_fk1"."national_person_id_bk",
			"mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "lnk_invoices_customers_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.invoices' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."invoice_number" AS "invoice_number"
		, "ext_src"."invoice_customer_id" AS "invoice_customer_id"
		, "ext_src"."invoice_number_bk" AS "invoice_number_bk"
		, "ext_src"."invoice_date" AS "invoice_date"
		, "ext_src"."amount" AS "amount"
		, "ext_src"."discount" AS "discount"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."invoices" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."invoice_customer_id" = "find_bk_fk1"."invoice_customer_id"
	;
END;


END;
$function$;
 
 
