CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_mktg_partycontacts_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- stg_dl_tgt

	TRUNCATE TABLE "moto_mktg_stg"."party_contacts"  CASCADE;

	INSERT INTO "moto_mktg_stg"."party_contacts"(
		 "lnd_party_contacts_hkey"
		,"customers_hkey"
		,"contacts_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"party_number"
		,"contact_id"
		,"contact_id_fk_contactid_bk"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."party_number" AS "party_number"
		FROM "moto_mktg_ext"."party_contacts" "ext_dis_io_src1"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."customers_hkey" AS "customers_hkey"
			, "sat_io_src1"."party_number" AS "party_number"
			, MAX("sat_io_src1"."load_date") AS "load_date"
			, "sat_io_src1"."name" AS "name"
			, "sat_io_src1"."birthdate" AS "birthdate"
			, "sat_io_src1"."gender" AS "gender"
			, "sat_io_src1"."party_type_code" AS "party_type_code"
		FROM "dist_io_fk1" "dist_io_fk1"
		INNER JOIN "moto_dv_fl"."sat_mktg_customers" "sat_io_src1" ON  "dist_io_fk1"."party_number" = "sat_io_src1"."party_number"
		GROUP BY  "sat_io_src1"."customers_hkey",  "sat_io_src1"."party_number",  "sat_io_src1"."name",  "sat_io_src1"."birthdate",
			  "sat_io_src1"."gender",  "sat_io_src1"."party_type_code"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."party_number" AS "party_number"
		FROM "moto_mktg_ext"."party_contacts" "ext_dis_src1"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  UPPER(REPLACE(TRIM( "sat_src1"."name"),'#','\' || '#')) AS "name_bk"
			, UPPER( TO_CHAR("sat_src1"."birthdate", 'DD/MM/YYYY'::varchar)) AS "birthdate_bk"
			, UPPER(REPLACE(TRIM( "sat_src1"."gender"),'#','\' || '#')) AS "gender_bk"
			, UPPER(REPLACE(TRIM( "sat_src1"."party_type_code"),'#','\' || '#')) AS "party_type_code_bk"
			, "dist_fk1"."party_number" AS "party_number"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."party_number" = "sat_src1"."party_number"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_src1" ON  "hub_src1"."customers_hkey" = "sat_src1"."customers_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."name_bk" AS "name_bk"
			, "ext_fkbk_src1"."birthdate_bk" AS "birthdate_bk"
			, "ext_fkbk_src1"."gender_bk" AS "gender_bk"
			, "ext_fkbk_src1"."party_type_code_bk" AS "party_type_code_bk"
			, "dist_fk1"."party_number" AS "party_number"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_mktg_ext"."party" "ext_fkbk_src1" ON  "dist_fk1"."party_number" = "ext_fkbk_src1"."party_number"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."name_bk" AS "name_bk"
			, "prep_find_bk_fk1"."birthdate_bk" AS "birthdate_bk"
			, "prep_find_bk_fk1"."gender_bk" AS "gender_bk"
			, "prep_find_bk_fk1"."party_type_code_bk" AS "party_type_code_bk"
			, "prep_find_bk_fk1"."party_number" AS "party_number"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."party_number" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."name_bk" AS "name_bk"
			, "order_bk_fk1"."birthdate_bk" AS "birthdate_bk"
			, "order_bk_fk1"."gender_bk" AS "gender_bk"
			, "order_bk_fk1"."party_type_code_bk" AS "party_type_code_bk"
			, "order_bk_fk1"."party_number" AS "party_number"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	SELECT 
		  DIGEST(  'mm' || '#' || COALESCE("find_bk_fk1"."name_bk","mex_src"."key_attribute_varchar")|| '#' ||  COALESCE("find_bk_fk1"."birthdate_bk",
			"mex_src"."key_attribute_date")|| '#' ||  COALESCE("find_bk_fk1"."gender_bk","mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk1"."party_type_code_bk","mex_src"."key_attribute_character")|| '#' || "ext_src"."contact_id_fk_contactid_bk" || '#'  ,'SHA1') AS "lnd_party_contacts_hkey"
		, DIGEST( 'mm' || '#' || COALESCE("find_bk_fk1"."name_bk","mex_src"."key_attribute_varchar")|| '#' ||  COALESCE("find_bk_fk1"."birthdate_bk",
			"mex_src"."key_attribute_date")|| '#' ||  COALESCE("find_bk_fk1"."gender_bk","mex_src"."key_attribute_character")|| '#' ||  COALESCE("find_bk_fk1"."party_type_code_bk","mex_src"."key_attribute_character")|| '#' ,'SHA1') AS "customers_hkey"
		, DIGEST( "ext_src"."contact_id_fk_contactid_bk" || '#' ,'SHA1') AS "contacts_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'mm.party_contacts' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."party_number" AS "party_number"
		, "ext_src"."contact_id" AS "contact_id"
		, "ext_src"."contact_id_fk_contactid_bk" AS "contact_id_fk_contactid_bk"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_mktg_ext"."party_contacts" "ext_src"
	INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."party_number" = "find_bk_fk1"."party_number"
	;
END;


END;
$function$;
 
 
