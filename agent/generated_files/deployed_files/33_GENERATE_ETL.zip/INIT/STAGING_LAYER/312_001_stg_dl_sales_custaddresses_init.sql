CREATE OR REPLACE FUNCTION "moto_proc"."stg_dl_sales_custaddresses_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_dl_tgt

	TRUNCATE TABLE "moto_sales_stg"."cust_addresses"  CASCADE;

	INSERT INTO "moto_sales_stg"."cust_addresses"(
		 "lnd_cust_addresses_hkey"
		,"customers_hkey"
		,"addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"customer_number"
		,"address_number"
		,"address_type_seq"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."customer_number" AS "customer_number"
		FROM "moto_sales_ext"."cust_addresses" "ext_dis_io_src1"
	)
	, "dist_io_fk2" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src2"."address_number" AS "address_number"
		FROM "moto_sales_ext"."cust_addresses" "ext_dis_io_src2"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."customers_hkey" AS "customers_hkey"
			, "sat_io_src1"."customer_number" AS "customer_number"
			, MAX("sat_io_src1"."load_date") AS "load_date"
			, "sat_io_src1"."national_person_id" AS "national_person_id"
		FROM "dist_io_fk1" "dist_io_fk1"
		INNER JOIN "moto_dv_fl"."sat_sales_customers_birth" "sat_io_src1" ON  "dist_io_fk1"."customer_number" = "sat_io_src1"."customer_number"
		GROUP BY  "sat_io_src1"."customers_hkey",  "sat_io_src1"."customer_number",  "sat_io_src1"."national_person_id"
	)
	, "sat_src2" AS 
	( 
		SELECT 
			  "sat_io_src2"."addresses_hkey" AS "addresses_hkey"
			, "sat_io_src2"."address_number" AS "address_number"
			, MAX("sat_io_src2"."load_date") AS "load_date"
		FROM "dist_io_fk2" "dist_io_fk2"
		INNER JOIN "moto_dv_fl"."sat_sales_addresses" "sat_io_src2" ON  "dist_io_fk2"."address_number" = "sat_io_src2"."address_number"
		GROUP BY  "sat_io_src2"."addresses_hkey",  "sat_io_src2"."address_number"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."customer_number" AS "customer_number"
		FROM "moto_sales_ext"."cust_addresses" "ext_dis_src1"
	)
	, "dist_fk2" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src2"."address_number" AS "address_number"
		FROM "moto_sales_ext"."cust_addresses" "ext_dis_src2"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  UPPER(REPLACE(TRIM( "sat_src1"."national_person_id"),'#','\' || '#')) AS "national_person_id_bk"
			, "dist_fk1"."customer_number" AS "customer_number"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."customer_number" = "sat_src1"."customer_number"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_src1" ON  "hub_src1"."customers_hkey" = "sat_src1"."customers_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."national_person_id_bk" AS "national_person_id_bk"
			, "dist_fk1"."customer_number" AS "customer_number"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_sales_ext"."customers" "ext_fkbk_src1" ON  "dist_fk1"."customer_number" = "ext_fkbk_src1"."customer_number"
	)
	, "prep_find_bk_fk2" AS 
	( 
		SELECT 
			  "hub_src2"."street_name_bk" AS "street_name_bk"
			, "hub_src2"."street_number_bk" AS "street_number_bk"
			, "hub_src2"."postal_code_bk" AS "postal_code_bk"
			, "hub_src2"."city_bk" AS "city_bk"
			, "dist_fk2"."address_number" AS "address_number"
			, "sat_src2"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk2" "dist_fk2"
		INNER JOIN "sat_src2" "sat_src2" ON  "dist_fk2"."address_number" = "sat_src2"."address_number"
		INNER JOIN "moto_dv_fl"."hub_addresses" "hub_src2" ON  "hub_src2"."addresses_hkey" = "sat_src2"."addresses_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src2"."street_name_bk" AS "street_name_bk"
			, "ext_fkbk_src2"."street_number_bk" AS "street_number_bk"
			, "ext_fkbk_src2"."postal_code_bk" AS "postal_code_bk"
			, "ext_fkbk_src2"."city_bk" AS "city_bk"
			, "dist_fk2"."address_number" AS "address_number"
			, "ext_fkbk_src2"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk2" "dist_fk2"
		INNER JOIN "moto_sales_ext"."addresses" "ext_fkbk_src2" ON  "dist_fk2"."address_number" = "ext_fkbk_src2"."address_number"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."national_person_id_bk" AS "national_person_id_bk"
			, "prep_find_bk_fk1"."customer_number" AS "customer_number"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."customer_number" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "order_bk_fk2" AS 
	( 
		SELECT 
			  "prep_find_bk_fk2"."street_name_bk" AS "street_name_bk"
			, "prep_find_bk_fk2"."street_number_bk" AS "street_number_bk"
			, "prep_find_bk_fk2"."postal_code_bk" AS "postal_code_bk"
			, "prep_find_bk_fk2"."city_bk" AS "city_bk"
			, "prep_find_bk_fk2"."address_number" AS "address_number"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk2"."address_number" ORDER BY "prep_find_bk_fk2"."general_order",
				"prep_find_bk_fk2"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk2" "prep_find_bk_fk2"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."national_person_id_bk" AS "national_person_id_bk"
			, "order_bk_fk1"."customer_number" AS "customer_number"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	, "find_bk_fk2" AS 
	( 
		SELECT 
			  "order_bk_fk2"."street_name_bk" AS "street_name_bk"
			, "order_bk_fk2"."street_number_bk" AS "street_number_bk"
			, "order_bk_fk2"."postal_code_bk" AS "postal_code_bk"
			, "order_bk_fk2"."city_bk" AS "city_bk"
			, "order_bk_fk2"."address_number" AS "address_number"
		FROM "order_bk_fk2" "order_bk_fk2"
		WHERE  "order_bk_fk2"."dummy" = 1
	)
	SELECT 
		  DIGEST(  'ms' || '#' || COALESCE("find_bk_fk1"."national_person_id_bk","mex_src"."key_attribute_varchar")|| 
			'#' || COALESCE("find_bk_fk2"."street_name_bk","mex_src"."key_attribute_varchar")|| '#' ||  COALESCE("find_bk_fk2"."street_number_bk","mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk2"."postal_code_bk","mex_src"."key_attribute_varchar")|| '#' ||  COALESCE("find_bk_fk2"."city_bk","mex_src"."key_attribute_varchar")|| '#'  ,'SHA1') AS "lnd_cust_addresses_hkey"
		, DIGEST( 'ms' || '#' || COALESCE("find_bk_fk1"."national_person_id_bk","mex_src"."key_attribute_varchar")|| '#' ,
			'SHA1') AS "customers_hkey"
		, DIGEST( COALESCE("find_bk_fk2"."street_name_bk","mex_src"."key_attribute_varchar")|| '#' ||  COALESCE("find_bk_fk2"."street_number_bk",
			"mex_src"."key_attribute_numeric")|| '#' ||  COALESCE("find_bk_fk2"."postal_code_bk","mex_src"."key_attribute_varchar")|| '#' ||  COALESCE("find_bk_fk2"."city_bk","mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "addresses_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.cust_addresses' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."customer_number" AS "customer_number"
		, "ext_src"."address_number" AS "address_number"
		, "ext_src"."address_type_seq" AS "address_type_seq"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."cust_addresses" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."customer_number" = "find_bk_fk1"."customer_number"
	LEFT OUTER JOIN "find_bk_fk2" "find_bk_fk2" ON  "ext_src"."address_number" = "find_bk_fk2"."address_number"
	;
END;


END;
$function$;
 
 
