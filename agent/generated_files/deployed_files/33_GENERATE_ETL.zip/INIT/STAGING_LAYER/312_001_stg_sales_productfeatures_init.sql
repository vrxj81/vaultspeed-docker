CREATE OR REPLACE FUNCTION "moto_proc"."stg_sales_productfeatures_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- stg_tgt

	TRUNCATE TABLE "moto_sales_stg"."product_features"  CASCADE;

	INSERT INTO "moto_sales_stg"."product_features"(
		 "product_features_hkey"
		,"product_feature_cat_hkey"
		,"lnk_productfeatures_productfeaturecat_hkey"
		,"load_date"
		,"load_cycle_id"
		,"record_source"
		,"jrn_flag"
		,"record_type"
		,"product_feature_id"
		,"product_feature_cat_id"
		,"product_feature_code_bk"
		,"product_feature_language_code_seq"
		,"product_feature_description"
		,"update_timestamp"
	)
	WITH "dist_io_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_io_src1"."product_feature_cat_id" AS "product_feature_cat_id"
		FROM "moto_sales_ext"."product_features" "ext_dis_io_src1"
	)
	, "sat_src1" AS 
	( 
		SELECT 
			  "sat_io_src1"."product_feature_cat_hkey" AS "product_feature_cat_hkey"
			, "sat_io_src1"."product_feature_category_id" AS "product_feature_category_id"
			, MAX("sat_io_src1"."load_date") AS "load_date"
		FROM "dist_io_fk1" "dist_io_fk1"
		INNER JOIN "moto_dv_fl"."sat_sales_product_feature_cat" "sat_io_src1" ON  "dist_io_fk1"."product_feature_cat_id" = "sat_io_src1"."product_feature_category_id"
		GROUP BY  "sat_io_src1"."product_feature_cat_hkey",  "sat_io_src1"."product_feature_category_id"
	)
	, "dist_fk1" AS 
	( 
		SELECT DISTINCT 
 			  "ext_dis_src1"."product_feature_cat_id" AS "product_feature_cat_id"
		FROM "moto_sales_ext"."product_features" "ext_dis_src1"
	)
	, "prep_find_bk_fk1" AS 
	( 
		SELECT 
			  "hub_src1"."product_feature_category_code_bk" AS "product_feature_category_code_bk"
			, "dist_fk1"."product_feature_cat_id" AS "product_feature_cat_id"
			, "sat_src1"."load_date" AS "load_date"
			, 1 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "sat_src1" "sat_src1" ON  "dist_fk1"."product_feature_cat_id" = "sat_src1"."product_feature_category_id"
		INNER JOIN "moto_dv_fl"."hub_product_feature_cat" "hub_src1" ON  "hub_src1"."product_feature_cat_hkey" = "sat_src1"."product_feature_cat_hkey"
		UNION ALL 
		SELECT 
			  "ext_fkbk_src1"."product_feature_category_code_bk" AS "product_feature_category_code_bk"
			, "dist_fk1"."product_feature_cat_id" AS "product_feature_cat_id"
			, "ext_fkbk_src1"."load_date" AS "load_date"
			, 0 AS "general_order"
		FROM "dist_fk1" "dist_fk1"
		INNER JOIN "moto_sales_ext"."product_feature_cat" "ext_fkbk_src1" ON  "dist_fk1"."product_feature_cat_id" = "ext_fkbk_src1"."product_feature_category_id"
	)
	, "order_bk_fk1" AS 
	( 
		SELECT 
			  "prep_find_bk_fk1"."product_feature_category_code_bk" AS "product_feature_category_code_bk"
			, "prep_find_bk_fk1"."product_feature_cat_id" AS "product_feature_cat_id"
			, ROW_NUMBER()OVER(PARTITION BY "prep_find_bk_fk1"."product_feature_cat_id" ORDER BY "prep_find_bk_fk1"."general_order",
				"prep_find_bk_fk1"."load_date" DESC) AS "dummy"
		FROM "prep_find_bk_fk1" "prep_find_bk_fk1"
	)
	, "find_bk_fk1" AS 
	( 
		SELECT 
			  "order_bk_fk1"."product_feature_category_code_bk" AS "product_feature_category_code_bk"
			, "order_bk_fk1"."product_feature_cat_id" AS "product_feature_cat_id"
		FROM "order_bk_fk1" "order_bk_fk1"
		WHERE  "order_bk_fk1"."dummy" = 1
	)
	SELECT 
		  DIGEST( "ext_src"."product_feature_code_bk" || '#' ,'SHA1') AS "product_features_hkey"
		, DIGEST( COALESCE("find_bk_fk1"."product_feature_category_code_bk","mex_src"."key_attribute_varchar")|| '#' ,
			'SHA1') AS "product_feature_cat_hkey"
		, DIGEST( "ext_src"."product_feature_code_bk" || '#' || COALESCE("find_bk_fk1"."product_feature_category_code_bk",
			"mex_src"."key_attribute_varchar")|| '#' ,'SHA1') AS "lnk_productfeatures_productfeaturecat_hkey"
		, "ext_src"."load_date" AS "load_date"
		, "ext_src"."load_cycle_id" AS "load_cycle_id"
		, 'ms.product_features' AS "record_source"
		, "ext_src"."jrn_flag" AS "jrn_flag"
		, "ext_src"."record_type" AS "record_type"
		, "ext_src"."product_feature_id" AS "product_feature_id"
		, "ext_src"."product_feature_cat_id" AS "product_feature_cat_id"
		, "ext_src"."product_feature_code_bk" AS "product_feature_code_bk"
		, "ext_src"."product_feature_language_code_seq" AS "product_feature_language_code_seq"
		, "ext_src"."product_feature_description" AS "product_feature_description"
		, "ext_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_sales_ext"."product_features" "ext_src"
	INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_src" ON  "mex_src"."record_type" = 'U'
	LEFT OUTER JOIN "find_bk_fk1" "find_bk_fk1" ON  "ext_src"."product_feature_cat_id" = "find_bk_fk1"."product_feature_cat_id"
	;
END;


END;
$function$;
 
 
