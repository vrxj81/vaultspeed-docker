CREATE OR REPLACE FUNCTION "moto_proc"."lds_mktg_campmotochannel_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- lds_tgt

	TRUNCATE TABLE "moto_dv_fl"."lds_mktg_camp_moto_channel"  CASCADE;

	INSERT INTO "moto_dv_fl"."lds_mktg_camp_moto_channel"(
		 "lnd_camp_moto_channel_hkey"
		,"campaign_code"
		,"campaign_start_date"
		,"channel_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"from_date_seq"
		,"motorcycle_name"
		,"to_date"
		,"valid_from_date"
		,"valid_to_date"
		,"update_timestamp"
	)
	WITH "stg_dl_src" AS 
	( 
		SELECT 
			  "stg_dl_inr_src"."lnd_camp_moto_channel_hkey" AS "lnd_camp_moto_channel_hkey"
			, "stg_dl_inr_src"."campaign_code" AS "campaign_code"
			, "stg_dl_inr_src"."campaign_start_date" AS "campaign_start_date"
			, "stg_dl_inr_src"."channel_id" AS "channel_id"
			, "stg_dl_inr_src"."load_date" AS "load_date"
			, "stg_dl_inr_src"."load_cycle_id" AS "load_cycle_id"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_dl_inr_src"."motorcycle_name"),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_dl_inr_src"."to_date",
				 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_dl_inr_src"."valid_from_date", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_dl_inr_src"."valid_to_date", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_dl_inr_src"."update_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, 'N'::text AS "delete_flag"
			, "stg_dl_inr_src"."from_date_seq" AS "from_date_seq"
			, "stg_dl_inr_src"."motorcycle_name" AS "motorcycle_name"
			, "stg_dl_inr_src"."to_date" AS "to_date"
			, "stg_dl_inr_src"."valid_from_date" AS "valid_from_date"
			, "stg_dl_inr_src"."valid_to_date" AS "valid_to_date"
			, "stg_dl_inr_src"."update_timestamp" AS "update_timestamp"
			, ROW_NUMBER()OVER(PARTITION BY "stg_dl_inr_src"."lnd_camp_moto_channel_hkey","stg_dl_inr_src"."from_date_seq" ORDER BY "stg_dl_inr_src"."load_date") AS "dummy"
		FROM "moto_mktg_stg"."camp_moto_channel" "stg_dl_inr_src"
	)
	SELECT 
		  "stg_dl_src"."lnd_camp_moto_channel_hkey" AS "lnd_camp_moto_channel_hkey"
		, "stg_dl_src"."campaign_code" AS "campaign_code"
		, "stg_dl_src"."campaign_start_date" AS "campaign_start_date"
		, "stg_dl_src"."channel_id" AS "channel_id"
		, "stg_dl_src"."load_date" AS "load_date"
		, "stg_dl_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_dl_src"."hash_diff" AS "hash_diff"
		, "stg_dl_src"."delete_flag" AS "delete_flag"
		, "stg_dl_src"."from_date_seq" AS "from_date_seq"
		, "stg_dl_src"."motorcycle_name" AS "motorcycle_name"
		, "stg_dl_src"."to_date" AS "to_date"
		, "stg_dl_src"."valid_from_date" AS "valid_from_date"
		, "stg_dl_src"."valid_to_date" AS "valid_to_date"
		, "stg_dl_src"."update_timestamp" AS "update_timestamp"
	FROM "stg_dl_src" "stg_dl_src"
	WHERE  "stg_dl_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
