CREATE OR REPLACE FUNCTION "moto_proc"."lks_mktg_customers_customers_parent_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- lks_tgt

	TRUNCATE TABLE "moto_dv_fl"."lks_mktg_customers_customers_parent"  CASCADE;

	INSERT INTO "moto_dv_fl"."lks_mktg_customers_customers_parent"(
		 "lnk_customers_customers_parent_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"party_number"
		,"parent_party_number"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."lnk_customers_customers_parent_hkey" AS "lnk_customers_customers_parent_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, 'N'::text AS "delete_flag"
			, "stg_inr_src"."party_number" AS "party_number"
			, "stg_inr_src"."parent_party_number" AS "parent_party_number"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."customers_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_mktg_stg"."party" "stg_inr_src"
	)
	SELECT 
		  "stg_src"."lnk_customers_customers_parent_hkey" AS "lnk_customers_customers_parent_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."delete_flag" AS "delete_flag"
		, "stg_src"."party_number" AS "party_number"
		, "stg_src"."parent_party_number" AS "parent_party_number"
	FROM "stg_src" "stg_src"
	WHERE  "stg_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
