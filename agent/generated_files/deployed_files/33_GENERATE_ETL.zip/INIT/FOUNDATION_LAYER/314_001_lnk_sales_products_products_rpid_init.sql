CREATE OR REPLACE FUNCTION "moto_proc"."lnk_sales_products_products_rpid_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lnk_tgt

	TRUNCATE TABLE "moto_dv_fl"."lnk_products_products_rpid"  CASCADE;

	INSERT INTO "moto_dv_fl"."lnk_products_products_rpid"(
		 "lnk_products_products_rpid_hkey"
		,"load_date"
		,"load_cycle_id"
		,"products_rpid_hkey"
		,"products_hkey"
		,"record_source"
	)
	SELECT DISTINCT 
		  "stg_src"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."products_rpid_hkey" AS "products_rpid_hkey"
		, "stg_src"."products_hkey" AS "products_hkey"
		, "stg_src"."record_source" AS "record_source"
	FROM "moto_sales_stg"."products" "stg_src"
	;
END;


END;
$function$;
 
 
