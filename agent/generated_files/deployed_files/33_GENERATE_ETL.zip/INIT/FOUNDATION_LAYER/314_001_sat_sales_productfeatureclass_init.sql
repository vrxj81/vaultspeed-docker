CREATE OR REPLACE FUNCTION "moto_proc"."sat_sales_productfeatureclass_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- sat_tgt

	TRUNCATE TABLE "moto_dv_fl"."sat_sales_product_feature_class"  CASCADE;

	INSERT INTO "moto_dv_fl"."sat_sales_product_feature_class"(
		 "product_feature_class_hkey"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"product_feature_class_id"
		,"product_feature_class_desc"
		,"update_timestamp"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_inr_src"."product_feature_class_desc"),'~'),'#','\' || 
				'#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_inr_src"."update_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, 'N'::text AS "delete_flag"
			, "stg_inr_src"."product_feature_class_id" AS "product_feature_class_id"
			, "stg_inr_src"."product_feature_class_desc" AS "product_feature_class_desc"
			, "stg_inr_src"."update_timestamp" AS "update_timestamp"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."product_feature_class_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_sales_stg"."product_feature_class" "stg_inr_src"
	)
	SELECT 
		  "stg_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."hash_diff" AS "hash_diff"
		, "stg_src"."delete_flag" AS "delete_flag"
		, "stg_src"."product_feature_class_id" AS "product_feature_class_id"
		, "stg_src"."product_feature_class_desc" AS "product_feature_class_desc"
		, "stg_src"."update_timestamp" AS "update_timestamp"
	FROM "stg_src" "stg_src"
	WHERE  "stg_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
