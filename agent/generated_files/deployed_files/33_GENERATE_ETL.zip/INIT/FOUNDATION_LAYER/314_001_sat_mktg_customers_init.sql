CREATE OR REPLACE FUNCTION "moto_proc"."sat_mktg_customers_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:13
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- sat_tgt

	TRUNCATE TABLE "moto_dv_fl"."sat_mktg_customers"  CASCADE;

	INSERT INTO "moto_dv_fl"."sat_mktg_customers"(
		 "customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"party_number"
		,"address_number"
		,"parent_party_number"
		,"name"
		,"birthdate"
		,"gender"
		,"party_type_code"
		,"comments"
		,"update_timestamp"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."customers_hkey" AS "customers_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( "stg_inr_src"."comments"),'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( "stg_inr_src"."address_number"::text)
				,'~'),'#','\' || '#')|| '#' ||  REPLACE(COALESCE(TRIM( TO_CHAR("stg_inr_src"."update_timestamp", 'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, 'N'::text AS "delete_flag"
			, "stg_inr_src"."party_number" AS "party_number"
			, "stg_inr_src"."address_number" AS "address_number"
			, "stg_inr_src"."parent_party_number" AS "parent_party_number"
			, "stg_inr_src"."name" AS "name"
			, "stg_inr_src"."birthdate" AS "birthdate"
			, "stg_inr_src"."gender" AS "gender"
			, "stg_inr_src"."party_type_code" AS "party_type_code"
			, "stg_inr_src"."comments" AS "comments"
			, "stg_inr_src"."update_timestamp" AS "update_timestamp"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."customers_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_mktg_stg"."party" "stg_inr_src"
	)
	SELECT 
		  "stg_src"."customers_hkey" AS "customers_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."hash_diff" AS "hash_diff"
		, "stg_src"."delete_flag" AS "delete_flag"
		, "stg_src"."party_number" AS "party_number"
		, "stg_src"."address_number" AS "address_number"
		, "stg_src"."parent_party_number" AS "parent_party_number"
		, "stg_src"."name" AS "name"
		, "stg_src"."birthdate" AS "birthdate"
		, "stg_src"."gender" AS "gender"
		, "stg_src"."party_type_code" AS "party_type_code"
		, "stg_src"."comments" AS "comments"
		, "stg_src"."update_timestamp" AS "update_timestamp"
	FROM "stg_src" "stg_src"
	WHERE  "stg_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
