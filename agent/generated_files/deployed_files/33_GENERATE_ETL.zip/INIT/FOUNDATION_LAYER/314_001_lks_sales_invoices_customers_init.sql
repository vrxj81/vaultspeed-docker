CREATE OR REPLACE FUNCTION "moto_proc"."lks_sales_invoices_customers_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lks_tgt

	TRUNCATE TABLE "moto_dv_fl"."lks_sales_invoices_customers"  CASCADE;

	INSERT INTO "moto_dv_fl"."lks_sales_invoices_customers"(
		 "lnk_invoices_customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"invoice_number"
		,"invoice_customer_id"
	)
	WITH "stg_src" AS 
	( 
		SELECT 
			  "stg_inr_src"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
			, "stg_inr_src"."load_date" AS "load_date"
			, "stg_inr_src"."load_cycle_id" AS "load_cycle_id"
			, 'N'::text AS "delete_flag"
			, "stg_inr_src"."invoice_number" AS "invoice_number"
			, "stg_inr_src"."invoice_customer_id" AS "invoice_customer_id"
			, ROW_NUMBER()OVER(PARTITION BY "stg_inr_src"."invoices_hkey" ORDER BY "stg_inr_src"."load_date") AS "dummy"
		FROM "moto_sales_stg"."invoices" "stg_inr_src"
	)
	SELECT 
		  "stg_src"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
		, "stg_src"."load_date" AS "load_date"
		, "stg_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_src"."delete_flag" AS "delete_flag"
		, "stg_src"."invoice_number" AS "invoice_number"
		, "stg_src"."invoice_customer_id" AS "invoice_customer_id"
	FROM "stg_src" "stg_src"
	WHERE  "stg_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
