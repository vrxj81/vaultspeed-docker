CREATE OR REPLACE FUNCTION "moto_proc"."lnd_sales_invoicelines_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lnd_tgt

	TRUNCATE TABLE "moto_dv_fl"."lnd_invoice_lines"  CASCADE;

	INSERT INTO "moto_dv_fl"."lnd_invoice_lines"(
		 "lnd_invoice_lines_hkey"
		,"load_date"
		,"load_cycle_id"
		,"invoices_hkey"
		,"parts_hkey"
		,"products_hkey"
		,"record_source"
	)
	WITH "stg_dl_src" AS 
	( 
		SELECT 
			  "in_stg_dl_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
			, "in_stg_dl_src"."load_date" AS "load_date"
			, "in_stg_dl_src"."load_cycle_id" AS "load_cycle_id"
			, "in_stg_dl_src"."invoices_hkey" AS "invoices_hkey"
			, "in_stg_dl_src"."parts_hkey" AS "parts_hkey"
			, "in_stg_dl_src"."products_hkey" AS "products_hkey"
			, "in_stg_dl_src"."record_source" AS "record_source"
			, ROW_NUMBER()OVER(PARTITION BY "in_stg_dl_src"."lnd_invoice_lines_hkey" ORDER BY "in_stg_dl_src"."load_cycle_id",
				"in_stg_dl_src"."load_date") AS "dummy"
		FROM "moto_sales_stg"."invoice_lines" "in_stg_dl_src"
	)
	SELECT DISTINCT 
		  "stg_dl_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
		, "stg_dl_src"."load_date" AS "load_date"
		, "stg_dl_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_dl_src"."invoices_hkey" AS "invoices_hkey"
		, "stg_dl_src"."parts_hkey" AS "parts_hkey"
		, "stg_dl_src"."products_hkey" AS "products_hkey"
		, "stg_dl_src"."record_source" AS "record_source"
	FROM "stg_dl_src" "stg_dl_src"
	WHERE  "stg_dl_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
