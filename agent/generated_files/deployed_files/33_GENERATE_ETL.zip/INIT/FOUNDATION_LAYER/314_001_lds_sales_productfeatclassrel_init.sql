CREATE OR REPLACE FUNCTION "moto_proc"."lds_sales_productfeatclassrel_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:02:17
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_sales - Release: moto_sales(0.01) - Comment: Initial Sales Release - Release date: 2021/12/29 16:06:21
 */


BEGIN 

BEGIN -- lds_tgt

	TRUNCATE TABLE "moto_dv_fl"."lds_sales_product_feat_class_rel"  CASCADE;

	INSERT INTO "moto_dv_fl"."lds_sales_product_feat_class_rel"(
		 "lnd_product_feat_class_rel_hkey"
		,"product_id"
		,"product_feature_class_id"
		,"product_feature_id"
		,"load_date"
		,"load_cycle_id"
		,"hash_diff"
		,"delete_flag"
		,"update_timestamp"
	)
	WITH "stg_dl_src" AS 
	( 
		SELECT 
			  "stg_dl_inr_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
			, "stg_dl_inr_src"."product_id" AS "product_id"
			, "stg_dl_inr_src"."product_feature_class_id" AS "product_feature_class_id"
			, "stg_dl_inr_src"."product_feature_id" AS "product_feature_id"
			, "stg_dl_inr_src"."load_date" AS "load_date"
			, "stg_dl_inr_src"."load_cycle_id" AS "load_cycle_id"
			, DIGEST(COALESCE(RTRIM( REPLACE(COALESCE(TRIM( TO_CHAR("stg_dl_inr_src"."update_timestamp", 
				'DD/MM/YYYY HH24:MI:SS'::varchar)),'~'),'#','\' || '#')|| '#','#' || '~'),'~') ,'SHA1') AS "hash_diff"
			, 'N'::text AS "delete_flag"
			, "stg_dl_inr_src"."update_timestamp" AS "update_timestamp"
			, ROW_NUMBER()OVER(PARTITION BY "stg_dl_inr_src"."lnd_product_feat_class_rel_hkey" ORDER BY "stg_dl_inr_src"."load_date") AS "dummy"
		FROM "moto_sales_stg"."product_feat_class_rel" "stg_dl_inr_src"
	)
	SELECT 
		  "stg_dl_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "stg_dl_src"."product_id" AS "product_id"
		, "stg_dl_src"."product_feature_class_id" AS "product_feature_class_id"
		, "stg_dl_src"."product_feature_id" AS "product_feature_id"
		, "stg_dl_src"."load_date" AS "load_date"
		, "stg_dl_src"."load_cycle_id" AS "load_cycle_id"
		, "stg_dl_src"."hash_diff" AS "hash_diff"
		, "stg_dl_src"."delete_flag" AS "delete_flag"
		, "stg_dl_src"."update_timestamp" AS "update_timestamp"
	FROM "stg_dl_src" "stg_dl_src"
	WHERE  "stg_dl_src"."dummy" = 1
	;
END;


END;
$function$;
 
 
