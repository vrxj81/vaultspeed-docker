CREATE OR REPLACE FUNCTION "moto_proc"."bv_bridge_cust_part_pro_fea_bridge_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:59
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- bridge_tgt

	TRUNCATE TABLE "moto_dv_bv"."bridge_cust_part_pro_fea"  CASCADE;

	INSERT INTO "moto_dv_bv"."bridge_cust_part_pro_fea"(
		 "load_date"
		,"load_cycle_id"
		,"products_hkey"
		,"customers_hkey"
		,"product_feature_class_hkey"
		,"parts_hkey"
		,"invoices_hkey"
		,"lnk_invoices_customers_hkey"
		,"lnd_invoice_lines_hkey"
		,"lnd_product_feat_class_rel_hkey"
		,"product_cc_bk"
		,"product_et_code_bk"
		,"product_part_code_bk"
		,"product_feature_class_code_bk"
		,"part_number_bk"
		,"invoice_number_bk"
		,"customers_bk"
	)
	WITH "calc_unique" AS 
	( 
		SELECT 
			  "bvlci_src"."load_date" AS "load_date"
			, "bvlci_src"."load_cycle_id" AS "load_cycle_id"
			, "dvo_src1"."parts_hkey" AS "parts_hkey"
			, "dvo_src3"."invoices_hkey" AS "invoices_hkey"
			, "dvo_src5"."customers_hkey" AS "customers_hkey"
			, "dvo_src6"."products_hkey" AS "products_hkey"
			, "dvo_src8"."product_feature_class_hkey" AS "product_feature_class_hkey"
			, MIN("dvo_src7"."lnd_product_feat_class_rel_hkey") AS "lnd_product_feat_class_rel_hkey"
			, "dvo_src2"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
			, "dvo_src4"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
			, "dvo_src1"."part_number_bk" AS "part_number_bk"
			, "dvo_src3"."invoice_number_bk" AS "invoice_number_bk"
			, "dvo_src6"."product_cc_bk" AS "product_cc_bk"
			, "dvo_src6"."product_et_code_bk" AS "product_et_code_bk"
			, "dvo_src6"."product_part_code_bk" AS "product_part_code_bk"
			, "dvo_src8"."product_feature_class_code_bk" AS "product_feature_class_code_bk"
			, "dvo_src5"."customers_bk" AS "customers_bk"
		FROM "moto_fmc"."load_cycle_info" "bvlci_src"
		INNER JOIN "moto_dv_fl"."hub_parts" "dvo_src1" ON 1 = 1
		INNER JOIN "moto_dv_fl"."lnd_invoice_lines" "dvo_src2" ON "dvo_src2"."parts_hkey" = "dvo_src1"."parts_hkey"
		INNER JOIN "moto_dv_fl"."hub_invoices" "dvo_src3" ON "dvo_src3"."invoices_hkey" = "dvo_src2"."invoices_hkey"
		INNER JOIN "moto_dv_fl"."lnk_invoices_customers" "dvo_src4" ON "dvo_src4"."invoices_hkey" = "dvo_src3"."invoices_hkey"
		INNER JOIN "moto_dv_fl"."hub_customers" "dvo_src5" ON "dvo_src5"."customers_hkey" = "dvo_src4"."customers_hkey"
		INNER JOIN "moto_dv_fl"."hub_products" "dvo_src6" ON "dvo_src6"."products_hkey" = "dvo_src2"."products_hkey"
		INNER JOIN "moto_dv_fl"."lnd_product_feat_class_rel" "dvo_src7" ON "dvo_src7"."products_hkey" = "dvo_src6"."products_hkey"
		INNER JOIN "moto_dv_fl"."hub_product_feature_class" "dvo_src8" ON "dvo_src8"."product_feature_class_hkey" = "dvo_src7"."product_feature_class_hkey"
		GROUP BY  "bvlci_src"."load_date",  "bvlci_src"."load_cycle_id",  "dvo_src1"."parts_hkey",  "dvo_src3"."invoices_hkey",
			  "dvo_src5"."customers_hkey",  "dvo_src6"."products_hkey",  "dvo_src8"."product_feature_class_hkey",  "dvo_src2"."lnd_invoice_lines_hkey",  "dvo_src4"."lnk_invoices_customers_hkey",  "dvo_src1"."part_number_bk",  "dvo_src3"."invoice_number_bk",  "dvo_src6"."product_cc_bk",  "dvo_src6"."product_et_code_bk",  "dvo_src6"."product_part_code_bk",  "dvo_src8"."product_feature_class_code_bk",  "dvo_src5"."customers_bk"
	)
	SELECT 
		  "calc_unique"."load_date" AS "load_date"
		, "calc_unique"."load_cycle_id" AS "load_cycle_id"
		, "calc_unique"."products_hkey" AS "products_hkey"
		, "calc_unique"."customers_hkey" AS "customers_hkey"
		, "calc_unique"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "calc_unique"."parts_hkey" AS "parts_hkey"
		, "calc_unique"."invoices_hkey" AS "invoices_hkey"
		, "calc_unique"."lnk_invoices_customers_hkey" AS "lnk_invoices_customers_hkey"
		, "calc_unique"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
		, "calc_unique"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "calc_unique"."product_cc_bk" AS "product_cc_bk"
		, "calc_unique"."product_et_code_bk" AS "product_et_code_bk"
		, "calc_unique"."product_part_code_bk" AS "product_part_code_bk"
		, "calc_unique"."product_feature_class_code_bk" AS "product_feature_class_code_bk"
		, "calc_unique"."part_number_bk" AS "part_number_bk"
		, "calc_unique"."invoice_number_bk" AS "invoice_number_bk"
		, "calc_unique"."customers_bk" AS "customers_bk"
	FROM "calc_unique" "calc_unique"
	;
END;


END;
$function$;
 
 
