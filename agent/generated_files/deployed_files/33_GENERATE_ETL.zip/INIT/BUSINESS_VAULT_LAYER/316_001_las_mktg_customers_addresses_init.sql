CREATE OR REPLACE FUNCTION "moto_proc"."las_mktg_customers_addresses_init"() 
RETURNS void 
LANGUAGE 'plpgsql' 

AS $function$ 
/*
 __     __          _ _                           _      __  ___  __   __   
 \ \   / /_ _ _   _| | |_ ___ ____   ___  ___  __| |     \ \/ _ \/ /  /_/   
  \ \ / / _` | | | | | __/ __|  _ \ / _ \/ _ \/ _` |      \/ / \ \/ /\      
   \ V / (_| | |_| | | |_\__ \ |_) |  __/  __/ (_| |      / / \/\ \/ /      
    \_/ \__,_|\__,_|_|\__|___/ .__/ \___|\___|\__,_|     /_/ \/_/\__/       
                             |_|                                            

Vaultspeed version: 4.2.6.0, generation date: 2021/12/31 15:03:59
DV_NAME: motorcycle_data_vault - Release: Initial DV(0.01) - Comment:  - Release date: 2021/12/29 16:18:08, 
BV release: pits,_bridge_and_end_date_calc_sats(2) - Comment:  - Release date: 2021/12/29 15:20:34, 
SRC_NAME: moto_mktg - Release: moto_mktg(0.01) - Comment: Initial Marketing Release - Release date: 2021/12/29 16:16:34
 */


BEGIN 

BEGIN -- las_temp_tgt

	TRUNCATE TABLE "moto_dv_bv"."las_mktg_customers_addresses_tmp"  CASCADE;

	INSERT INTO "moto_dv_bv"."las_mktg_customers_addresses_tmp"(
		 "lna_customers_addresses_hkey"
		,"addresses_hkey"
		,"customers_hkey"
		,"load_date"
		,"load_cycle_id"
		,"source"
		,"equal"
		,"delete_flag"
		,"party_number"
		,"address_number"
	)
	WITH "las_set" AS 
	( 
		SELECT 
			  DIGEST( "hub_pk_src"."src_bk" || '#' || "hub_pk_src"."customers_bk" || '#' || COALESCE("hub_fk_src"."street_name_bk",
				"unhub_fk_src"."street_name_bk")|| '#' ||  COALESCE("hub_fk_src"."street_number_bk","unhub_fk_src"."street_number_bk")|| '#' ||  COALESCE("hub_fk_src"."postal_code_bk","unhub_fk_src"."postal_code_bk")|| '#' ||  COALESCE("hub_fk_src"."city_bk","unhub_fk_src"."city_bk")|| '#' ,'SHA1') AS "lna_customers_addresses_hkey"
			, COALESCE("hub_fk_src"."addresses_hkey","unhub_fk_src"."addresses_hkey") AS "addresses_hkey"
			, "hub_pk_src"."customers_hkey" AS "customers_hkey"
			, "sat_pk_src"."load_date" AS "load_date"
			, NULL AS "load_end_date"
			, CASE WHEN "mex_ex_src"."load_cycle_id" IS NULL THEN "bvlci_src"."load_cycle_id" ELSE "mex_ex_src"."load_cycle_id"::int END AS "load_cycle_id"
			, "sat_pk_src"."delete_flag" AS "delete_flag"
			, "sat_pk_src"."party_number" AS "party_number"
			, "sat_pk_src"."address_number" AS "address_number"
		FROM "moto_dv_fl"."sat_mktg_customers" "sat_pk_src"
		INNER JOIN "moto_dv_fl"."hub_customers" "hub_pk_src" ON  "sat_pk_src"."customers_hkey" = "hub_pk_src"."customers_hkey"
		LEFT OUTER JOIN "moto_dv_fl"."sat_sales_addresses" "sat_fk_src" ON  "sat_pk_src"."address_number" = "sat_fk_src"."address_number"
		LEFT OUTER JOIN "moto_dv_fl"."hub_addresses" "hub_fk_src" ON  "sat_fk_src"."addresses_hkey" = "hub_fk_src"."addresses_hkey"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_src" ON  1 = 1
		INNER JOIN "moto_dv_fl"."hub_addresses" "unhub_fk_src" ON  "mex_src"."load_cycle_id"::int = "unhub_fk_src"."load_cycle_id"
		INNER JOIN "moto_fmc"."load_cycle_info" "bvlci_src" ON  1 = 1
		LEFT OUTER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_ex_src" ON  "mex_ex_src"."load_cycle_id" = "hub_pk_src"."load_cycle_id" ::text
		WHERE  "mex_src"."record_type" = 'U'
	)
	SELECT 
		  "las_set"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
		, "las_set"."addresses_hkey" AS "addresses_hkey"
		, "las_set"."customers_hkey" AS "customers_hkey"
		, "las_set"."load_date" AS "load_date"
		, "las_set"."load_cycle_id" AS "load_cycle_id"
		, '1' AS "source"
		, CASE WHEN "las_set"."delete_flag"::text || encode("las_set"."addresses_hkey",'hex') = LAG( "las_set"."delete_flag"::text || encode("las_set"."addresses_hkey",
			'hex'),1)OVER(PARTITION BY "las_set"."customers_hkey" ORDER BY "las_set"."load_date")THEN 1 ELSE 0 END AS "equal"
		, "las_set"."delete_flag" AS "delete_flag"
		, "las_set"."party_number" AS "party_number"
		, "las_set"."address_number" AS "address_number"
	FROM "las_set" "las_set"
	;
END;


BEGIN -- las_inur_tgt

	TRUNCATE TABLE "moto_dv_bv"."las_mktg_customers_addresses"  CASCADE;

	INSERT INTO "moto_dv_bv"."las_mktg_customers_addresses"(
		 "lna_customers_addresses_hkey"
		,"load_date"
		,"load_cycle_id"
		,"delete_flag"
		,"party_number"
		,"address_number"
	)
	SELECT 
		  "las_temp_src_inur"."lna_customers_addresses_hkey" AS "lna_customers_addresses_hkey"
		, "las_temp_src_inur"."load_date" AS "load_date"
		, "las_temp_src_inur"."load_cycle_id" AS "load_cycle_id"
		, "las_temp_src_inur"."delete_flag" AS "delete_flag"
		, "las_temp_src_inur"."party_number" AS "party_number"
		, "las_temp_src_inur"."address_number" AS "address_number"
	FROM "moto_dv_bv"."las_mktg_customers_addresses_tmp" "las_temp_src_inur"
	WHERE  "las_temp_src_inur"."equal" = 0
	;
END;


END;
$function$;
 
 
