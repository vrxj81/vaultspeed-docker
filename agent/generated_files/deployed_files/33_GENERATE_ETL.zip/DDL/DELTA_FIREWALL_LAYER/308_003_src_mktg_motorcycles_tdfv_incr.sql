DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_motorcycles";
CREATE   VIEW "moto_mktg_dfv"."vw_motorcycles"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."motorcycle_id" AS "motorcycle_id"
			, "cdc_src"."motorcycle_cc" AS "motorcycle_cc"
			, "cdc_src"."motorcycle_et_code" AS "motorcycle_et_code"
			, "cdc_src"."motorcycle_part_code" AS "motorcycle_part_code"
			, "cdc_src"."motorcycle_name" AS "motorcycle_name"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_motorcycles" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."motorcycle_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "motorcycle_id"
			, "delta_view"."motorcycle_cc" AS "motorcycle_cc"
			, "delta_view"."motorcycle_et_code" AS "motorcycle_et_code"
			, "delta_view"."motorcycle_part_code" AS "motorcycle_part_code"
			, "delta_view"."motorcycle_name" AS "motorcycle_name"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."motorcycle_id" AS "motorcycle_id"
		, "prepjoinbk"."motorcycle_cc" AS "motorcycle_cc"
		, "prepjoinbk"."motorcycle_et_code" AS "motorcycle_et_code"
		, "prepjoinbk"."motorcycle_part_code" AS "motorcycle_part_code"
		, "prepjoinbk"."motorcycle_name" AS "motorcycle_name"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
