DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_party";
CREATE   VIEW "moto_mktg_dfv"."vw_party"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."party_number" AS "party_number"
			, "cdc_src"."parent_party_number" AS "parent_party_number"
			, "cdc_src"."address_number" AS "address_number"
			, "cdc_src"."name" AS "name"
			, "cdc_src"."birthdate" AS "birthdate"
			, "cdc_src"."gender" AS "gender"
			, "cdc_src"."party_type_code" AS "party_type_code"
			, "cdc_src"."comments" AS "comments"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_party" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."party_number", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "party_number"
			, COALESCE("delta_view"."parent_party_number", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "parent_party_number"
			, COALESCE("delta_view"."address_number", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "address_number"
			, "delta_view"."name" AS "name"
			, "delta_view"."birthdate" AS "birthdate"
			, "delta_view"."gender" AS "gender"
			, "delta_view"."party_type_code" AS "party_type_code"
			, "delta_view"."comments" AS "comments"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."party_number" AS "party_number"
		, "prepjoinbk"."parent_party_number" AS "parent_party_number"
		, "prepjoinbk"."address_number" AS "address_number"
		, "prepjoinbk"."name" AS "name"
		, "prepjoinbk"."birthdate" AS "birthdate"
		, "prepjoinbk"."gender" AS "gender"
		, "prepjoinbk"."party_type_code" AS "party_type_code"
		, "prepjoinbk"."comments" AS "comments"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
