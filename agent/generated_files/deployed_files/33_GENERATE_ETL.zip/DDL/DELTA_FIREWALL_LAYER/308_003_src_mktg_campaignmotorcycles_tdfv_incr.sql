DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_campaign_motorcycles";
CREATE   VIEW "moto_mktg_dfv"."vw_campaign_motorcycles"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."campaign_code" AS "campaign_code"
			, "cdc_src"."campaign_start_date" AS "campaign_start_date"
			, "cdc_src"."motorcycle_id" AS "motorcycle_id"
			, "cdc_src"."motorcycle_class_desc" AS "motorcycle_class_desc"
			, "cdc_src"."motorcycle_subclass_desc" AS "motorcycle_subclass_desc"
			, "cdc_src"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
			, "cdc_src"."motorcycle_comment" AS "motorcycle_comment"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_campaign_motorcycles" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."motorcycle_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "motorcycle_id"
			, COALESCE("delta_view"."campaign_code","mex_bk_src"."key_attribute_varchar") AS "campaign_code"
			, COALESCE("delta_view"."campaign_start_date", TO_DATE("mex_bk_src"."key_attribute_date", 'DD/MM/YYYY'::varchar)
				) AS "campaign_start_date"
			, "delta_view"."motorcycle_class_desc" AS "motorcycle_class_desc"
			, "delta_view"."motorcycle_subclass_desc" AS "motorcycle_subclass_desc"
			, "delta_view"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
			, "delta_view"."motorcycle_comment" AS "motorcycle_comment"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."campaign_code" AS "campaign_code"
		, "prepjoinbk"."campaign_start_date" AS "campaign_start_date"
		, "prepjoinbk"."motorcycle_id" AS "motorcycle_id"
		, "prepjoinbk"."motorcycle_class_desc" AS "motorcycle_class_desc"
		, "prepjoinbk"."motorcycle_subclass_desc" AS "motorcycle_subclass_desc"
		, "prepjoinbk"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
		, "prepjoinbk"."motorcycle_comment" AS "motorcycle_comment"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
