DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_party_contacts";
CREATE   VIEW "moto_mktg_dfv"."vw_party_contacts"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."party_number" AS "party_number"
			, "cdc_src"."contact_id" AS "contact_id"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_party_contacts" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."party_number", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "party_number"
			, COALESCE("delta_view"."contact_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "contact_id"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."party_number" AS "party_number"
		, "prepjoinbk"."contact_id" AS "contact_id"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
