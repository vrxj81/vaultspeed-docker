DROP VIEW IF EXISTS "moto_mktg_dfv"."vw_camp_moto_channel";
CREATE   VIEW "moto_mktg_dfv"."vw_camp_moto_channel"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."channel_id" AS "channel_id"
			, "cdc_src"."campaign_code" AS "campaign_code"
			, "cdc_src"."campaign_start_date" AS "campaign_start_date"
			, "cdc_src"."from_date" AS "from_date"
			, "cdc_src"."motorcycle_name" AS "motorcycle_name"
			, "cdc_src"."to_date" AS "to_date"
			, "cdc_src"."valid_from_date" AS "valid_from_date"
			, "cdc_src"."valid_to_date" AS "valid_to_date"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_mktg_cdc"."cdc_camp_moto_channel" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."channel_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "channel_id"
			, COALESCE("delta_view"."campaign_code","mex_bk_src"."key_attribute_varchar") AS "campaign_code"
			, COALESCE("delta_view"."campaign_start_date", TO_DATE("mex_bk_src"."key_attribute_date", 'DD/MM/YYYY'::varchar)
				) AS "campaign_start_date"
			, COALESCE("delta_view"."from_date", TO_TIMESTAMP("mex_bk_src"."key_attribute_timestamp", 
				'DD/MM/YYYY HH24:MI:SS'::varchar)) AS "from_date_seq"
			, "delta_view"."from_date" AS "from_date"
			, "delta_view"."motorcycle_name" AS "motorcycle_name"
			, "delta_view"."to_date" AS "to_date"
			, "delta_view"."valid_from_date" AS "valid_from_date"
			, "delta_view"."valid_to_date" AS "valid_to_date"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_mktg_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."channel_id" AS "channel_id"
		, "prepjoinbk"."campaign_code" AS "campaign_code"
		, "prepjoinbk"."campaign_start_date" AS "campaign_start_date"
		, "prepjoinbk"."from_date" AS "from_date"
		, "prepjoinbk"."motorcycle_name" AS "motorcycle_name"
		, "prepjoinbk"."to_date" AS "to_date"
		, "prepjoinbk"."valid_from_date" AS "valid_from_date"
		, "prepjoinbk"."valid_to_date" AS "valid_to_date"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
