DROP VIEW IF EXISTS "moto_sales_dfv"."vw_invoices";
CREATE   VIEW "moto_sales_dfv"."vw_invoices"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."invoice_number" AS "invoice_number"
			, "cdc_src"."invoice_customer_id" AS "invoice_customer_id"
			, "cdc_src"."invoice_date" AS "invoice_date"
			, "cdc_src"."amount" AS "amount"
			, "cdc_src"."discount" AS "discount"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_invoices" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."invoice_number", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "invoice_number"
			, COALESCE("delta_view"."invoice_customer_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "invoice_customer_id"
			, COALESCE(UPPER( "delta_view"."invoice_number"::text),"mex_bk_src"."key_attribute_numeric") AS "invoice_number_bk"
			, "delta_view"."invoice_date" AS "invoice_date"
			, "delta_view"."amount" AS "amount"
			, "delta_view"."discount" AS "discount"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."invoice_number" AS "invoice_number"
		, "prepjoinbk"."invoice_customer_id" AS "invoice_customer_id"
		, "prepjoinbk"."invoice_date" AS "invoice_date"
		, "prepjoinbk"."amount" AS "amount"
		, "prepjoinbk"."discount" AS "discount"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
