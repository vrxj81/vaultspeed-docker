DROP VIEW IF EXISTS "moto_sales_dfv"."vw_products";
CREATE   VIEW "moto_sales_dfv"."vw_products"  AS 
	WITH "delta_view" AS 
	( 
		SELECT 
			  'S' ::text AS "record_type"
			, "cdc_src"."product_id" AS "product_id"
			, "cdc_src"."replacement_product_id" AS "replacement_product_id"
			, "cdc_src"."product_cc" AS "product_cc"
			, "cdc_src"."product_et_code" AS "product_et_code"
			, "cdc_src"."product_part_code" AS "product_part_code"
			, "cdc_src"."product_intro_date" AS "product_intro_date"
			, "cdc_src"."product_name" AS "product_name"
			, "cdc_src"."update_timestamp" AS "update_timestamp"
		FROM "moto_sales_cdc"."cdc_moto_products" "cdc_src"
	)
	, "prepjoinbk" AS 
	( 
		SELECT 
			  "delta_view"."record_type" AS "record_type"
			, COALESCE("delta_view"."product_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "product_id"
			, COALESCE("delta_view"."replacement_product_id", TO_NUMBER("mex_bk_src"."key_attribute_numeric", 
				'9999999999999D9999999999'::varchar)) AS "replacement_product_id"
			, "delta_view"."product_cc" AS "product_cc"
			, "delta_view"."product_et_code" AS "product_et_code"
			, "delta_view"."product_part_code" AS "product_part_code"
			, "delta_view"."product_intro_date" AS "product_intro_date"
			, "delta_view"."product_name" AS "product_name"
			, "delta_view"."update_timestamp" AS "update_timestamp"
		FROM "delta_view" "delta_view"
		INNER JOIN "moto_sales_mtd"."mtd_exception_records" "mex_bk_src" ON  1 = 1
		WHERE  "mex_bk_src"."record_type" = 'N'
	)
	SELECT 
		  "prepjoinbk"."record_type" AS "record_type"
		, "prepjoinbk"."product_id" AS "product_id"
		, "prepjoinbk"."replacement_product_id" AS "replacement_product_id"
		, "prepjoinbk"."product_cc" AS "product_cc"
		, "prepjoinbk"."product_et_code" AS "product_et_code"
		, "prepjoinbk"."product_part_code" AS "product_part_code"
		, "prepjoinbk"."product_intro_date" AS "product_intro_date"
		, "prepjoinbk"."product_name" AS "product_name"
		, "prepjoinbk"."update_timestamp" AS "update_timestamp"
	FROM "prepjoinbk" "prepjoinbk"
	;

 
 
