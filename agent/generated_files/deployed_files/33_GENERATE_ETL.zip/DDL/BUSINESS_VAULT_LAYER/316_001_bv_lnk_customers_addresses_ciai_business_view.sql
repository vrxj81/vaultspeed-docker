DROP VIEW IF EXISTS "moto_dv_bv"."lnk_customers_addresses_ciai";
CREATE   VIEW "moto_dv_bv"."lnk_customers_addresses_ciai"  AS 
	SELECT 
		  "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."lnk_customers_addresses_ciai_hkey" AS "lnk_customers_addresses_ciai_hkey"
		, "dvt_src"."addresses_ciai_hkey" AS "addresses_ciai_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnk_customers_addresses_ciai" "dvt_src"
	;

 
 
