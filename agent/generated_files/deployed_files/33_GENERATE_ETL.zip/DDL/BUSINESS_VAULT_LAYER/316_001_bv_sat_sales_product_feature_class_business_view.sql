DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_product_feature_class";
CREATE   VIEW "moto_dv_bv"."sat_sales_product_feature_class"  AS 
	SELECT 
		  "dvt_src"."product_feature_class_hkey" AS "product_feature_class_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_feature_class_id" AS "product_feature_class_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."product_feature_class_desc" AS "product_feature_class_desc"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_sales_product_feature_class" "dvt_src"
	;

 
 
