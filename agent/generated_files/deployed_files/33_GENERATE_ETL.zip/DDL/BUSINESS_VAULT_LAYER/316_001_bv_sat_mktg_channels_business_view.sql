DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_channels";
CREATE   VIEW "moto_dv_bv"."sat_mktg_channels"  AS 
	SELECT 
		  "dvt_src"."channels_hkey" AS "channels_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."channel_id" AS "channel_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."channel_description" AS "channel_description"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_mktg_channels" "dvt_src"
	;

 
 
