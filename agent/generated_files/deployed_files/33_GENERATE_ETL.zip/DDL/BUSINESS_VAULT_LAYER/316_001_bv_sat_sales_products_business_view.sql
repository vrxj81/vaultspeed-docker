DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_products";
CREATE   VIEW "moto_dv_bv"."sat_sales_products"  AS 
	SELECT 
		  "dvt_src"."products_hkey" AS "products_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_id" AS "product_id"
		, "dvt_src"."replacement_product_id" AS "replacement_product_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."product_intro_date" AS "product_intro_date"
		, "dvt_src"."product_name" AS "product_name"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_sales_products" "dvt_src"
	;

 
 
