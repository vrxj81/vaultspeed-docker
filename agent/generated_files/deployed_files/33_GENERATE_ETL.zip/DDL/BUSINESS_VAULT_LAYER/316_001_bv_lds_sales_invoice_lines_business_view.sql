DROP VIEW IF EXISTS "moto_dv_bv"."lds_sales_invoice_lines";
CREATE   VIEW "moto_dv_bv"."lds_sales_invoice_lines"  AS 
	SELECT 
		  "dvt_src"."lnd_invoice_lines_hkey" AS "lnd_invoice_lines_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."invoice_number" AS "invoice_number"
		, "dvt_src"."part_id" AS "part_id"
		, "dvt_src"."product_id" AS "product_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."amount" AS "amount"
		, "dvt_src"."quantity" AS "quantity"
		, "dvt_src"."unit_price" AS "unit_price"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
		, "dvt_src"."invoice_line_number_seq" AS "invoice_line_number_seq"
	FROM "moto_dv_fl"."lds_sales_invoice_lines" "dvt_src"
	;

 
 
