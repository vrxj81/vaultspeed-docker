DROP VIEW IF EXISTS "moto_dv_bv"."lds_sales_product_feat_class_rel";
CREATE   VIEW "moto_dv_bv"."lds_sales_product_feat_class_rel"  AS 
	SELECT 
		  "dvt_src"."lnd_product_feat_class_rel_hkey" AS "lnd_product_feat_class_rel_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_id" AS "product_id"
		, "dvt_src"."product_feature_class_id" AS "product_feature_class_id"
		, "dvt_src"."product_feature_id" AS "product_feature_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lds_sales_product_feat_class_rel" "dvt_src"
	;

 
 
