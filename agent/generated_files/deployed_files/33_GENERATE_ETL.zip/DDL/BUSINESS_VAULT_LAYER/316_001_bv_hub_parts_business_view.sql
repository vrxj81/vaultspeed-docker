DROP VIEW IF EXISTS "moto_dv_bv"."hub_parts";
CREATE   VIEW "moto_dv_bv"."hub_parts"  AS 
	SELECT 
		  "dvt_src"."parts_hkey" AS "parts_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."part_number_bk" AS "part_number_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_parts" "dvt_src"
	;

 
 
