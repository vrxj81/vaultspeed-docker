DROP VIEW IF EXISTS "moto_dv_bv"."lks_sales_productfeatures_productfeaturecat";
CREATE   VIEW "moto_dv_bv"."lks_sales_productfeatures_productfeaturecat"  AS 
	SELECT 
		  "dvt_src"."lnk_productfeatures_productfeaturecat_hkey" AS "lnk_productfeatures_productfeaturecat_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_feature_id" AS "product_feature_id"
		, "dvt_src"."product_feature_cat_id" AS "product_feature_cat_id"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lks_sales_productfeatures_productfeaturecat" "dvt_src"
	;

 
 
