DROP VIEW IF EXISTS "moto_dv_bv"."hub_customers";
CREATE   VIEW "moto_dv_bv"."hub_customers"  AS 
	SELECT 
		  "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."customers_bk" AS "customers_bk"
		, "dvt_src"."src_bk" AS "src_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_customers" "dvt_src"
	;

 
 
