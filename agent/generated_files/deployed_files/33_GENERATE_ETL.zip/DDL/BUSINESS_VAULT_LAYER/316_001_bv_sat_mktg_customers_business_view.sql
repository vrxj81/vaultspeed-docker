DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_customers";
CREATE   VIEW "moto_dv_bv"."sat_mktg_customers"  AS 
	SELECT 
		  "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."party_number" AS "party_number"
		, "dvt_src"."address_number" AS "address_number"
		, "dvt_src"."parent_party_number" AS "parent_party_number"
		, "dvt_src"."name" AS "name"
		, "dvt_src"."birthdate" AS "birthdate"
		, "dvt_src"."gender" AS "gender"
		, "dvt_src"."party_type_code" AS "party_type_code"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."comments" AS "comments"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_mktg_customers" "dvt_src"
	;

 
 
