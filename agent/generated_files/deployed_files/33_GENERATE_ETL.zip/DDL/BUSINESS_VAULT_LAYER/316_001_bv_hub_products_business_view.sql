DROP VIEW IF EXISTS "moto_dv_bv"."hub_products";
CREATE   VIEW "moto_dv_bv"."hub_products"  AS 
	SELECT 
		  "dvt_src"."products_hkey" AS "products_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_cc_bk" AS "product_cc_bk"
		, "dvt_src"."product_et_code_bk" AS "product_et_code_bk"
		, "dvt_src"."product_part_code_bk" AS "product_part_code_bk"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."hub_products" "dvt_src"
	;

 
 
