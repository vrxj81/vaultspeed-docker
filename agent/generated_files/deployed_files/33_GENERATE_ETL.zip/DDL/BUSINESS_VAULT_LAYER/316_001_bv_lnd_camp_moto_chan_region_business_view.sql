DROP VIEW IF EXISTS "moto_dv_bv"."lnd_camp_moto_chan_region";
CREATE   VIEW "moto_dv_bv"."lnd_camp_moto_chan_region"  AS 
	SELECT 
		  "dvt_src"."lnd_camp_moto_chan_region_hkey" AS "lnd_camp_moto_chan_region_hkey"
		, "dvt_src"."campaigns_hkey" AS "campaigns_hkey"
		, "dvt_src"."channels_hkey" AS "channels_hkey"
		, "dvt_src"."products_hkey" AS "products_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnd_camp_moto_chan_region" "dvt_src"
	;

 
 
