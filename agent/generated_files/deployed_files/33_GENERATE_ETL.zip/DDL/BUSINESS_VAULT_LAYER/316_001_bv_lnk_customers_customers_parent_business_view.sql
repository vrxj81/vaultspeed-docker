DROP VIEW IF EXISTS "moto_dv_bv"."lnk_customers_customers_parent";
CREATE   VIEW "moto_dv_bv"."lnk_customers_customers_parent"  AS 
	SELECT 
		  "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."lnk_customers_customers_parent_hkey" AS "lnk_customers_customers_parent_hkey"
		, "dvt_src"."customers_parent_hkey" AS "customers_parent_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnk_customers_customers_parent" "dvt_src"
	;

 
 
