DROP VIEW IF EXISTS "moto_dv_bv"."lds_mktg_campaign_motorcycles_emo";
CREATE   VIEW "moto_dv_bv"."lds_mktg_campaign_motorcycles_emo"  AS 
	SELECT 
		  "dvt_src"."lnd_campaign_motorcycles_hkey" AS "lnd_campaign_motorcycles_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."campaign_code" AS "campaign_code"
		, "dvt_src"."campaign_start_date" AS "campaign_start_date"
		, "dvt_src"."motorcycle_id" AS "motorcycle_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."motorcycle_emotion_desc" AS "motorcycle_emotion_desc"
		, "dvt_src"."motorcycle_comment" AS "motorcycle_comment"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."lds_mktg_campaign_motorcycles_emo" "dvt_src"
	;

 
 
