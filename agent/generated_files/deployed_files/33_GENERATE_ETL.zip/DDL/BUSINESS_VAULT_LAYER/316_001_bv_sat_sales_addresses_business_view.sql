DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_addresses";
CREATE   VIEW "moto_dv_bv"."sat_sales_addresses"  AS 
	SELECT 
		  "dvt_src"."addresses_hkey" AS "addresses_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."address_number" AS "address_number"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."coordinates" AS "coordinates"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
	FROM "moto_dv_fl"."sat_sales_addresses" "dvt_src"
	;

 
 
