DROP VIEW IF EXISTS "moto_dv_bv"."sat_sales_product_features";
CREATE   VIEW "moto_dv_bv"."sat_sales_product_features"  AS 
	SELECT 
		  "dvt_src"."product_features_hkey" AS "product_features_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."product_feature_id" AS "product_feature_id"
		, "dvt_src"."product_feature_cat_id" AS "product_feature_cat_id"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."product_feature_description" AS "product_feature_description"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
		, "dvt_src"."product_feature_language_code_seq" AS "product_feature_language_code_seq"
	FROM "moto_dv_fl"."sat_sales_product_features" "dvt_src"
	;

 
 
