DROP VIEW IF EXISTS "moto_dv_bv"."sat_mktg_campaigns";
CREATE   VIEW "moto_dv_bv"."sat_mktg_campaigns"  AS 
	SELECT 
		  "dvt_src"."campaigns_hkey" AS "campaigns_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."campaign_code" AS "campaign_code"
		, "dvt_src"."campaign_start_date" AS "campaign_start_date"
		, "dvt_src"."hash_diff" AS "hash_diff"
		, "dvt_src"."campaign_name" AS "campaign_name"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
		, "dvt_src"."delete_flag" AS "delete_flag"
		, "dvt_src"."campaign_start_date_seq" AS "campaign_start_date_seq"
	FROM "moto_dv_fl"."sat_mktg_campaigns" "dvt_src"
	;

 
 
