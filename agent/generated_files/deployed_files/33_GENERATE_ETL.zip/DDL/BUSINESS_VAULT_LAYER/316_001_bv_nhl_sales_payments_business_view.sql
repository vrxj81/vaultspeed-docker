DROP VIEW IF EXISTS "moto_dv_bv"."nhl_sales_payments";
CREATE   VIEW "moto_dv_bv"."nhl_sales_payments"  AS 
	SELECT 
		  "dvt_src"."nhl_payments_hkey" AS "nhl_payments_hkey"
		, "dvt_src"."invoices_hkey" AS "invoices_hkey"
		, "dvt_src"."customers_hkey" AS "customers_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."customer_number" AS "customer_number"
		, "dvt_src"."invoice_number" AS "invoice_number"
		, "dvt_src"."record_source" AS "record_source"
		, "dvt_src"."date_time" AS "date_time"
		, "dvt_src"."amount" AS "amount"
		, "dvt_src"."update_timestamp" AS "update_timestamp"
	FROM "moto_dv_fl"."nhl_sales_payments" "dvt_src"
	;

 
 
