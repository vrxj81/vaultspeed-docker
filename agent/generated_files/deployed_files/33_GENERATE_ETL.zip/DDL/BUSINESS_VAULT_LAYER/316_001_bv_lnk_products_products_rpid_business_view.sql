DROP VIEW IF EXISTS "moto_dv_bv"."lnk_products_products_rpid";
CREATE   VIEW "moto_dv_bv"."lnk_products_products_rpid"  AS 
	SELECT 
		  "dvt_src"."products_hkey" AS "products_hkey"
		, "dvt_src"."lnk_products_products_rpid_hkey" AS "lnk_products_products_rpid_hkey"
		, "dvt_src"."products_rpid_hkey" AS "products_rpid_hkey"
		, "dvt_src"."load_date" AS "load_date"
		, "dvt_src"."load_cycle_id" AS "load_cycle_id"
		, "dvt_src"."record_source" AS "record_source"
	FROM "moto_dv_fl"."lnk_products_products_rpid" "dvt_src"
	;

 
 
